import { z } from "zod";
import { findChoiceEvaluator } from "../contracts/choice-evaluation.js";
import { questionDeliveryReviewBasis, questionDeliveryScoringKey } from "../contracts/question-delivery.js";
import { findResponseEvaluator } from "../contracts/response-evaluation.js";
import { indexResponseValue, orderedTextResponseValue, responseValue, titledTextResponseValue } from "../contracts/response.js";
import { loadEvaluationKey } from "./evaluation.js";
import { LearningError } from "./learning-error.js";
import { readResponseReviewRequirements, recoverEvaluatedResponses } from "./response-evaluation.js";
import { submissionAssessmentTarget } from "./verdict-state.js";
export function recoverQuestionDeliveryEvaluation(database, activity, receipt, delivery, registered) {
    const target = submissionAssessmentTarget(database, receipt.id);
    return recoverEvaluatedResponses(database, activity, receipt, delivery.questions, (reference, key, context) => {
        const { acceptedByQuestion } = questionDeliveryScoringKey.parse(key);
        return question => {
            const basis = Object.hasOwn(acceptedByQuestion, question.questionId) ? acceptedByQuestion[question.questionId] : undefined;
            if (!basis)
                throw new Error("冻结的逐题评分键缺少题目");
            const evaluate = evaluateOf(reference, basis, registered);
            return evaluate({ ...context, practice: { ...context.practice }, ...question });
        };
    }, target);
}
export function readManualReviewQuestions(database, receipt, delivery) {
    const required = new Set(readResponseReviewRequirements(database, receipt.id));
    if (required.size !== delivery.questions.length || delivery.questions.some(({ questionId }) => !required.has(questionId))) {
        throw new Error("人工待评位置与冻结提交不一致");
    }
    return delivery.questions.map(({ questionId, questionVersion }) => ({ questionId, questionVersion, status: "needsReview" }));
}
export function readManualReviewBasis(database, receipt, reference) {
    const basis = questionDeliveryReviewBasis.parse(loadEvaluationKey(database, receipt.id));
    if (basis.id !== reference.id || basis.version !== reference.version)
        throw new Error("人工待评引用与冻结依据不一致");
    return basis;
}
const confirmedChoice = z.string().nullable();
const confirmedScalar = responseValue.nullable();
const confirmedIndexes = indexResponseValue.nullable();
const confirmedOrderedText = orderedTextResponseValue.nullable();
const confirmedTitledText = titledTextResponseValue.nullable();
function evaluateOf(reference, basis, { choice = [], scalar = [], indexes = [], orderedText = [], titledText = [] }) {
    switch (basis.response) {
        case "choice": {
            const evaluate = requireEvaluator(findChoiceEvaluator(choice, reference));
            return ({ value, ...context }) => {
                const correct = evaluate({ ...context, choice: confirmedChoice.parse(value), acceptedChoice: basis.acceptedChoice });
                return { status: "judged", correct };
            };
        }
        case "booleanOrString": {
            const evaluate = requireEvaluator(findResponseEvaluator(scalar, reference));
            return ({ value, ...context }) => evaluate({ ...context, value: confirmedScalar.parse(value), acceptedResponse: basis.acceptedResponse });
        }
        case "optionIndexArray": {
            const evaluate = requireEvaluator(findResponseEvaluator(indexes, reference));
            return ({ value, ...context }) => evaluate({ ...context, value: confirmedIndexes.parse(value), acceptedIndexes: [...basis.acceptedIndexes] });
        }
        case "orderedTextBlanks": {
            const evaluate = requireEvaluator(findResponseEvaluator(orderedText, reference));
            return ({ value, ...context }) => evaluate({
                ...context, value: confirmedOrderedText.parse(value),
                acceptedBlanks: basis.acceptedBlanks.map(values => [...values]),
            });
        }
        case "textWithOptionalTitle": {
            const evaluate = requireEvaluator(findResponseEvaluator(titledText, reference));
            return ({ value, ...context }) => evaluate({ ...context, value: confirmedTitledText.parse(value) });
        }
    }
}
function requireEvaluator(evaluate) {
    if (!evaluate)
        throw new LearningError(503, "EVALUATOR_UNAVAILABLE");
    return evaluate;
}
