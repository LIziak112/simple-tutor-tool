import type { DatabaseSync } from "node:sqlite";
import type { QuestionDelivery } from "../contracts/question-delivery.ts";
import type { SubmissionReceipt, VersionRef } from "../contracts/reading.ts";
import type { ReadingActivity } from "./activity.ts";
import type { PublicationEvaluators } from "./publication-bindings.ts";
export declare function recoverQuestionDeliveryEvaluation(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, delivery: QuestionDelivery, registered: PublicationEvaluators): {
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    needsReviewCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        result: {
            status: "judged";
            correct: boolean;
        } | {
            status: "needsReview";
        };
    }[];
};
export declare function readManualReviewQuestions(database: DatabaseSync, receipt: SubmissionReceipt, delivery: QuestionDelivery): {
    questionId: string;
    questionVersion: number;
    status: "needsReview";
}[];
export declare function readManualReviewBasis(database: DatabaseSync, receipt: SubmissionReceipt, reference: VersionRef): {
    id: string;
    version: number;
    reviewCriteria: string;
};
