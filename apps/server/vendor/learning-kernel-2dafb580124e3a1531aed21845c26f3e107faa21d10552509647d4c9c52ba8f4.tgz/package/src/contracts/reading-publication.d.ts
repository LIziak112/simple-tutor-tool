import { z } from "zod";
declare const slot: z.ZodDiscriminatedUnion<[z.ZodObject<{
    source: z.ZodString;
    targetId: z.ZodString;
    type: z.ZodLiteral<"passageSelection">;
    oneRangePerRole: z.ZodRecord<z.ZodString, z.ZodString>;
    distinctParagraphs: z.ZodBoolean;
    evidenceUnit: z.ZodLiteral<"wholeSelection">;
}, z.core.$strict>, z.ZodObject<{
    source: z.ZodString;
    targetId: z.ZodString;
    type: z.ZodLiteral<"oneChoicePerQuestion">;
    reasonTargetId: z.ZodOptional<z.ZodString>;
    confirmFromDrafts: z.ZodOptional<z.ZodObject<{
        allowUnanswered: z.ZodBoolean;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    source: z.ZodString;
    targetId: z.ZodString;
    type: z.ZodLiteral<"oneResponsePerQuestion">;
    input: z.ZodEnum<{
        booleanOrString: "booleanOrString";
        optionIndexArray: "optionIndexArray";
    }>;
    confirmFromDrafts: z.ZodObject<{
        allowUnanswered: z.ZodBoolean;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    source: z.ZodString;
    targetId: z.ZodString;
    type: z.ZodLiteral<"questionDelivery">;
    delivery: z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"whole">;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"perQuestion">;
        questionSlots: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodString>, z.ZodTransform<{
            [k: string]: string;
        }, Record<string, string>>>;
    }, z.core.$strict>], "mode">;
    confirmFromDrafts: z.ZodObject<{
        allowUnanswered: z.ZodBoolean;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"reuse">;
    source: z.ZodString;
}, z.core.$strict>], "type">;
declare const step: z.ZodObject<{
    id: z.ZodString;
    requires: z.ZodOptional<z.ZodString>;
    instructions: z.ZodString;
    tool: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
    }, z.core.$strict>;
    inputs: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
        from: z.ZodLiteral<"material">;
        positionId: z.ZodString;
        material: z.ZodOptional<z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        from: z.ZodLiteral<"questions">;
    }, z.core.$strict>, z.ZodObject<{
        stepId: z.ZodString;
        slotId: z.ZodString;
        from: z.ZodLiteral<"submission">;
        readOnly: z.ZodLiteral<true>;
    }, z.core.$strict>], "from">>;
    submit: z.ZodObject<{
        purpose: z.ZodEnum<{
            finalAnswer: "finalAnswer";
            stepEvidence: "stepEvidence";
        }>;
        slots: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
            source: z.ZodString;
            targetId: z.ZodString;
            type: z.ZodLiteral<"passageSelection">;
            oneRangePerRole: z.ZodRecord<z.ZodString, z.ZodString>;
            distinctParagraphs: z.ZodBoolean;
            evidenceUnit: z.ZodLiteral<"wholeSelection">;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodString;
            targetId: z.ZodString;
            type: z.ZodLiteral<"oneChoicePerQuestion">;
            reasonTargetId: z.ZodOptional<z.ZodString>;
            confirmFromDrafts: z.ZodOptional<z.ZodObject<{
                allowUnanswered: z.ZodBoolean;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodString;
            targetId: z.ZodString;
            type: z.ZodLiteral<"oneResponsePerQuestion">;
            input: z.ZodEnum<{
                booleanOrString: "booleanOrString";
                optionIndexArray: "optionIndexArray";
            }>;
            confirmFromDrafts: z.ZodObject<{
                allowUnanswered: z.ZodBoolean;
            }, z.core.$strict>;
        }, z.core.$strict>, z.ZodObject<{
            source: z.ZodString;
            targetId: z.ZodString;
            type: z.ZodLiteral<"questionDelivery">;
            delivery: z.ZodDiscriminatedUnion<[z.ZodObject<{
                mode: z.ZodLiteral<"whole">;
            }, z.core.$strict>, z.ZodObject<{
                mode: z.ZodLiteral<"perQuestion">;
                questionSlots: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodString>, z.ZodTransform<{
                    [k: string]: string;
                }, Record<string, string>>>;
            }, z.core.$strict>], "mode">;
            confirmFromDrafts: z.ZodObject<{
                allowUnanswered: z.ZodBoolean;
            }, z.core.$strict>;
        }, z.core.$strict>, z.ZodObject<{
            type: z.ZodLiteral<"reuse">;
            source: z.ZodString;
        }, z.core.$strict>], "type">>;
    }, z.core.$strict>;
    afterConfirmation: z.ZodEnum<{
        advance: "advance";
        finish: "finish";
    }>;
}, z.core.$strict>;
export declare const readingQuestion: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodOptional<z.ZodInt>;
    prompt: z.ZodString;
    options: z.ZodRecord<z.ZodString, z.ZodString>;
}, z.core.$strict>;
export declare const readingPracticeSchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    formatVersion: z.ZodLiteral<1>;
    title: z.ZodString;
    material: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
    }, z.core.$strict>>;
    goals: z.ZodRecord<z.ZodString, z.ZodString>;
    questions: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        id: z.ZodString;
        version: z.ZodOptional<z.ZodInt>;
        prompt: z.ZodString;
        options: z.ZodRecord<z.ZodString, z.ZodString>;
        response: z.ZodOptional<z.ZodEnum<{
            booleanOrString: "booleanOrString";
            choice: "choice";
            optionIndexArray: "optionIndexArray";
        }>>;
    }, z.core.$strict>, z.ZodObject<{
        id: z.ZodString;
        version: z.ZodOptional<z.ZodInt>;
        prompt: z.ZodString;
        response: z.ZodLiteral<"orderedTextBlanks">;
        blankCount: z.ZodInt;
        options: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodNever>>;
    }, z.core.$strict>, z.ZodObject<{
        id: z.ZodString;
        version: z.ZodOptional<z.ZodInt>;
        prompt: z.ZodString;
        response: z.ZodLiteral<"textWithOptionalTitle">;
        options: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodNever>>;
    }, z.core.$strict>], "response">>>;
    questionAnswerRules: z.ZodOptional<z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
    }, z.core.$strict>>, z.ZodTransform<{
        [k: string]: {
            id: string;
            version: number;
        };
    }, Record<string, {
        id: string;
        version: number;
    }>>>>;
    steps: z.ZodTuple<[z.ZodObject<{
        id: z.ZodString;
        requires: z.ZodOptional<z.ZodString>;
        instructions: z.ZodString;
        tool: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>;
        inputs: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
            from: z.ZodLiteral<"material">;
            positionId: z.ZodString;
            material: z.ZodOptional<z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            from: z.ZodLiteral<"questions">;
        }, z.core.$strict>, z.ZodObject<{
            stepId: z.ZodString;
            slotId: z.ZodString;
            from: z.ZodLiteral<"submission">;
            readOnly: z.ZodLiteral<true>;
        }, z.core.$strict>], "from">>;
        submit: z.ZodObject<{
            purpose: z.ZodEnum<{
                finalAnswer: "finalAnswer";
                stepEvidence: "stepEvidence";
            }>;
            slots: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"passageSelection">;
                oneRangePerRole: z.ZodRecord<z.ZodString, z.ZodString>;
                distinctParagraphs: z.ZodBoolean;
                evidenceUnit: z.ZodLiteral<"wholeSelection">;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"oneChoicePerQuestion">;
                reasonTargetId: z.ZodOptional<z.ZodString>;
                confirmFromDrafts: z.ZodOptional<z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"oneResponsePerQuestion">;
                input: z.ZodEnum<{
                    booleanOrString: "booleanOrString";
                    optionIndexArray: "optionIndexArray";
                }>;
                confirmFromDrafts: z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"questionDelivery">;
                delivery: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    mode: z.ZodLiteral<"whole">;
                }, z.core.$strict>, z.ZodObject<{
                    mode: z.ZodLiteral<"perQuestion">;
                    questionSlots: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodString>, z.ZodTransform<{
                        [k: string]: string;
                    }, Record<string, string>>>;
                }, z.core.$strict>], "mode">;
                confirmFromDrafts: z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"reuse">;
                source: z.ZodString;
            }, z.core.$strict>], "type">>;
        }, z.core.$strict>;
        afterConfirmation: z.ZodEnum<{
            advance: "advance";
            finish: "finish";
        }>;
    }, z.core.$strict>], z.ZodObject<{
        id: z.ZodString;
        requires: z.ZodOptional<z.ZodString>;
        instructions: z.ZodString;
        tool: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>;
        inputs: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
            from: z.ZodLiteral<"material">;
            positionId: z.ZodString;
            material: z.ZodOptional<z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            from: z.ZodLiteral<"questions">;
        }, z.core.$strict>, z.ZodObject<{
            stepId: z.ZodString;
            slotId: z.ZodString;
            from: z.ZodLiteral<"submission">;
            readOnly: z.ZodLiteral<true>;
        }, z.core.$strict>], "from">>;
        submit: z.ZodObject<{
            purpose: z.ZodEnum<{
                finalAnswer: "finalAnswer";
                stepEvidence: "stepEvidence";
            }>;
            slots: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"passageSelection">;
                oneRangePerRole: z.ZodRecord<z.ZodString, z.ZodString>;
                distinctParagraphs: z.ZodBoolean;
                evidenceUnit: z.ZodLiteral<"wholeSelection">;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"oneChoicePerQuestion">;
                reasonTargetId: z.ZodOptional<z.ZodString>;
                confirmFromDrafts: z.ZodOptional<z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"oneResponsePerQuestion">;
                input: z.ZodEnum<{
                    booleanOrString: "booleanOrString";
                    optionIndexArray: "optionIndexArray";
                }>;
                confirmFromDrafts: z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"questionDelivery">;
                delivery: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    mode: z.ZodLiteral<"whole">;
                }, z.core.$strict>, z.ZodObject<{
                    mode: z.ZodLiteral<"perQuestion">;
                    questionSlots: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodString>, z.ZodTransform<{
                        [k: string]: string;
                    }, Record<string, string>>>;
                }, z.core.$strict>], "mode">;
                confirmFromDrafts: z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"reuse">;
                source: z.ZodString;
            }, z.core.$strict>], "type">>;
        }, z.core.$strict>;
        afterConfirmation: z.ZodEnum<{
            advance: "advance";
            finish: "finish";
        }>;
    }, z.core.$strict>>;
    grading: z.ZodDefault<z.ZodObject<{
        selectionFeedback: z.ZodOptional<z.ZodObject<{
            from: z.ZodObject<{
                stepId: z.ZodString;
                slotId: z.ZodString;
            }, z.core.$strict>;
            criterion: z.ZodString;
        }, z.core.$strict>>;
        assessment: z.ZodOptional<z.ZodObject<{
            from: z.ZodObject<{
                stepId: z.ZodString;
                slotId: z.ZodString;
            }, z.core.$strict>;
            evaluator: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>;
            keyRef: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>;
            unit: z.ZodLiteral<"question">;
            effectiveVerdictOrder: z.ZodTuple<[z.ZodLiteral<"teacherReview">, z.ZodLiteral<"automatic">], null>;
        }, z.core.$strict>>;
        manualReview: z.ZodOptional<z.ZodObject<{
            keyRef: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    policy: z.ZodObject<{
        timeLimit: z.ZodOptional<z.ZodObject<{
            minutes: z.ZodInt;
            startsAt: z.ZodLiteral<"instanceStarted">;
            onDeadline: z.ZodLiteral<"keepDraftAndClose">;
        }, z.core.$strict>>;
        offline: z.ZodLiteral<"onlineOnly">;
        redo: z.ZodLiteral<"newInstanceOnAuthorization">;
        student: z.ZodObject<{
            ownSubmission: z.ZodObject<{
                scope: z.ZodLiteral<"ownConfirmedSubmissions">;
                fields: z.ZodArray<z.ZodEnum<{
                    ownChoices: "ownChoices";
                    ownResponses: "ownResponses";
                    receipt: "receipt";
                    submittedQuotes: "submittedQuotes";
                }>>;
                onFinal: z.ZodArray<z.ZodLiteral<"passageGradingStatus">>;
            }, z.core.$strict>;
            passageScore: z.ZodOptional<z.ZodObject<{
                whenAll: z.ZodTuple<[z.ZodLiteral<"finalConfirmed">, z.ZodLiteral<"allQuestionsJudged">], null>;
                group: z.ZodLiteral<"wholePassage">;
                fields: z.ZodArray<z.ZodEnum<{
                    correctCount: "correctCount";
                    questionCount: "questionCount";
                }>>;
                allowSubsets: z.ZodLiteral<false>;
                drilldown: z.ZodLiteral<false>;
            }, z.core.$strict>>;
            review: z.ZodOptional<z.ZodObject<{
                requires: z.ZodLiteral<"passageScore">;
                while: z.ZodLiteral<"reviewOpen">;
                byQuestion: z.ZodArray<z.ZodLiteral<"effectiveVerdict">>;
                byQuoteSet: z.ZodArray<z.ZodLiteral<"learnerFeedback">>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        reviewer: z.ZodObject<{
            scope: z.ZodLiteral<"assignedReviewer">;
            fields: z.ZodArray<z.ZodEnum<{
                gradingBasis: "gradingBasis";
                learnerFeedback: "learnerFeedback";
                studentChoices: "studentChoices";
                submittedQuotes: "submittedQuotes";
                verdictHistory: "verdictHistory";
            }>>;
            actions: z.ZodArray<z.ZodEnum<{
                commentOnQuotes: "commentOnQuotes";
                reviseQuestionVerdict: "reviseQuestionVerdict";
            }>>;
        }, z.core.$strict>;
        manager: z.ZodObject<{
            scope: z.ZodLiteral<"assigningTeacher">;
            actions: z.ZodArray<z.ZodEnum<{
                authorizeRedo: "authorizeRedo";
                closeReview: "closeReview";
                openReview: "openReview";
            }>>;
        }, z.core.$strict>;
        externalAi: z.ZodLiteral<"disabled">;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const scoringKeySchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    acceptedChoices: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodString>, z.ZodTransform<{
        [k: string]: string;
    }, Record<string, string>>>;
}, z.core.$strict>;
export declare const responseScoringKeySchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    acceptedResponses: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodBoolean>, z.ZodTransform<{
        [k: string]: boolean;
    }, Record<string, boolean>>>;
}, z.core.$strict>;
export declare const indexResponseScoringKeySchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    acceptedIndexes: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodInt>>, z.ZodTransform<{
        [k: string]: number[];
    }, Record<string, number[]>>>;
}, z.core.$strict>;
export declare const readingPublicationSchema: z.ZodObject<{
    material: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        source: z.ZodString;
        title: z.ZodString;
        paragraphs: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            text: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    materials: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        source: z.ZodString;
        title: z.ZodString;
        paragraphs: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            text: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    practice: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        formatVersion: z.ZodLiteral<1>;
        title: z.ZodString;
        material: z.ZodOptional<z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>>;
        goals: z.ZodRecord<z.ZodString, z.ZodString>;
        questions: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            id: z.ZodString;
            version: z.ZodOptional<z.ZodInt>;
            prompt: z.ZodString;
            options: z.ZodRecord<z.ZodString, z.ZodString>;
            response: z.ZodOptional<z.ZodEnum<{
                booleanOrString: "booleanOrString";
                choice: "choice";
                optionIndexArray: "optionIndexArray";
            }>>;
        }, z.core.$strict>, z.ZodObject<{
            id: z.ZodString;
            version: z.ZodOptional<z.ZodInt>;
            prompt: z.ZodString;
            response: z.ZodLiteral<"orderedTextBlanks">;
            blankCount: z.ZodInt;
            options: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodNever>>;
        }, z.core.$strict>, z.ZodObject<{
            id: z.ZodString;
            version: z.ZodOptional<z.ZodInt>;
            prompt: z.ZodString;
            response: z.ZodLiteral<"textWithOptionalTitle">;
            options: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodNever>>;
        }, z.core.$strict>], "response">>>;
        questionAnswerRules: z.ZodOptional<z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>>, z.ZodTransform<{
            [k: string]: {
                id: string;
                version: number;
            };
        }, Record<string, {
            id: string;
            version: number;
        }>>>>;
        steps: z.ZodTuple<[z.ZodObject<{
            id: z.ZodString;
            requires: z.ZodOptional<z.ZodString>;
            instructions: z.ZodString;
            tool: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>;
            inputs: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
                from: z.ZodLiteral<"material">;
                positionId: z.ZodString;
                material: z.ZodOptional<z.ZodObject<{
                    id: z.ZodString;
                    version: z.ZodInt;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                from: z.ZodLiteral<"questions">;
            }, z.core.$strict>, z.ZodObject<{
                stepId: z.ZodString;
                slotId: z.ZodString;
                from: z.ZodLiteral<"submission">;
                readOnly: z.ZodLiteral<true>;
            }, z.core.$strict>], "from">>;
            submit: z.ZodObject<{
                purpose: z.ZodEnum<{
                    finalAnswer: "finalAnswer";
                    stepEvidence: "stepEvidence";
                }>;
                slots: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
                    source: z.ZodString;
                    targetId: z.ZodString;
                    type: z.ZodLiteral<"passageSelection">;
                    oneRangePerRole: z.ZodRecord<z.ZodString, z.ZodString>;
                    distinctParagraphs: z.ZodBoolean;
                    evidenceUnit: z.ZodLiteral<"wholeSelection">;
                }, z.core.$strict>, z.ZodObject<{
                    source: z.ZodString;
                    targetId: z.ZodString;
                    type: z.ZodLiteral<"oneChoicePerQuestion">;
                    reasonTargetId: z.ZodOptional<z.ZodString>;
                    confirmFromDrafts: z.ZodOptional<z.ZodObject<{
                        allowUnanswered: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>, z.ZodObject<{
                    source: z.ZodString;
                    targetId: z.ZodString;
                    type: z.ZodLiteral<"oneResponsePerQuestion">;
                    input: z.ZodEnum<{
                        booleanOrString: "booleanOrString";
                        optionIndexArray: "optionIndexArray";
                    }>;
                    confirmFromDrafts: z.ZodObject<{
                        allowUnanswered: z.ZodBoolean;
                    }, z.core.$strict>;
                }, z.core.$strict>, z.ZodObject<{
                    source: z.ZodString;
                    targetId: z.ZodString;
                    type: z.ZodLiteral<"questionDelivery">;
                    delivery: z.ZodDiscriminatedUnion<[z.ZodObject<{
                        mode: z.ZodLiteral<"whole">;
                    }, z.core.$strict>, z.ZodObject<{
                        mode: z.ZodLiteral<"perQuestion">;
                        questionSlots: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodString>, z.ZodTransform<{
                            [k: string]: string;
                        }, Record<string, string>>>;
                    }, z.core.$strict>], "mode">;
                    confirmFromDrafts: z.ZodObject<{
                        allowUnanswered: z.ZodBoolean;
                    }, z.core.$strict>;
                }, z.core.$strict>, z.ZodObject<{
                    type: z.ZodLiteral<"reuse">;
                    source: z.ZodString;
                }, z.core.$strict>], "type">>;
            }, z.core.$strict>;
            afterConfirmation: z.ZodEnum<{
                advance: "advance";
                finish: "finish";
            }>;
        }, z.core.$strict>], z.ZodObject<{
            id: z.ZodString;
            requires: z.ZodOptional<z.ZodString>;
            instructions: z.ZodString;
            tool: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>;
            inputs: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
                from: z.ZodLiteral<"material">;
                positionId: z.ZodString;
                material: z.ZodOptional<z.ZodObject<{
                    id: z.ZodString;
                    version: z.ZodInt;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                from: z.ZodLiteral<"questions">;
            }, z.core.$strict>, z.ZodObject<{
                stepId: z.ZodString;
                slotId: z.ZodString;
                from: z.ZodLiteral<"submission">;
                readOnly: z.ZodLiteral<true>;
            }, z.core.$strict>], "from">>;
            submit: z.ZodObject<{
                purpose: z.ZodEnum<{
                    finalAnswer: "finalAnswer";
                    stepEvidence: "stepEvidence";
                }>;
                slots: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
                    source: z.ZodString;
                    targetId: z.ZodString;
                    type: z.ZodLiteral<"passageSelection">;
                    oneRangePerRole: z.ZodRecord<z.ZodString, z.ZodString>;
                    distinctParagraphs: z.ZodBoolean;
                    evidenceUnit: z.ZodLiteral<"wholeSelection">;
                }, z.core.$strict>, z.ZodObject<{
                    source: z.ZodString;
                    targetId: z.ZodString;
                    type: z.ZodLiteral<"oneChoicePerQuestion">;
                    reasonTargetId: z.ZodOptional<z.ZodString>;
                    confirmFromDrafts: z.ZodOptional<z.ZodObject<{
                        allowUnanswered: z.ZodBoolean;
                    }, z.core.$strict>>;
                }, z.core.$strict>, z.ZodObject<{
                    source: z.ZodString;
                    targetId: z.ZodString;
                    type: z.ZodLiteral<"oneResponsePerQuestion">;
                    input: z.ZodEnum<{
                        booleanOrString: "booleanOrString";
                        optionIndexArray: "optionIndexArray";
                    }>;
                    confirmFromDrafts: z.ZodObject<{
                        allowUnanswered: z.ZodBoolean;
                    }, z.core.$strict>;
                }, z.core.$strict>, z.ZodObject<{
                    source: z.ZodString;
                    targetId: z.ZodString;
                    type: z.ZodLiteral<"questionDelivery">;
                    delivery: z.ZodDiscriminatedUnion<[z.ZodObject<{
                        mode: z.ZodLiteral<"whole">;
                    }, z.core.$strict>, z.ZodObject<{
                        mode: z.ZodLiteral<"perQuestion">;
                        questionSlots: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodString>, z.ZodTransform<{
                            [k: string]: string;
                        }, Record<string, string>>>;
                    }, z.core.$strict>], "mode">;
                    confirmFromDrafts: z.ZodObject<{
                        allowUnanswered: z.ZodBoolean;
                    }, z.core.$strict>;
                }, z.core.$strict>, z.ZodObject<{
                    type: z.ZodLiteral<"reuse">;
                    source: z.ZodString;
                }, z.core.$strict>], "type">>;
            }, z.core.$strict>;
            afterConfirmation: z.ZodEnum<{
                advance: "advance";
                finish: "finish";
            }>;
        }, z.core.$strict>>;
        grading: z.ZodDefault<z.ZodObject<{
            selectionFeedback: z.ZodOptional<z.ZodObject<{
                from: z.ZodObject<{
                    stepId: z.ZodString;
                    slotId: z.ZodString;
                }, z.core.$strict>;
                criterion: z.ZodString;
            }, z.core.$strict>>;
            assessment: z.ZodOptional<z.ZodObject<{
                from: z.ZodObject<{
                    stepId: z.ZodString;
                    slotId: z.ZodString;
                }, z.core.$strict>;
                evaluator: z.ZodObject<{
                    id: z.ZodString;
                    version: z.ZodInt;
                }, z.core.$strict>;
                keyRef: z.ZodObject<{
                    id: z.ZodString;
                    version: z.ZodInt;
                }, z.core.$strict>;
                unit: z.ZodLiteral<"question">;
                effectiveVerdictOrder: z.ZodTuple<[z.ZodLiteral<"teacherReview">, z.ZodLiteral<"automatic">], null>;
            }, z.core.$strict>>;
            manualReview: z.ZodOptional<z.ZodObject<{
                keyRef: z.ZodObject<{
                    id: z.ZodString;
                    version: z.ZodInt;
                }, z.core.$strict>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        policy: z.ZodObject<{
            timeLimit: z.ZodOptional<z.ZodObject<{
                minutes: z.ZodInt;
                startsAt: z.ZodLiteral<"instanceStarted">;
                onDeadline: z.ZodLiteral<"keepDraftAndClose">;
            }, z.core.$strict>>;
            offline: z.ZodLiteral<"onlineOnly">;
            redo: z.ZodLiteral<"newInstanceOnAuthorization">;
            student: z.ZodObject<{
                ownSubmission: z.ZodObject<{
                    scope: z.ZodLiteral<"ownConfirmedSubmissions">;
                    fields: z.ZodArray<z.ZodEnum<{
                        ownChoices: "ownChoices";
                        ownResponses: "ownResponses";
                        receipt: "receipt";
                        submittedQuotes: "submittedQuotes";
                    }>>;
                    onFinal: z.ZodArray<z.ZodLiteral<"passageGradingStatus">>;
                }, z.core.$strict>;
                passageScore: z.ZodOptional<z.ZodObject<{
                    whenAll: z.ZodTuple<[z.ZodLiteral<"finalConfirmed">, z.ZodLiteral<"allQuestionsJudged">], null>;
                    group: z.ZodLiteral<"wholePassage">;
                    fields: z.ZodArray<z.ZodEnum<{
                        correctCount: "correctCount";
                        questionCount: "questionCount";
                    }>>;
                    allowSubsets: z.ZodLiteral<false>;
                    drilldown: z.ZodLiteral<false>;
                }, z.core.$strict>>;
                review: z.ZodOptional<z.ZodObject<{
                    requires: z.ZodLiteral<"passageScore">;
                    while: z.ZodLiteral<"reviewOpen">;
                    byQuestion: z.ZodArray<z.ZodLiteral<"effectiveVerdict">>;
                    byQuoteSet: z.ZodArray<z.ZodLiteral<"learnerFeedback">>;
                }, z.core.$strict>>;
            }, z.core.$strict>;
            reviewer: z.ZodObject<{
                scope: z.ZodLiteral<"assignedReviewer">;
                fields: z.ZodArray<z.ZodEnum<{
                    gradingBasis: "gradingBasis";
                    learnerFeedback: "learnerFeedback";
                    studentChoices: "studentChoices";
                    submittedQuotes: "submittedQuotes";
                    verdictHistory: "verdictHistory";
                }>>;
                actions: z.ZodArray<z.ZodEnum<{
                    commentOnQuotes: "commentOnQuotes";
                    reviseQuestionVerdict: "reviseQuestionVerdict";
                }>>;
            }, z.core.$strict>;
            manager: z.ZodObject<{
                scope: z.ZodLiteral<"assigningTeacher">;
                actions: z.ZodArray<z.ZodEnum<{
                    authorizeRedo: "authorizeRedo";
                    closeReview: "closeReview";
                    openReview: "openReview";
                }>>;
            }, z.core.$strict>;
            externalAi: z.ZodLiteral<"disabled">;
        }, z.core.$strict>;
    }, z.core.$strict>;
    scoringKey: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        acceptedChoices: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodString>, z.ZodTransform<{
            [k: string]: string;
        }, Record<string, string>>>;
    }, z.core.$strict>, z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        acceptedResponses: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodBoolean>, z.ZodTransform<{
            [k: string]: boolean;
        }, Record<string, boolean>>>;
    }, z.core.$strict>, z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        acceptedIndexes: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodInt>>, z.ZodTransform<{
            [k: string]: number[];
        }, Record<string, number[]>>>;
    }, z.core.$strict>, z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        acceptedByQuestion: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
            response: z.ZodLiteral<"choice">;
            acceptedChoice: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            response: z.ZodLiteral<"booleanOrString">;
            acceptedResponse: z.ZodBoolean;
        }, z.core.$strict>, z.ZodObject<{
            response: z.ZodLiteral<"optionIndexArray">;
            acceptedIndexes: z.ZodArray<z.ZodInt>;
        }, z.core.$strict>, z.ZodObject<{
            response: z.ZodLiteral<"orderedTextBlanks">;
            acceptedBlanks: z.ZodArray<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            response: z.ZodLiteral<"textWithOptionalTitle">;
        }, z.core.$strict>], "response">>, z.ZodTransform<{
            [k: string]: {
                response: "choice";
                acceptedChoice: string;
            } | {
                response: "booleanOrString";
                acceptedResponse: boolean;
            } | {
                response: "optionIndexArray";
                acceptedIndexes: number[];
            } | {
                response: "orderedTextBlanks";
                acceptedBlanks: string[][];
            } | {
                response: "textWithOptionalTitle";
            };
        }, Record<string, {
            response: "choice";
            acceptedChoice: string;
        } | {
            response: "booleanOrString";
            acceptedResponse: boolean;
        } | {
            response: "optionIndexArray";
            acceptedIndexes: number[];
        } | {
            response: "orderedTextBlanks";
            acceptedBlanks: string[][];
        } | {
            response: "textWithOptionalTitle";
        }>>>;
    }, z.core.$strict>, z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        reviewCriteria: z.ZodString;
    }, z.core.$strict>]>>;
}, z.core.$strict>;
export type ReadingPublication = z.infer<typeof readingPublicationSchema>;
export type ReadingStep = z.infer<typeof step>;
export type ReadingSlot = z.infer<typeof slot>;
export {};
