import { z } from "zod";
import { choiceConfirmationInput, confirmationKey } from "./contracts/choice-confirmation.js";
import { choiceDraftAmendmentInput } from "./contracts/choice-amendment.js";
import { choiceDraftScope, choiceDraftInput, currentChoiceDraftMode } from "./contracts/choice-draft.js";
import { choiceSnapshotRevisionInput } from "./contracts/choice-snapshot.js";
import { questionDeliveryDraftInput, questionDeliveryInput, questionDeliveryReviewMode } from "./contracts/question-delivery.js";
import { questionDeliveryAmendmentScope, questionDeliveryDraftAmendmentInput, questionDeliverySnapshotRevisionInput, } from "./contracts/question-delivery-amendment.js";
import { selfAssessmentInput } from "./contracts/self-assessment.js";
import { frozenConfirmationVerdictMode, verdictCommand } from "./contracts/verdict.js";
import { preparedVersionInput } from "./contracts/prepared-activity.js";
import { id, publicationSchema, restartInput, startInput, versionRef } from "./contracts/reading.js";
import { readingPublicationSchema } from "./contracts/reading-publication.js";
import { responseDraftInput } from "./contracts/response.js";
import { defaultEvaluators, defaultResponseTypes, defaultTools } from "./extensions/index.js";
import { startActivity } from "./kernel/activity.js";
import { restartActivity } from "./kernel/activity-restart.js";
import { amendChoiceDraft, readChoiceDraftForAmendment } from "./kernel/choice-amendment.js";
import { confirmChoices, recoverChoiceConfirmation } from "./kernel/choice-confirmation.js";
import { readChoiceDraftActivity } from "./kernel/choice-draft-activity.js";
import { saveChoiceDraft, saveCurrentChoiceDraft } from "./kernel/choice-drafts.js";
import { reviseChoiceSnapshot } from "./kernel/choice-snapshot.js";
import { openDatabase, readTransaction } from "./kernel/database.js";
import { LearningError } from "./contracts/learning-error.js";
import { replacePreparedActivityVersion } from "./kernel/prepared-activity.js";
import { confirmQuestionDelivery, recoverQuestionDelivery } from "./kernel/question-delivery-confirmation.js";
import { readChoiceConfirmationVerdicts, readQuestionDeliveryReview, readQuestionDeliveryVerdicts, readResponseConfirmationVerdicts, writeQuestionDeliveryVerdict, } from "./kernel/question-delivery-review.js";
import { saveQuestionDeliveryDraft } from "./kernel/question-delivery-drafts.js";
import { amendQuestionDeliveryDraft, readQuestionDeliveryDraftForAmendment } from "./kernel/question-delivery-amendment.js";
import { reviseQuestionDeliverySnapshot } from "./kernel/question-delivery-snapshot.js";
import { registerPublication } from "./kernel/publication.js";
import { evaluatePending } from "./kernel/pending-evaluation.js";
import { createRegistry } from "./kernel/registry.js";
import { readingEntries } from "./runtime/reading.js";
import { confirmResponses, recoverResponseConfirmation } from "./kernel/response-confirmation.js";
import { saveResponseDraft } from "./kernel/response-drafts.js";
import { assessSelf, readSelfAssessments } from "./kernel/self-assessment.js";
import { readActivity } from "./kernel/submission.js";
const callable = () => z.custom(value => typeof value === "function");
const evaluatorShape = versionRef.extend({ responseTypes: z.array(id).min(1), evaluate: callable() });
const evaluatorRegistration = z.custom(value => evaluatorShape.safeParse(value).success);
const answerRuleShape = versionRef.extend({ responseType: id, isAnswered: callable() });
const answerRuleRegistration = z.custom(value => answerRuleShape.safeParse(value).success);
const optionalCallable = z.custom(value => value === undefined || typeof value === "function");
const responseTypeShape = versionRef.extend({
    config: z.array(id), validateQuestion: callable(), parseValue: callable(), isAnswered: callable(),
    parseKey: optionalCallable, wholePaperKey: z.strictObject({ field: id, toKey: callable() }).optional(),
});
const responseTypeRegistration = z.custom(value => responseTypeShape.safeParse(value).success, "作答形态须经 defineResponseType 定义");
const toolRegistration = z.custom(value => typeof value === "object" && value !== null && Array.isArray(Reflect.get(value, "outputs")));
const runtimeOptions = z.strictObject({
    databasePath: z.string().min(1),
    tools: z.array(toolRegistration).default([]),
    responseTypes: z.array(responseTypeRegistration).default([]),
    evaluators: z.array(evaluatorRegistration).default([]),
    questionAnswerRules: z.array(answerRuleRegistration).default([]),
    authorizeChoiceDraftAmendment: z.custom(value => typeof value === "function").optional(),
    authorizeChoiceSnapshotRevision: z.custom(value => typeof value === "function").optional(),
    hasChoiceSnapshotEvidence: z.custom(value => typeof value === "function").optional(),
    verifyOriginal: z.custom(value => typeof value === "function").optional(),
    authorizeConfirmationRecovery: z.custom(value => typeof value === "function").optional(),
    authorizeReview: z.custom(value => typeof value === "function").optional(),
    clock: callable().optional(),
    checkpoint: callable().optional(),
});
const studentPrincipal = z.strictObject({ role: z.literal("student"), id });
const reviewerPrincipal = z.strictObject({ role: z.literal("reviewer"), id });
const publishedStartInput = startInput.extend({ practiceVersion: versionRef.shape.version });
const uuid = z.uuid();
const recoveryMode = z.literal("declared").optional();
const verdictMode = frozenConfirmationVerdictMode.optional();
export { LearningError };
export { verifyActivityBindings } from "./kernel/activity-bindings.js";
export { defineResponseType } from "./contracts/response-type.js";
export { defaultEvaluators, defaultResponseTypes, defaultTools } from "./extensions/index.js";
export { QuestionDeliveryConflict } from "./kernel/question-delivery-drafts.js";
export { ChoiceConfirmationConflict } from "./kernel/choice-confirmation.js";
export { ChoiceSnapshotRevisionConflict } from "./kernel/choice-snapshot.js";
export { ChoiceDraftConflict } from "./kernel/choice-drafts.js";
export { ResponseConfirmationConflict } from "./kernel/response-confirmation.js";
export { ResponseDraftConflict } from "./kernel/response-drafts.js";
function principalId(schema, principal) {
    const parsed = schema.safeParse(principal);
    if (!parsed.success)
        throw new LearningError(403, "FORBIDDEN");
    return parsed.data.id;
}
export function openLearningRuntime(options) {
    const settings = runtimeOptions.parse(options);
    const registry = createRegistry({
        tools: [...defaultTools, ...settings.tools],
        responseTypes: [...defaultResponseTypes, ...settings.responseTypes],
        evaluators: [...defaultEvaluators, ...settings.evaluators],
        answerRules: settings.questionAnswerRules,
    });
    const database = openDatabase(settings.databasePath);
    const clock = settings.clock ?? (() => new Date());
    function recoverDelivery(principal, activityId, key, input) {
        const mode = recoveryMode.parse(input);
        const recovered = recoverQuestionDelivery(database, principalId(studentPrincipal, principal), uuid.parse(activityId), confirmationKey.parse(key), settings.authorizeConfirmationRecovery, mode ?? "automatic");
        if (mode === "declared" || recovered.assessment !== "automatic")
            return recovered;
        const { assessment: _assessment, ...legacy } = recovered;
        return legacy;
    }
    function readDeliveryReview(principal, activityId, key, input) {
        const mode = questionDeliveryReviewMode.parse(input);
        const reviewerId = principalId(reviewerPrincipal, principal);
        const activity = uuid.parse(activityId);
        const confirmation = confirmationKey.parse(key);
        if (mode === "choiceConfirmation")
            return readChoiceConfirmationVerdicts(database, reviewerId, activity, confirmation, settings.authorizeReview);
        if (mode === "responseConfirmation")
            return readResponseConfirmationVerdicts(database, reviewerId, activity, confirmation, settings.authorizeReview);
        const read = mode === "verdicts" ? readQuestionDeliveryVerdicts : readQuestionDeliveryReview;
        return read(database, reviewerId, activity, confirmation, settings.authorizeReview);
    }
    return {
        ...readingEntries({ database, registry, clock, checkpoint: settings.checkpoint }),
        publish(input) {
            registerPublication(database, input, registry);
        },
        start(principal, input) {
            return startActivity(database, principalId(studentPrincipal, principal), publishedStartInput.parse(input), clock);
        },
        prepare(principal, input) {
            return startActivity(database, principalId(studentPrincipal, principal), publishedStartInput.parse(input), clock, undefined, "prepare");
        },
        restart(principal, activityId, input) {
            return restartActivity(database, principalId(studentPrincipal, principal), uuid.parse(activityId), restartInput.parse(input), clock);
        },
        replacePreparedActivityVersion(principal, activityId, input) {
            return replacePreparedActivityVersion(database, principalId(studentPrincipal, principal), uuid.parse(activityId), preparedVersionInput.parse(input));
        },
        read(principal, activityId) {
            return readTransaction(database, () => readActivity(database, principalId(studentPrincipal, principal), uuid.parse(activityId)));
        },
        readChoiceDraftActivity(principal, activityId) {
            return readChoiceDraftActivity(database, principalId(studentPrincipal, principal), uuid.parse(activityId));
        },
        saveChoiceDraft(principal, activityId, input) {
            return saveChoiceDraft(database, registry, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceDraftInput.parse(input), clock);
        },
        saveCurrentChoiceDraft(principal, activityId, input, mode = "save") {
            return saveCurrentChoiceDraft(database, registry, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceDraftInput.parse(input), currentChoiceDraftMode.parse(mode), clock);
        },
        readChoiceDraftForAmendment(principal, activityId, scope) {
            return readChoiceDraftForAmendment(database, principalId(reviewerPrincipal, principal), uuid.parse(activityId), choiceDraftScope.parse(scope), settings.authorizeChoiceDraftAmendment);
        },
        amendChoiceDraft(principal, activityId, input) {
            return amendChoiceDraft(database, principalId(reviewerPrincipal, principal), uuid.parse(activityId), choiceDraftAmendmentInput.parse(input), clock, settings.authorizeChoiceDraftAmendment);
        },
        reviseChoiceSnapshot(principal, activityId, input) {
            return reviseChoiceSnapshot(database, principalId(reviewerPrincipal, principal), uuid.parse(activityId), choiceSnapshotRevisionInput.parse(input), clock, {
                authorize: settings.authorizeChoiceSnapshotRevision, hasEvidence: settings.hasChoiceSnapshotEvidence,
            });
        },
        confirmChoices(principal, activityId, input) {
            return confirmChoices(database, registry, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceConfirmationInput.parse(input), clock, settings.verifyOriginal);
        },
        recoverChoiceConfirmation(principal, activityId, key) {
            return recoverChoiceConfirmation(database, principalId(studentPrincipal, principal), uuid.parse(activityId), confirmationKey.parse(key), settings.authorizeConfirmationRecovery);
        },
        saveResponseDraft(principal, activityId, input, mode = "save") {
            return saveResponseDraft(database, registry, principalId(studentPrincipal, principal), uuid.parse(activityId), responseDraftInput.parse(input), currentChoiceDraftMode.parse(mode), clock);
        },
        confirmResponses(principal, activityId, input) {
            return confirmResponses(database, registry, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceConfirmationInput.parse(input), clock, settings.verifyOriginal);
        },
        recoverResponseConfirmation(principal, activityId, key) {
            return recoverResponseConfirmation(database, principalId(studentPrincipal, principal), uuid.parse(activityId), confirmationKey.parse(key), settings.authorizeConfirmationRecovery);
        },
        saveQuestionDeliveryDraft(principal, activityId, input, mode = "save") {
            return saveQuestionDeliveryDraft(database, registry, principalId(studentPrincipal, principal), uuid.parse(activityId), questionDeliveryDraftInput.parse(input), currentChoiceDraftMode.parse(mode), clock);
        },
        confirmQuestionDelivery(principal, activityId, input) {
            return confirmQuestionDelivery(database, registry, principalId(studentPrincipal, principal), uuid.parse(activityId), questionDeliveryInput.parse(input), clock, settings.verifyOriginal, settings.authorizeConfirmationRecovery);
        },
        readQuestionDeliveryDraftForAmendment(principal, activityId, scope) {
            return readQuestionDeliveryDraftForAmendment(database, registry, principalId(reviewerPrincipal, principal), uuid.parse(activityId), questionDeliveryAmendmentScope.parse(scope), settings.authorizeChoiceDraftAmendment);
        },
        amendQuestionDeliveryDraft(principal, activityId, input) {
            return amendQuestionDeliveryDraft(database, registry, principalId(reviewerPrincipal, principal), uuid.parse(activityId), questionDeliveryDraftAmendmentInput.parse(input), clock, settings.authorizeChoiceDraftAmendment);
        },
        reviseQuestionDeliverySnapshot(principal, activityId, input) {
            return reviseQuestionDeliverySnapshot(database, registry, principalId(reviewerPrincipal, principal), uuid.parse(activityId), questionDeliverySnapshotRevisionInput.parse(input), clock, {
                authorize: settings.authorizeChoiceSnapshotRevision, hasEvidence: settings.hasChoiceSnapshotEvidence,
            });
        },
        recoverQuestionDelivery: recoverDelivery,
        readQuestionDeliveryReview: readDeliveryReview,
        writeQuestionDeliveryVerdict(principal, activityId, key, command, input) {
            return writeQuestionDeliveryVerdict(database, principalId(reviewerPrincipal, principal), uuid.parse(activityId), confirmationKey.parse(key), verdictCommand.parse(command), settings.authorizeReview, clock, verdictMode.parse(input));
        },
        selfAssess(principal, activityId, key, input) {
            return assessSelf(database, principalId(studentPrincipal, principal), uuid.parse(activityId), confirmationKey.parse(key), selfAssessmentInput.parse(input), clock);
        },
        readSelfAssessments(principal, activityId, key) {
            return readSelfAssessments(database, principalId(studentPrincipal, principal), uuid.parse(activityId), confirmationKey.parse(key));
        },
        evaluatePending(scope) {
            return evaluatePending(database, registry, settings.checkpoint, scope && uuid.parse(scope.submissionId));
        },
        close() {
            database.close();
        },
    };
}
