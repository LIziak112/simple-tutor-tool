import { z } from "zod";
export declare const selfAssessmentScoring: z.ZodEnum<{
    countAsCorrect: "countAsCorrect";
    separate: "separate";
}>;
export declare const selfAssessmentPolicy: z.ZodObject<{
    scoring: z.ZodEnum<{
        countAsCorrect: "countAsCorrect";
        separate: "separate";
    }>;
}, z.core.$strict>;
export declare const selfAssessmentVerdict: z.ZodEnum<{
    correct: "correct";
    wrong: "wrong";
}>;
export declare const selfAssessmentRubric: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
export declare const selfAssessmentInput: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
    questionId: z.ZodString;
    expectedRevision: z.ZodInt;
    verdict: z.ZodNullable<z.ZodEnum<{
        correct: "correct";
        wrong: "wrong";
    }>>;
    rubric: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>>;
}, z.core.$strict>;
export declare const selfAssessmentReceipt: z.ZodObject<{
    id: z.ZodUUID;
    submissionId: z.ZodUUID;
    questionId: z.ZodString;
    revision: z.ZodInt;
    verdict: z.ZodNullable<z.ZodEnum<{
        correct: "correct";
        wrong: "wrong";
    }>>;
    rubric: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>>;
}, z.core.$strict>;
export type SelfAssessmentScoring = z.infer<typeof selfAssessmentScoring>;
export type SelfAssessmentVerdict = z.infer<typeof selfAssessmentVerdict>;
export type SelfAssessmentInput = z.infer<typeof selfAssessmentInput>;
export type SelfAssessmentReceipt = z.infer<typeof selfAssessmentReceipt>;
