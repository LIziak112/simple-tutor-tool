import type { DatabaseSync } from "node:sqlite";
import { questionDeliveryView } from "../contracts/question-delivery.ts";
import type { ChoiceConfirmation } from "../contracts/choice-confirmation.ts";
import type { ResponseConfirmation } from "../contracts/response.ts";
import type { StudentValue } from "../contracts/capabilities.ts";
import type { Material, SubmitInput, VersionRef } from "../contracts/reading.ts";
import type { ReadingStep } from "../contracts/reading-publication.ts";
import type { ReadingAnswer, ReadingAnswerInput, ReadingSaveInput, ReadingSelection } from "../contracts/reading-runtime.ts";
import type { ReadingActivity } from "./activity.ts";
import type { Registry } from "./registry.ts";
import type { RuntimeCheckpoint } from "./runtime-checkpoint.ts";
import type { StoredSubmission } from "./submission-store.ts";
export declare function boundOutput(step: ReadingStep, slotId: string): {
    source: string;
    targetId: string;
    type: "passageSelection";
    oneRangePerRole: Record<string, string>;
    distinctParagraphs: boolean;
    evidenceUnit: "wholeSelection";
} | {
    source: string;
    targetId: string;
    type: "oneChoicePerQuestion";
    reasonTargetId?: string | undefined;
    confirmFromDrafts?: {
        allowUnanswered: boolean;
    } | undefined;
} | {
    source: string;
    targetId: string;
    type: "oneResponsePerQuestion";
    input: string;
    confirmFromDrafts: {
        allowUnanswered: boolean;
    };
} | {
    source: string;
    targetId: string;
    type: "questionDelivery";
    delivery: {
        mode: "whole";
    } | {
        mode: "perQuestion";
        questionSlots: {
            [k: string]: string;
        };
    };
    confirmFromDrafts: {
        allowUnanswered: boolean;
    };
};
export declare function requireAvailableTool(registry: Registry, step: {
    tool: VersionRef;
}, output: StudentValue): void;
export declare function writableOutput(registry: Registry, step: ReadingStep, slotId: string): {
    source: string;
    targetId: string;
    type: "passageSelection";
    oneRangePerRole: Record<string, string>;
    distinctParagraphs: boolean;
    evidenceUnit: "wholeSelection";
} | {
    source: string;
    targetId: string;
    type: "oneChoicePerQuestion";
    reasonTargetId?: string | undefined;
    confirmFromDrafts?: {
        allowUnanswered: boolean;
    } | undefined;
} | {
    source: string;
    targetId: string;
    type: "oneResponsePerQuestion";
    input: string;
    confirmFromDrafts: {
        allowUnanswered: boolean;
    };
} | {
    source: string;
    targetId: string;
    type: "questionDelivery";
    delivery: {
        mode: "whole";
    } | {
        mode: "perQuestion";
        questionSlots: {
            [k: string]: string;
        };
    };
    confirmFromDrafts: {
        allowUnanswered: boolean;
    };
};
export declare function saveReadingSelection(database: DatabaseSync, registry: Registry, activity: ReadingActivity, input: ReadingSaveInput): {
    draft: {
        id: string;
        version: number;
    };
    selection: {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        ranges: {
            role: string;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
            text: string;
        }[];
    };
};
export declare function saveReadingAnswer(database: DatabaseSync, registry: Registry, activity: ReadingActivity, input: ReadingAnswerInput): {
    draft: {
        id: string;
        version: number;
    };
    answer: {
        choices: Record<string, string>;
        references: Record<string, string>;
        reason?: {
            text: string;
            independent: boolean;
        } | undefined;
    };
};
export declare function confirmReadingDraft(database: DatabaseSync, registry: Registry, activity: ReadingActivity, input: SubmitInput, clock: () => Date, checkpoint?: RuntimeCheckpoint): {
    id: string;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export declare function requireBeforeDeadline(activity: ReadingActivity, confirmedAt: Date): void;
export declare function readingStatus({ completed, abandoned }: ReadingActivity): "abandoned" | "active" | "completed";
export declare function readingActivityView(database: DatabaseSync, activity: ReadingActivity, submissions: StoredSubmission[]): {
    assessment?: (ReturnType<(score: NonNullable<{
        whenAll: ["finalConfirmed", "allQuestionsJudged"];
        group: "wholePassage";
        fields: ("correctCount" | "questionCount")[];
        allowSubsets: false;
        drilldown: false;
    } | undefined>, result: {
        questionCount: number;
        correctCount: number;
    }) => {
        status: "complete";
    }> & {
        selfAssessment?: {
            scoring: import("../server.ts").SelfAssessmentScoring;
            judgedCorrect: number;
            selfAssessedCorrect: number;
            selfAssessedWrong: number;
        };
    }) | {
        status: "pending";
    };
    review?: undefined;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: string;
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "abandoned" | "active" | "completed";
    inputs: {
        [k: string]: ReadingInputView;
    };
    submission: StudentSubmissionView | undefined;
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: string;
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "abandoned" | "active" | "completed";
    inputs: {
        [k: string]: ReadingInputView;
    };
    submission: StudentSubmissionView | undefined;
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: string;
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "abandoned" | "active" | "completed";
    inputs: {
        [k: string]: ReadingInputView;
    };
    submission: StudentSubmissionView | undefined;
};
type StudentSubmissionView = {
    receipt?: StoredSubmission["receipt"];
    confirmation?: ChoiceConfirmation;
    responseConfirmation?: ResponseConfirmation;
    questionDelivery?: ReturnType<typeof questionDeliveryView>;
    selection?: ReadingSelection;
    answer?: Omit<ReadingAnswer, "references"> & {
        references?: ReadingAnswer["references"];
    };
};
type ReadingInputView = {
    from: "material";
    positionId: string;
    material?: Material;
} | {
    from: "questions";
    questions: ReadingActivity["practice"]["questions"];
} | ({
    from: "submission";
} & StudentSubmissionView);
export declare function studentSubmissionView(activity: ReadingActivity, submitted: StoredSubmission): StudentSubmissionView;
export declare function readingSubmissionView(submitted: StoredSubmission): {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    selection: {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        ranges: {
            role: string;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
            text: string;
        }[];
    };
    answer?: never;
} | {
    selection?: never;
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    answer: {
        choices: Record<string, string>;
        references: Record<string, string>;
        reason?: {
            text: string;
            independent: boolean;
        } | undefined;
    };
};
export {};
