import { readQuestionDelivery } from "../contracts/question-delivery.js";
import { confirmedDeliveryAssessment } from "./question-delivery-evaluation.js";
import { questionDeliverySlot } from "./question-delivery-publication.js";
import { reviewDisclosure } from "./review-access.js";
import { currentSelfAssessments, selfAssessmentCounts, selfAssessmentScoring, selfReviewQuestionIds } from "./self-assessment.js";
import { activitySubmissions } from "./submission-store.js";
import { assessmentTarget, questionVerdicts, questionVerdictStates, submissionReviewTarget } from "./verdict-state.js";
export function studentResults(database, activity) {
    const policy = activity.practice.policy.student;
    const delivery = questionDeliverySlot(activity.step);
    if (delivery)
        return deliveryResults(database, activity, policy, delivery[1].targetId);
    const target = assessmentTarget(database, activity.activityId);
    if (!target || !policy.passageScore)
        return {};
    const pending = policy.ownSubmission.onFinal.includes("passageGradingStatus") ? { status: "pending" } : undefined;
    if (target.status !== "done")
        return { assessment: pending };
    const graded = questionVerdicts(database, activity, target).flatMap(({ questionId, effective }) => effective ? [{ questionId, correct: effective.correct }] : []);
    if (graded.length !== activity.practice.questions.length)
        return { assessment: pending };
    return {
        assessment: passageAssessment(policy.passageScore, graded),
        review: policy.review && studentReview(database, activity.activityId, policy.review, graded),
    };
}
function passageAssessment(score, graded) {
    return scoreFields(score, { questionCount: graded.length, correctCount: graded.filter(item => item.correct).length });
}
function scoreFields(score, result) {
    return { status: "complete", ...Object.fromEntries(score.fields.map(field => [field, result[field]])) };
}
function deliveryResults(database, activity, policy, targetId) {
    if (!activity.completed || !policy.passageScore)
        return {};
    const routed = selfReviewQuestionIds(activity);
    const entries = activitySubmissions(database, activity.activityId).flatMap(({ receipt, content }) => {
        const delivered = readQuestionDelivery(content);
        const target = delivered && submissionReviewTarget(database, receipt.id, targetId);
        if (!delivered || !target)
            return [];
        const { automatic, review } = confirmedDeliveryAssessment(activity, delivered);
        const current = currentSelfAssessments(database, receipt.id);
        return questionVerdictStates(database, target, [...automatic, ...review]).map(({ questionId, effective }) => ({
            ...effective && { effective }, self: routed.has(questionId) ? current.get(questionId)?.verdict ?? null : null,
        }));
    });
    if (entries.filter(({ effective, self }) => effective || self).length !== activity.practice.questions.length) {
        return policy.ownSubmission.onFinal.includes("passageGradingStatus") ? { assessment: { status: "pending" } } : {};
    }
    const scoring = selfAssessmentScoring(activity);
    if (!scoring) {
        const correctCount = entries.filter(({ effective }) => effective?.correct).length;
        return { assessment: scoreFields(policy.passageScore, { questionCount: entries.length, correctCount }) };
    }
    const { questionCount, correctCount, judgedCorrect, selfAssessedCorrect, selfAssessedWrong } = selfAssessmentCounts(scoring, entries);
    return {
        assessment: {
            ...scoreFields(policy.passageScore, { questionCount, correctCount }),
            selfAssessment: { scoring, judgedCorrect, selfAssessedCorrect, selfAssessedWrong },
        },
    };
}
function studentReview(database, activityId, policy, graded) {
    const disclosure = reviewDisclosure(database, activityId);
    if (!disclosure?.reviewOpen)
        return undefined;
    const byQuestion = policy.byQuestion.includes("effectiveVerdict") ? graded : undefined;
    const selectionFeedback = policy.byQuoteSet.includes("learnerFeedback") ? disclosure.feedback ?? undefined : undefined;
    if (!byQuestion && !selectionFeedback)
        return undefined;
    return { byQuestion, selectionFeedback };
}
