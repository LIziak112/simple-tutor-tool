import { readChoiceConfirmation } from "../contracts/choice-confirmation.js";
import { LearningError } from "../contracts/learning-error.js";
import { questionDeliveryView, readQuestionDelivery } from "../contracts/question-delivery.js";
import { readResponseConfirmation } from "../contracts/response.js";
import { loadActivity } from "./activity.js";
import { readTransaction, writeTransaction } from "./database.js";
import { confirmedWorkForOperation } from "./question-confirmation.js";
import { requireQuestionDeliverySlot } from "./question-delivery-drafts.js";
import { confirmedDeliveryAssessment, readManualReviewBasis, readManualReviewQuestions } from "./question-delivery-evaluation.js";
import { boundOutput } from "./reading-progress.js";
import { currentSelfAssessments, selfAssessmentCounts, selfAssessmentScoring, selfAssessmentView, selfReviewQuestionIds } from "./self-assessment.js";
import { appendReview, eventView, repeatedReview } from "./verdict-history.js";
import { questionVerdictStates, submissionReviewTarget } from "./verdict-state.js";
export function readQuestionDeliveryReview(database, reviewerId, activityId, key, authorize) {
    return readTransaction(database, () => {
        const { activity, receipt, content, fields } = authorizedDelivery(database, reviewerId, activityId, key, authorize);
        const manualReview = activity.practice.grading.manualReview;
        if (!manualReview)
            throw new LearningError(404, "REVIEW_NOT_FOUND");
        const questions = readManualReviewQuestions(database, receipt, content.questions);
        return { ...reviewedDelivery(activity, receipt, content, fields), ...manualBasis(database, receipt, manualReview.keyRef, fields), questions };
    });
}
export function readQuestionDeliveryVerdicts(database, reviewerId, activityId, key, authorize) {
    return readTransaction(database, () => {
        const { activity, receipt, content, fields } = authorizedDelivery(database, reviewerId, activityId, key, authorize);
        const target = requireAssessment(database, receipt.id, requireQuestionDeliverySlot(activity, content.slotId).targetId);
        const manualReview = activity.practice.grading.manualReview;
        const { automatic, review } = confirmedDeliveryAssessment(activity, content);
        const assessmentIds = new Set([...automatic, ...review].map(({ questionId }) => questionId));
        const confirmed = content.questions.filter(({ questionId }) => assessmentIds.has(questionId));
        const { questions, selfAssessment } = withSelfAssessments(database, activity, receipt.id, reviewedVerdicts(database, target, confirmed, automatic, fields), fields);
        const reviewed = {
            ...reviewedDelivery(activity, receipt, { ...content, questions: confirmed }, fields), targetId: target.targetId, questions,
            ...selfAssessment && { selfAssessment },
        };
        if (manualReview)
            return { ...reviewed, assessment: "manual", ...manualBasis(database, receipt, manualReview.keyRef, fields) };
        if (automatic.length)
            return { ...reviewed, assessment: "automatic" };
        return { ...reviewed, assessment: "teacherReview" };
    });
}
export function readChoiceConfirmationVerdicts(database, reviewerId, activityId, key, authorize) {
    return readFrozenConfirmationVerdicts(database, reviewerId, activityId, key, authorize, "choiceConfirmation", readChoiceConfirmation);
}
export function readResponseConfirmationVerdicts(database, reviewerId, activityId, key, authorize) {
    return readFrozenConfirmationVerdicts(database, reviewerId, activityId, key, authorize, "responseConfirmation", readResponseConfirmation);
}
function readFrozenConfirmationVerdicts(database, reviewerId, activityId, key, authorize, delivery, read) {
    return readTransaction(database, () => {
        const recovered = reviewConfirmation(database, reviewerId, activityId, key);
        const confirmation = read(recovered.content);
        if (!confirmation)
            throw new LearningError(404, "REVIEW_NOT_FOUND");
        const fields = authorizeRead(recovered, delivery, authorize);
        const { activity, receipt } = recovered;
        const target = requireAssessment(database, receipt.id, boundOutput(activity.step, receipt.slotId).targetId);
        const questions = reviewedVerdicts(database, target, confirmation.questions, confirmation.questions, fields);
        const { id, version } = activity.practice;
        return {
            receipt, practice: { id, version }, confirmation: projectAnswers(confirmation, fields), targetId: target.targetId,
            assessment: "automatic", questions,
        };
    });
}
function frozenConfirmation(content, delivery) {
    return delivery === "responseConfirmation" ? readResponseConfirmation(content) : readChoiceConfirmation(content);
}
function reviewedVerdicts(database, target, positions, automatic, fields) {
    const states = questionVerdictStates(database, target, positions);
    const unfinished = new Set(target.status === "pending" || target.status === "failed" ? automatic.map(({ questionId }) => questionId) : []);
    const waiting = target.status === "failed" ? "evaluationFailed" : "pendingEvaluation";
    const basis = fields.has("gradingBasis");
    return states.map(({ questionId, questionVersion, revision, automatic: original, effective, history }) => {
        const state = {
            questionId, questionVersion, revision, ...basis && original && { automatic: original },
            ...fields.has("verdictHistory") && { history: history.map(eventView) },
        };
        if (effective)
            return { ...state, status: "judged", ...basis && { effective } };
        return { ...state, status: unfinished.has(questionId) ? waiting : "needsReview" };
    });
}
function withSelfAssessments(database, activity, submissionId, verdicts, fields) {
    const scoring = selfAssessmentScoring(activity);
    const routed = selfReviewQuestionIds(activity);
    const current = currentSelfAssessments(database, submissionId);
    const viewOf = (questionId) => routed.has(questionId) ? selfAssessmentView(current.get(questionId)) : undefined;
    const questions = verdicts.map((question) => {
        const selfAssessment = viewOf(question.questionId);
        return selfAssessment ? { ...question, selfAssessment } : question;
    });
    if (!scoring)
        return { questions };
    const entries = verdicts.map(({ questionId, effective }) => ({ ...effective && { effective }, self: viewOf(questionId)?.verdict ?? null }));
    return { questions, selfAssessment: fields.has("gradingBasis") ? selfAssessmentCounts(scoring, entries) : { scoring } };
}
export function writeQuestionDeliveryVerdict(database, reviewerId, activityId, key, command, authorize, clock, mode) {
    return writeTransaction(database, () => {
        const recovered = reviewConfirmation(database, reviewerId, activityId, key);
        const { activity, receipt, content } = recovered;
        const delivery = mode ?? "questionDelivery";
        const { deliveryContent, questionVersion, targetId } = requireVerdictPosition(activity, receipt, content, command, mode);
        requireReviewPolicy(activity, "reviseQuestionVerdict");
        const { questionId, action } = command;
        if (authorize?.({ ...recovered.scope, delivery, purpose: "reviseVerdict", targetId, questionId, questionVersion, action }) !== true) {
            throw new LearningError(403, "FORBIDDEN");
        }
        const target = requireAssessment(database, receipt.id, targetId);
        if (target.targetId !== targetId)
            throw new Error("评估目标与冻结提交不一致");
        if (deliveryContent) {
            const { automatic, review } = confirmedDeliveryAssessment(activity, deliveryContent);
            if (![...automatic, ...review].some(question => question.questionId === questionId))
                throw new LearningError(403, "FORBIDDEN");
        }
        return repeatedReview(database, activityId, reviewerId, command) ?? appendReview(database, activityId, reviewerId, command, clock);
    });
}
function requireVerdictPosition(activity, receipt, content, command, mode) {
    const deliveryContent = mode === undefined ? readQuestionDelivery(content) : undefined;
    const confirmation = mode === undefined ? deliveryContent : frozenConfirmation(content, mode);
    if (!confirmation || command.submissionId !== receipt.id)
        throw new LearningError(403, "FORBIDDEN");
    const slot = deliveryContent ? requireQuestionDeliverySlot(activity, deliveryContent.slotId) : boundOutput(activity.step, receipt.slotId);
    const question = confirmation.questions.find(frozen => frozen.questionId === command.questionId);
    if (!question || command.targetId !== slot.targetId)
        throw new LearningError(403, "FORBIDDEN");
    return { deliveryContent, questionVersion: question.questionVersion, targetId: slot.targetId };
}
function requireReviewPolicy(activity, action) {
    const { fields, actions } = activity.practice.policy.reviewer;
    if (action ? !actions.includes(action) : fields.length === 0 && actions.length === 0)
        throw new LearningError(403, "FORBIDDEN");
    return new Set(fields);
}
function authorizeRead(recovered, delivery, authorize) {
    const fields = requireReviewPolicy(recovered.activity);
    if (authorize?.({ ...recovered.scope, delivery, purpose: "readReview" }) !== true)
        throw new LearningError(403, "FORBIDDEN");
    return fields;
}
function authorizedDelivery(database, reviewerId, activityId, key, authorize) {
    const recovered = reviewConfirmation(database, reviewerId, activityId, key);
    const content = readQuestionDelivery(recovered.content);
    if (!content)
        throw new LearningError(404, "REVIEW_NOT_FOUND");
    return { ...recovered, content, fields: authorizeRead(recovered, "questionDelivery", authorize) };
}
function projectAnswers(confirmation, fields) {
    if (fields.has("studentChoices"))
        return confirmation;
    return { ...confirmation, questions: confirmation.questions.map(({ value: _value, choice: _choice, ...question }) => question) };
}
function reviewedDelivery({ practice: { id, version } }, receipt, content, fields) {
    return { receipt, practice: { id, version }, confirmation: projectAnswers(questionDeliveryView(content), fields) };
}
function manualBasis(database, receipt, keyRef, fields) {
    return fields.has("gradingBasis") ? { basis: readManualReviewBasis(database, receipt, keyRef) } : {};
}
function requireAssessment(database, submissionId, targetId) {
    const target = submissionReviewTarget(database, submissionId, targetId);
    if (!target)
        throw new LearningError(404, "REVIEW_NOT_FOUND");
    return target;
}
function reviewConfirmation(database, reviewerId, activityId, key) {
    const { stepAttemptId, operationId } = key;
    const studentId = database.prepare(`
    SELECT a.student_id AS studentId FROM activities a
    JOIN step_attempts t ON t.activity_id = a.id
    LEFT JOIN reading_reviews r ON r.activity_id = a.id
    WHERE a.id = ? AND t.id = ? AND (r.activity_id IS NULL OR (r.reviewer_id = ? AND r.reviewer_active = 1))
  `).get(activityId, stepAttemptId, reviewerId)?.studentId;
    if (typeof studentId !== "string")
        throw new LearningError(403, "FORBIDDEN");
    const activity = loadActivity(database, studentId, activityId);
    if (activity.kind !== "reading" || activity.stepAttemptId !== stepAttemptId)
        throw new LearningError(403, "FORBIDDEN");
    const recovered = confirmedWorkForOperation(database, activityId, key);
    if (!recovered)
        throw new LearningError(403, "FORBIDDEN");
    const { id: submissionId, slotId } = recovered.receipt;
    const scope = { reviewerId, studentId, activityId, stepAttemptId, operationId, submissionId, slotId };
    return { activity, ...recovered, scope };
}
