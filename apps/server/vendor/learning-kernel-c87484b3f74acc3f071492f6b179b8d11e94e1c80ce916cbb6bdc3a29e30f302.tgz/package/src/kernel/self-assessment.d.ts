import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { ConfirmationKey } from "../contracts/choice-confirmation.ts";
import { selfAssessmentRubric } from "../contracts/self-assessment.ts";
import type { SelfAssessmentInput, SelfAssessmentReceipt, SelfAssessmentScoring } from "../contracts/self-assessment.ts";
import type { ReadingActivity } from "./activity.ts";
declare const storedEvent: z.ZodObject<{
    id: z.ZodUUID;
    submissionId: z.ZodUUID;
    questionId: z.ZodString;
    revision: z.ZodInt;
    verdict: z.ZodNullable<z.ZodEnum<{
        correct: "correct";
        wrong: "wrong";
    }>>;
    rubric: z.ZodNullable<z.ZodString>;
    assessedAt: z.ZodISODateTime;
}, z.core.$strict>;
type Rubric = z.infer<typeof selfAssessmentRubric>;
type Event = Omit<z.infer<typeof storedEvent>, "rubric"> & {
    rubric?: Rubric;
};
type Verdict = Event["verdict"];
type Delivered = Readonly<{
    questionId: string;
    questionVersion: number;
}>;
export type SelfCountEntry = Readonly<{
    effective?: {
        correct: boolean;
    };
    self: Verdict;
}>;
export declare function selfAssessmentScoring(activity: Pick<ReadingActivity, "practice">): SelfAssessmentScoring | undefined;
export declare function selfReviewQuestionIds(activity: Pick<ReadingActivity, "practice">): ReadonlySet<string>;
export declare function currentSelfAssessments(database: DatabaseSync, submissionId: string): Map<string, Event>;
export type SelfAssessmentView = ReturnType<typeof selfAssessmentView>;
export declare function selfAssessmentView(event: Event | undefined): {
    source: "self";
    revision: number;
    verdict: null;
} | {
    source: "self";
    revision: number;
    verdict: "correct" | "wrong" | null;
    rubric?: Record<string, string | number>;
    assessedAt: string;
};
export declare function selfAssessmentCounts(scoring: SelfAssessmentScoring, entries: readonly SelfCountEntry[]): {
    questionCount: number;
    judgedCorrect: number;
    judgedWrong: number;
    selfAssessedCorrect: number;
    selfAssessedWrong: number;
    pending: number;
    scoring: "countAsCorrect" | "separate";
    correctCount: number;
};
export declare function readSelfAssessments(database: DatabaseSync, studentId: string, activityId: string, key: ConfirmationKey): {
    submissionId: string;
    scoring: "countAsCorrect" | "separate";
    questions: {
        questionId: string;
        questionVersion: number;
        selfAssessment: {
            source: "self";
            revision: number;
            verdict: null;
        } | {
            source: "self";
            revision: number;
            verdict: "correct" | "wrong" | null;
            rubric?: Record<string, string | number>;
            assessedAt: string;
        };
    }[];
};
export declare function deliveredSelfAssessments(database: DatabaseSync, activity: ReadingActivity, submissionId: string, questions: readonly Delivered[]): {
    questionId: string;
    questionVersion: number;
    selfAssessment: {
        source: "self";
        revision: number;
        verdict: null;
    } | {
        source: "self";
        revision: number;
        verdict: "correct" | "wrong" | null;
        rubric?: Record<string, string | number>;
        assessedAt: string;
    };
}[];
export declare function assessSelf(database: DatabaseSync, studentId: string, activityId: string, key: ConfirmationKey, input: SelfAssessmentInput, clock: () => Date): SelfAssessmentReceipt;
export {};
