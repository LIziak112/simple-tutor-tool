import type { DatabaseSync } from "node:sqlite";
import type { AuthorizeConfirmationRecovery, ConfirmationKey, VerifyOriginal } from "../contracts/choice-confirmation.ts";
import type { ResponseConfirmationInput } from "../contracts/response.ts";
import type { Registry } from "./registry.ts";
import { ResponseDraftConflict } from "./response-drafts.ts";
export declare class ResponseConfirmationConflict extends ResponseDraftConflict {
    constructor(questionId: string, current: ResponseDraftConflict["current"]);
}
export declare function confirmResponses(database: DatabaseSync, registry: Registry, studentId: string, activityId: string, input: ResponseConfirmationInput, clock: () => Date, verifyOriginal?: VerifyOriginal): {
    id: string;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export declare function recoverResponseConfirmation(database: DatabaseSync, studentId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeConfirmationRecovery | undefined): {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        kind: "responseConfirmation";
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: import("zod").JSONType;
        }[];
    };
    responseDraftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
    evaluation: {
        status: "failed" | "pending";
        evaluator: {
            id: string;
            version: number;
        };
        needsReviewCount?: never;
        questionCount?: never;
        correctCount?: never;
        questions?: never;
    } | {
        status: "evaluated";
        evaluator: {
            id: string;
            version: number;
        };
        questionCount: number;
        correctCount: number;
        needsReviewCount: number;
        questions: {
            questionId: string;
            questionVersion: number;
            result: {
                status: "judged";
                correct: boolean;
            } | {
                status: "needsReview";
            };
        }[];
    };
};
