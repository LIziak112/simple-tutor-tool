import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { StartInput } from "../contracts/reading.ts";
declare const publishedPractice: z.ZodUnion<readonly [z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    title: z.ZodString;
    material: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
    }, z.core.$strict>;
    steps: z.ZodTuple<[z.ZodObject<{
        id: z.ZodString;
        instructions: z.ZodString;
        tool: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>;
        positionId: z.ZodString;
        slotId: z.ZodString;
        targetId: z.ZodString;
    }, z.core.$strict>], null>;
}, z.core.$strict>, z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    formatVersion: z.ZodLiteral<1>;
    title: z.ZodString;
    material: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
    }, z.core.$strict>>;
    goals: z.ZodRecord<z.ZodString, z.ZodString>;
    questions: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodOptional<z.ZodInt>;
        prompt: z.ZodString;
        options: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        response: z.ZodOptional<z.ZodString>;
    }, z.core.$loose>>>;
    questionAnswerRules: z.ZodOptional<z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
    }, z.core.$strict>>, z.ZodTransform<{
        [k: string]: {
            id: string;
            version: number;
        };
    }, Record<string, {
        id: string;
        version: number;
    }>>>>;
    steps: z.ZodTuple<[z.ZodObject<{
        id: z.ZodString;
        requires: z.ZodOptional<z.ZodString>;
        instructions: z.ZodString;
        tool: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>;
        inputs: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
            from: z.ZodLiteral<"material">;
            positionId: z.ZodString;
            material: z.ZodOptional<z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            from: z.ZodLiteral<"questions">;
        }, z.core.$strict>, z.ZodObject<{
            stepId: z.ZodString;
            slotId: z.ZodString;
            from: z.ZodLiteral<"submission">;
            readOnly: z.ZodLiteral<true>;
        }, z.core.$strict>], "from">>;
        submit: z.ZodObject<{
            purpose: z.ZodEnum<{
                finalAnswer: "finalAnswer";
                stepEvidence: "stepEvidence";
            }>;
            slots: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"passageSelection">;
                oneRangePerRole: z.ZodRecord<z.ZodString, z.ZodString>;
                distinctParagraphs: z.ZodBoolean;
                evidenceUnit: z.ZodLiteral<"wholeSelection">;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"oneChoicePerQuestion">;
                reasonTargetId: z.ZodOptional<z.ZodString>;
                confirmFromDrafts: z.ZodOptional<z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"oneResponsePerQuestion">;
                input: z.ZodString;
                confirmFromDrafts: z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"questionDelivery">;
                delivery: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    mode: z.ZodLiteral<"whole">;
                }, z.core.$strict>, z.ZodObject<{
                    mode: z.ZodLiteral<"perQuestion">;
                    questionSlots: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodString>, z.ZodTransform<{
                        [k: string]: string;
                    }, Record<string, string>>>;
                }, z.core.$strict>], "mode">;
                confirmFromDrafts: z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"reuse">;
                source: z.ZodString;
            }, z.core.$strict>], "type">>;
        }, z.core.$strict>;
        afterConfirmation: z.ZodEnum<{
            advance: "advance";
            finish: "finish";
        }>;
    }, z.core.$strict>], z.ZodObject<{
        id: z.ZodString;
        requires: z.ZodOptional<z.ZodString>;
        instructions: z.ZodString;
        tool: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>;
        inputs: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
            from: z.ZodLiteral<"material">;
            positionId: z.ZodString;
            material: z.ZodOptional<z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>>;
        }, z.core.$strict>, z.ZodObject<{
            from: z.ZodLiteral<"questions">;
        }, z.core.$strict>, z.ZodObject<{
            stepId: z.ZodString;
            slotId: z.ZodString;
            from: z.ZodLiteral<"submission">;
            readOnly: z.ZodLiteral<true>;
        }, z.core.$strict>], "from">>;
        submit: z.ZodObject<{
            purpose: z.ZodEnum<{
                finalAnswer: "finalAnswer";
                stepEvidence: "stepEvidence";
            }>;
            slots: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"passageSelection">;
                oneRangePerRole: z.ZodRecord<z.ZodString, z.ZodString>;
                distinctParagraphs: z.ZodBoolean;
                evidenceUnit: z.ZodLiteral<"wholeSelection">;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"oneChoicePerQuestion">;
                reasonTargetId: z.ZodOptional<z.ZodString>;
                confirmFromDrafts: z.ZodOptional<z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"oneResponsePerQuestion">;
                input: z.ZodString;
                confirmFromDrafts: z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                source: z.ZodString;
                targetId: z.ZodString;
                type: z.ZodLiteral<"questionDelivery">;
                delivery: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    mode: z.ZodLiteral<"whole">;
                }, z.core.$strict>, z.ZodObject<{
                    mode: z.ZodLiteral<"perQuestion">;
                    questionSlots: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodString>, z.ZodTransform<{
                        [k: string]: string;
                    }, Record<string, string>>>;
                }, z.core.$strict>], "mode">;
                confirmFromDrafts: z.ZodObject<{
                    allowUnanswered: z.ZodBoolean;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                type: z.ZodLiteral<"reuse">;
                source: z.ZodString;
            }, z.core.$strict>], "type">>;
        }, z.core.$strict>;
        afterConfirmation: z.ZodEnum<{
            advance: "advance";
            finish: "finish";
        }>;
    }, z.core.$strict>>;
    grading: z.ZodDefault<z.ZodObject<{
        selectionFeedback: z.ZodOptional<z.ZodObject<{
            from: z.ZodObject<{
                stepId: z.ZodString;
                slotId: z.ZodString;
            }, z.core.$strict>;
            criterion: z.ZodString;
        }, z.core.$strict>>;
        assessment: z.ZodOptional<z.ZodObject<{
            from: z.ZodObject<{
                stepId: z.ZodString;
                slotId: z.ZodString;
            }, z.core.$strict>;
            evaluator: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>;
            keyRef: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>;
            unit: z.ZodLiteral<"question">;
            effectiveVerdictOrder: z.ZodTuple<[z.ZodLiteral<"teacherReview">, z.ZodLiteral<"automatic">], null>;
        }, z.core.$strict>>;
        manualReview: z.ZodOptional<z.ZodObject<{
            keyRef: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        teacherReview: z.ZodOptional<z.ZodObject<{
            questionIds: z.ZodPipe<z.ZodArray<z.ZodString>, z.ZodTransform<string[], string[]>>;
        }, z.core.$strict>>;
        selfReview: z.ZodOptional<z.ZodObject<{
            questionIds: z.ZodPipe<z.ZodArray<z.ZodString>, z.ZodTransform<string[], string[]>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    policy: z.ZodObject<{
        timeLimit: z.ZodOptional<z.ZodObject<{
            minutes: z.ZodInt;
            startsAt: z.ZodLiteral<"instanceStarted">;
            onDeadline: z.ZodLiteral<"keepDraftAndClose">;
        }, z.core.$strict>>;
        offline: z.ZodLiteral<"onlineOnly">;
        redo: z.ZodLiteral<"newInstanceOnAuthorization">;
        student: z.ZodObject<{
            ownSubmission: z.ZodObject<{
                scope: z.ZodLiteral<"ownConfirmedSubmissions">;
                fields: z.ZodArray<z.ZodEnum<{
                    ownChoices: "ownChoices";
                    ownResponses: "ownResponses";
                    receipt: "receipt";
                    submittedQuotes: "submittedQuotes";
                }>>;
                onFinal: z.ZodArray<z.ZodLiteral<"passageGradingStatus">>;
            }, z.core.$strict>;
            restart: z.ZodOptional<z.ZodLiteral<"anytime">>;
            selfAssessment: z.ZodOptional<z.ZodObject<{
                scoring: z.ZodEnum<{
                    countAsCorrect: "countAsCorrect";
                    separate: "separate";
                }>;
            }, z.core.$strict>>;
            passageScore: z.ZodOptional<z.ZodObject<{
                whenAll: z.ZodTuple<[z.ZodLiteral<"finalConfirmed">, z.ZodLiteral<"allQuestionsJudged">], null>;
                group: z.ZodLiteral<"wholePassage">;
                fields: z.ZodArray<z.ZodEnum<{
                    correctCount: "correctCount";
                    questionCount: "questionCount";
                }>>;
                allowSubsets: z.ZodLiteral<false>;
                drilldown: z.ZodLiteral<false>;
            }, z.core.$strict>>;
            review: z.ZodOptional<z.ZodObject<{
                requires: z.ZodLiteral<"passageScore">;
                while: z.ZodLiteral<"reviewOpen">;
                byQuestion: z.ZodArray<z.ZodLiteral<"effectiveVerdict">>;
                byQuoteSet: z.ZodArray<z.ZodLiteral<"learnerFeedback">>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        reviewer: z.ZodObject<{
            scope: z.ZodLiteral<"assignedReviewer">;
            fields: z.ZodArray<z.ZodEnum<{
                gradingBasis: "gradingBasis";
                learnerFeedback: "learnerFeedback";
                studentChoices: "studentChoices";
                submittedQuotes: "submittedQuotes";
                verdictHistory: "verdictHistory";
            }>>;
            actions: z.ZodArray<z.ZodEnum<{
                commentOnQuotes: "commentOnQuotes";
                reviseQuestionVerdict: "reviseQuestionVerdict";
            }>>;
        }, z.core.$strict>;
        manager: z.ZodObject<{
            scope: z.ZodLiteral<"assigningTeacher">;
            actions: z.ZodArray<z.ZodEnum<{
                authorizeRedo: "authorizeRedo";
                closeReview: "closeReview";
                openReview: "openReview";
            }>>;
        }, z.core.$strict>;
        externalAi: z.ZodLiteral<"disabled">;
    }, z.core.$strict>;
}, z.core.$strict>]>;
export type ReadingActivity = Extract<ReturnType<typeof loadActivity>, {
    kind: "reading";
}>;
type OpeningInput = StartInput & {
    practiceVersion?: number;
};
type OpeningMode = "start" | "prepare";
export declare function startActivity(database: DatabaseSync, student: string, input: OpeningInput, clock: () => Date, assignedReviewer?: string, openingMode?: OpeningMode): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
};
export declare function redoActivity(database: DatabaseSync, student: string, sourceId: string, operationId: string, clock: () => Date): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
};
export declare function recoverStart(database: DatabaseSync, student: string, operationId: string): {
    practiceId: string;
    practiceVersion: number;
    redoOf: string | null;
    prepared: 0 | 1;
    receipt: {
        activityId: string;
        stepAttemptId: string;
        startedAt: string;
    };
} | undefined;
export declare function createActivity(database: DatabaseSync, student: string, practice: z.infer<typeof publishedPractice>, operationId: string, startedAt: Date, assignedReviewer?: string, redoOf?: string | null, prepared?: boolean): {
    activityId: `${string}-${string}-${string}-${string}-${string}`;
    stepAttemptId: `${string}-${string}-${string}-${string}-${string}`;
    startedAt: string;
};
export declare function loadStudentActivity(database: DatabaseSync, student: string, activityId: string): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    completed: boolean;
    kind: "reading";
    abandoned: boolean;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    practice: {
        id: string;
        version: number;
        formatVersion: 1;
        title: string;
        material?: {
            id: string;
            version: number;
        } | undefined;
        goals: Record<string, string>;
        questionAnswerRules?: {
            [k: string]: {
                id: string;
                version: number;
            };
        } | undefined;
        steps: [{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: string;
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }, ...{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: string;
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }[]];
        grading: {
            selectionFeedback?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                criterion: string;
            } | undefined;
            assessment?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                evaluator: {
                    id: string;
                    version: number;
                };
                keyRef: {
                    id: string;
                    version: number;
                };
                unit: "question";
                effectiveVerdictOrder: ["teacherReview", "automatic"];
            } | undefined;
            manualReview?: {
                keyRef: {
                    id: string;
                    version: number;
                };
            } | undefined;
            teacherReview?: {
                questionIds: string[];
            } | undefined;
            selfReview?: {
                questionIds: string[];
            } | undefined;
        };
        policy: {
            timeLimit?: {
                minutes: number;
                startsAt: "instanceStarted";
                onDeadline: "keepDraftAndClose";
            } | undefined;
            offline: "onlineOnly";
            redo: "newInstanceOnAuthorization";
            student: {
                ownSubmission: {
                    scope: "ownConfirmedSubmissions";
                    fields: ("ownChoices" | "ownResponses" | "receipt" | "submittedQuotes")[];
                    onFinal: "passageGradingStatus"[];
                };
                restart?: "anytime" | undefined;
                selfAssessment?: {
                    scoring: "countAsCorrect" | "separate";
                } | undefined;
                passageScore?: {
                    whenAll: ["finalConfirmed", "allQuestionsJudged"];
                    group: "wholePassage";
                    fields: ("correctCount" | "questionCount")[];
                    allowSubsets: false;
                    drilldown: false;
                } | undefined;
                review?: {
                    requires: "passageScore";
                    while: "reviewOpen";
                    byQuestion: "effectiveVerdict"[];
                    byQuoteSet: "learnerFeedback"[];
                } | undefined;
            };
            reviewer: {
                scope: "assignedReviewer";
                fields: ("gradingBasis" | "learnerFeedback" | "studentChoices" | "submittedQuotes" | "verdictHistory")[];
                actions: ("commentOnQuotes" | "reviseQuestionVerdict")[];
            };
            manager: {
                scope: "assigningTeacher";
                actions: ("authorizeRedo" | "closeReview" | "openReview")[];
            };
            externalAi: "disabled";
        };
        questions: {
            [x: string]: unknown;
            id: string;
            version?: number | undefined;
            prompt: string;
            options: Record<string, string>;
            response?: string | undefined;
        }[];
    };
    step: {
        id: string;
        requires?: string | undefined;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        inputs: Record<string, {
            from: "material";
            positionId: string;
            material?: {
                id: string;
                version: number;
            } | undefined;
        } | {
            from: "questions";
        } | {
            stepId: string;
            slotId: string;
            from: "submission";
            readOnly: true;
        }>;
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: string;
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
        afterConfirmation: "advance" | "finish";
    };
    choiceSnapshotRevisions: {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
    }[];
    redoOf: string | undefined;
    practiceVersion: number | undefined;
} | {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    completed: boolean;
    kind: "single";
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    };
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        positionId: string;
        slotId: string;
        targetId: string;
    };
};
export declare function loadStudentReadingActivity(database: DatabaseSync, student: string, activityId: string, stepAttemptId: string): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    completed: boolean;
    kind: "reading";
    abandoned: boolean;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    practice: {
        id: string;
        version: number;
        formatVersion: 1;
        title: string;
        material?: {
            id: string;
            version: number;
        } | undefined;
        goals: Record<string, string>;
        questionAnswerRules?: {
            [k: string]: {
                id: string;
                version: number;
            };
        } | undefined;
        steps: [{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: string;
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }, ...{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: string;
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }[]];
        grading: {
            selectionFeedback?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                criterion: string;
            } | undefined;
            assessment?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                evaluator: {
                    id: string;
                    version: number;
                };
                keyRef: {
                    id: string;
                    version: number;
                };
                unit: "question";
                effectiveVerdictOrder: ["teacherReview", "automatic"];
            } | undefined;
            manualReview?: {
                keyRef: {
                    id: string;
                    version: number;
                };
            } | undefined;
            teacherReview?: {
                questionIds: string[];
            } | undefined;
            selfReview?: {
                questionIds: string[];
            } | undefined;
        };
        policy: {
            timeLimit?: {
                minutes: number;
                startsAt: "instanceStarted";
                onDeadline: "keepDraftAndClose";
            } | undefined;
            offline: "onlineOnly";
            redo: "newInstanceOnAuthorization";
            student: {
                ownSubmission: {
                    scope: "ownConfirmedSubmissions";
                    fields: ("ownChoices" | "ownResponses" | "receipt" | "submittedQuotes")[];
                    onFinal: "passageGradingStatus"[];
                };
                restart?: "anytime" | undefined;
                selfAssessment?: {
                    scoring: "countAsCorrect" | "separate";
                } | undefined;
                passageScore?: {
                    whenAll: ["finalConfirmed", "allQuestionsJudged"];
                    group: "wholePassage";
                    fields: ("correctCount" | "questionCount")[];
                    allowSubsets: false;
                    drilldown: false;
                } | undefined;
                review?: {
                    requires: "passageScore";
                    while: "reviewOpen";
                    byQuestion: "effectiveVerdict"[];
                    byQuoteSet: "learnerFeedback"[];
                } | undefined;
            };
            reviewer: {
                scope: "assignedReviewer";
                fields: ("gradingBasis" | "learnerFeedback" | "studentChoices" | "submittedQuotes" | "verdictHistory")[];
                actions: ("commentOnQuotes" | "reviseQuestionVerdict")[];
            };
            manager: {
                scope: "assigningTeacher";
                actions: ("authorizeRedo" | "closeReview" | "openReview")[];
            };
            externalAi: "disabled";
        };
        questions: {
            [x: string]: unknown;
            id: string;
            version?: number | undefined;
            prompt: string;
            options: Record<string, string>;
            response?: string | undefined;
        }[];
    };
    step: {
        id: string;
        requires?: string | undefined;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        inputs: Record<string, {
            from: "material";
            positionId: string;
            material?: {
                id: string;
                version: number;
            } | undefined;
        } | {
            from: "questions";
        } | {
            stepId: string;
            slotId: string;
            from: "submission";
            readOnly: true;
        }>;
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: string;
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
        afterConfirmation: "advance" | "finish";
    };
    choiceSnapshotRevisions: {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
    }[];
    redoOf: string | undefined;
    practiceVersion: number | undefined;
};
export declare function loadActivity(database: DatabaseSync, student: string, activityId: string): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    completed: boolean;
    kind: "reading";
    abandoned: boolean;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    practice: {
        id: string;
        version: number;
        formatVersion: 1;
        title: string;
        material?: {
            id: string;
            version: number;
        } | undefined;
        goals: Record<string, string>;
        questionAnswerRules?: {
            [k: string]: {
                id: string;
                version: number;
            };
        } | undefined;
        steps: [{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: string;
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }, ...{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: string;
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }[]];
        grading: {
            selectionFeedback?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                criterion: string;
            } | undefined;
            assessment?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                evaluator: {
                    id: string;
                    version: number;
                };
                keyRef: {
                    id: string;
                    version: number;
                };
                unit: "question";
                effectiveVerdictOrder: ["teacherReview", "automatic"];
            } | undefined;
            manualReview?: {
                keyRef: {
                    id: string;
                    version: number;
                };
            } | undefined;
            teacherReview?: {
                questionIds: string[];
            } | undefined;
            selfReview?: {
                questionIds: string[];
            } | undefined;
        };
        policy: {
            timeLimit?: {
                minutes: number;
                startsAt: "instanceStarted";
                onDeadline: "keepDraftAndClose";
            } | undefined;
            offline: "onlineOnly";
            redo: "newInstanceOnAuthorization";
            student: {
                ownSubmission: {
                    scope: "ownConfirmedSubmissions";
                    fields: ("ownChoices" | "ownResponses" | "receipt" | "submittedQuotes")[];
                    onFinal: "passageGradingStatus"[];
                };
                restart?: "anytime" | undefined;
                selfAssessment?: {
                    scoring: "countAsCorrect" | "separate";
                } | undefined;
                passageScore?: {
                    whenAll: ["finalConfirmed", "allQuestionsJudged"];
                    group: "wholePassage";
                    fields: ("correctCount" | "questionCount")[];
                    allowSubsets: false;
                    drilldown: false;
                } | undefined;
                review?: {
                    requires: "passageScore";
                    while: "reviewOpen";
                    byQuestion: "effectiveVerdict"[];
                    byQuoteSet: "learnerFeedback"[];
                } | undefined;
            };
            reviewer: {
                scope: "assignedReviewer";
                fields: ("gradingBasis" | "learnerFeedback" | "studentChoices" | "submittedQuotes" | "verdictHistory")[];
                actions: ("commentOnQuotes" | "reviseQuestionVerdict")[];
            };
            manager: {
                scope: "assigningTeacher";
                actions: ("authorizeRedo" | "closeReview" | "openReview")[];
            };
            externalAi: "disabled";
        };
        questions: {
            [x: string]: unknown;
            id: string;
            version?: number | undefined;
            prompt: string;
            options: Record<string, string>;
            response?: string | undefined;
        }[];
    };
    step: {
        id: string;
        requires?: string | undefined;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        inputs: Record<string, {
            from: "material";
            positionId: string;
            material?: {
                id: string;
                version: number;
            } | undefined;
        } | {
            from: "questions";
        } | {
            stepId: string;
            slotId: string;
            from: "submission";
            readOnly: true;
        }>;
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: string;
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
        afterConfirmation: "advance" | "finish";
    };
    choiceSnapshotRevisions: {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
    }[];
    redoOf: string | undefined;
    practiceVersion: number | undefined;
} | {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    completed: boolean;
    kind: "single";
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    };
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        positionId: string;
        slotId: string;
        targetId: string;
    };
};
export {};
