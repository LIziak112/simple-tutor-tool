import type { DatabaseSync } from "node:sqlite";
import type { ReadingActivity } from "./activity.ts";
import type { SelfAssessmentScoring } from "../contracts/self-assessment.ts";
type StudentPolicy = ReadingActivity["practice"]["policy"]["student"];
type Graded = {
    questionId: string;
    correct: boolean;
};
export declare function studentResults(database: DatabaseSync, activity: ReadingActivity): DeliveryResults | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: Graded[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
};
declare function scoreFields(score: NonNullable<StudentPolicy["passageScore"]>, result: {
    questionCount: number;
    correctCount: number;
}): {
    status: "complete";
};
type SelfSummary = {
    scoring: SelfAssessmentScoring;
    judgedCorrect: number;
    selfAssessedCorrect: number;
    selfAssessedWrong: number;
};
type DeliveryResults = {
    assessment?: (ReturnType<typeof scoreFields> & {
        selfAssessment?: SelfSummary;
    }) | {
        status: "pending";
    };
    review?: undefined;
};
export {};
