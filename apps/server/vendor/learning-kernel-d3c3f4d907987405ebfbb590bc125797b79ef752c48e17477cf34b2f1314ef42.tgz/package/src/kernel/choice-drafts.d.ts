import type { DatabaseSync } from "node:sqlite";
import type { ChoiceDraftInput, UnversionedChoiceDraftInput } from "../contracts/choice-draft.ts";
import { LearningError } from "./learning-error.ts";
export declare class ChoiceDraftConflict extends LearningError {
    readonly current: Readonly<{
        revision: number;
        choice: string | null;
    }>;
    constructor(current: ChoiceDraftConflict["current"], code?: "ANSWER_REVISION_CONFLICT" | "OPERATION_CONFLICT");
}
export declare function readChoiceDrafts(database: DatabaseSync, activityId: string, stepAttemptId: string): {
    questionVersion: number;
    choice: string;
    slotId: string;
    questionId: string;
    revision: number;
    changeCount: number;
}[];
type DraftInput = ChoiceDraftInput | UnversionedChoiceDraftInput;
export declare function saveChoiceDraft(database: DatabaseSync, student: string, activityId: string, input: DraftInput): {
    questionVersion: number;
    choice: string;
    slotId: string;
    questionId: string;
    revision: number;
    changeCount: number;
};
export {};
