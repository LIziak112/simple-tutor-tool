import { z } from "zod";
import { id, publicationSchema, startInput, versionRef } from "./contracts/reading.js";
import { readingPublicationSchema } from "./contracts/reading-publication.js";
import { startActivity } from "./kernel/activity.js";
import { openDatabase } from "./kernel/database.js";
import { LearningError } from "./kernel/learning-error.js";
import { registerPublication } from "./kernel/publication.js";
import { readActivity } from "./kernel/submission.js";
const runtimeOptions = z.strictObject({ databasePath: z.string().min(1) });
const studentPrincipal = z.strictObject({ role: z.literal("student"), id });
const publishedStartInput = startInput.extend({ practiceVersion: versionRef.shape.version });
const uuid = z.uuid();
export { LearningError };
function studentId(principal) {
    const parsed = studentPrincipal.safeParse(principal);
    if (!parsed.success)
        throw new LearningError(403, "FORBIDDEN");
    return parsed.data.id;
}
export function openLearningRuntime(options) {
    const database = openDatabase(runtimeOptions.parse(options).databasePath);
    return {
        publish(input) {
            registerPublication(database, input);
        },
        start(principal, input) {
            return startActivity(database, studentId(principal), publishedStartInput.parse(input), () => new Date());
        },
        read(principal, activityId) {
            return readActivity(database, studentId(principal), uuid.parse(activityId));
        },
        close() {
            database.close();
        },
    };
}
