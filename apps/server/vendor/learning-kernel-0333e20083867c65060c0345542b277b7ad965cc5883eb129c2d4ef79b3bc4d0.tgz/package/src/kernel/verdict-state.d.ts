import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { ReadingActivity } from "./activity.ts";
declare const assessment: z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    status: z.ZodEnum<{
        done: "done";
        pending: "pending";
    }>;
}, z.core.$strict>;
export declare function assessmentTarget(database: DatabaseSync, activityId: string): {
    submissionId: string;
    targetId: string;
    status: "done" | "pending";
} | undefined;
export declare function questionVerdicts(database: DatabaseSync, activity: ReadingActivity, target: z.infer<typeof assessment>): {
    submissionId: string;
    targetId: string;
    questionId: string;
    prompt: string;
    revision: number;
    effective: {
        source: "teacherReview";
        id: string;
        correct: boolean;
    } | {
        source: "automatic";
        correct: boolean;
    } | undefined;
    automatic: {
        correct: boolean;
        valid: boolean;
    } | undefined;
    history: {
        submissionId: string;
        targetId: string;
        questionId: string;
        id: string;
        revision: number;
        reviewerId: string;
        reason: string;
        reviewedAt: string;
        action: "override" | "withdraw";
        correct: 0 | 1 | null;
        withdrawId: string | null;
    }[];
}[];
export {};
