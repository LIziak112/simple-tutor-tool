import { z } from "zod";
import { readingCapability } from "../builtins/reading-capabilities.js";
import { readingPracticeSchema, scoringKeySchema } from "../contracts/reading-publication.js";
import { readingAnswer } from "../contracts/reading-runtime.js";
const task = z.strictObject({
    submissionId: z.uuid(),
    targetId: z.string(),
    keyJSON: z.string(),
    practiceJSON: z.string(),
    answerJSON: z.string(),
});
export function queueEvaluation(database, activity, receipt, targetId) {
    const { assessment } = activity.practice.grading;
    if (!assessment || assessment.from.stepId !== activity.step.id || assessment.from.slotId !== receipt.slotId)
        return;
    database.prepare(`
    INSERT INTO evaluation_tasks (submission_id, key_id, key_version, target_id, status)
    VALUES (?, ?, ?, ?, 'pending')
  `).run(receipt.id, assessment.keyRef.id, assessment.keyRef.version, targetId);
}
export function evaluatePending(database, checkpoint) {
    const pending = database.prepare(`
    SELECT t.submission_id AS submissionId, t.target_id AS targetId, k.definition AS keyJSON,
      p.definition AS practiceJSON, v.selection AS answerJSON
    FROM evaluation_tasks t
    JOIN scoring_keys k ON k.id = t.key_id AND k.version = t.key_version
    JOIN submissions s ON s.id = t.submission_id
    JOIN step_attempts a ON a.id = s.step_attempt_id
    JOIN activities i ON i.id = a.activity_id
    JOIN practices p ON p.id = i.practice_id AND p.version = i.practice_version
    JOIN work_versions v ON v.work_id = s.work_id AND v.version = s.work_version
    WHERE t.status = 'pending' ORDER BY s.confirmed_at, s.id
  `).all();
    for (const row of pending)
        evaluateTask(database, task.parse(row), checkpoint);
}
function evaluateTask(database, input, checkpoint) {
    checkpoint?.({ point: "beforeEvaluation", submissionId: input.submissionId });
    const practice = readingPracticeSchema.parse(JSON.parse(input.practiceJSON));
    const assessment = practice.grading.assessment;
    const evaluator = assessment && readingCapability(assessment.evaluator);
    if (evaluator?.audience !== "server")
        throw new Error("已发布评估器不可用");
    const key = scoringKeySchema.parse(JSON.parse(input.keyJSON));
    const answer = readingAnswer.parse(JSON.parse(input.answerJSON));
    const record = database.prepare(`
    INSERT INTO automatic_verdicts (submission_id, target_id, question_id, correct)
    VALUES (?, ?, ?, ?) ON CONFLICT (submission_id, target_id, question_id) DO NOTHING
  `);
    for (const question of practice.questions) {
        const correct = key.acceptedChoices[question.id] === answer.choices[question.id];
        record.run(input.submissionId, input.targetId, question.id, Number(correct));
        checkpoint?.({ point: "afterAutomaticVerdict", submissionId: input.submissionId, questionId: question.id });
    }
    checkpoint?.({ point: "beforeEvaluationComplete", submissionId: input.submissionId });
    database.prepare("UPDATE evaluation_tasks SET status = 'done' WHERE submission_id = ?").run(input.submissionId);
}
