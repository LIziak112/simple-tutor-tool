import type { DatabaseSync } from "node:sqlite";
export declare function registerPublication(database: DatabaseSync, input: unknown): void;
