import type { DatabaseSync } from "node:sqlite";
import type { SubmissionReceipt } from "../contracts/reading.ts";
import type { ReadingActivity } from "./activity.ts";
import type { RuntimeCheckpoint } from "./runtime-checkpoint.ts";
export declare function queueEvaluation(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, targetId: string): void;
export declare function evaluatePending(database: DatabaseSync, checkpoint?: RuntimeCheckpoint): void;
