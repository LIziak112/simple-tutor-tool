import { z } from "zod";
import { publicationSchema } from "./contracts/reading.ts";
import { readingPublicationSchema } from "./contracts/reading-publication.ts";
import { LearningError } from "./kernel/learning-error.ts";
import { readActivity } from "./kernel/submission.ts";
declare const runtimeOptions: z.ZodObject<{
    databasePath: z.ZodString;
}, z.core.$strict>;
declare const studentPrincipal: z.ZodObject<{
    role: z.ZodLiteral<"student">;
    id: z.ZodString;
}, z.core.$strict>;
declare const publishedStartInput: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
    practiceId: z.ZodString;
    practiceVersion: z.ZodInt;
}, z.core.$strict>;
export { LearningError };
export type PublicationInput = z.input<typeof publicationSchema> | z.input<typeof readingPublicationSchema>;
export type StudentPrincipal = z.input<typeof studentPrincipal>;
export type PublishedStartInput = z.input<typeof publishedStartInput>;
export type StudentActivity = ReturnType<typeof readActivity>;
export declare function openLearningRuntime(options: z.input<typeof runtimeOptions>): {
    publish(input: PublicationInput): void;
    start(principal: StudentPrincipal, input: PublishedStartInput): {
        activityId: string;
        stepAttemptId: string;
        startedAt: string;
    };
    read(principal: StudentPrincipal, activityId: string): StudentActivity;
    close(): void;
};
