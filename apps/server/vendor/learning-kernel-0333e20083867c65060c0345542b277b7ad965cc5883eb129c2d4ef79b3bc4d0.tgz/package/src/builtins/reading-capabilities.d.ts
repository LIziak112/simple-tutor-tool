import type { VersionRef } from "../contracts/reading.ts";
type StudentValue = "material" | "questions" | "textRange" | "passageSelection" | "oneChoicePerQuestion";
export type ValueType = StudentValue | "scoringKey" | "questionVerdict";
type ReadingCapability = Readonly<VersionRef> & ({
    readonly audience: "student";
    readonly requiredInputs: readonly StudentValue[];
    readonly optionalInputs: readonly StudentValue[];
    readonly outputs: readonly StudentValue[];
} | {
    readonly audience: "server";
    readonly requiredInputs: readonly ["oneChoicePerQuestion", "scoringKey"];
    readonly optionalInputs: readonly [];
    readonly outputs: readonly ["questionVerdict"];
});
export declare const textSelectionCapability: {
    readonly id: "text-selection";
    readonly version: 1;
    readonly audience: "student";
    readonly requiredInputs: readonly ["material"];
    readonly optionalInputs: readonly [];
    readonly outputs: readonly ["textRange"];
};
export declare function readingCapability(reference: VersionRef): ReadingCapability | undefined;
export declare function studentTool(reference: VersionRef): (Readonly<{
    id: string;
    version: number;
}> & {
    readonly audience: "student";
    readonly requiredInputs: readonly StudentValue[];
    readonly optionalInputs: readonly StudentValue[];
    readonly outputs: readonly StudentValue[];
}) | undefined;
export {};
