import { draftReceipt, selectionSchema } from "../contracts/reading.js";
import { selectText } from "./material-selection.js";
import { loadStudentActivity } from "./activity.js";
import { readChoiceDrafts } from "./choice-drafts.js";
import { readOpenDeliveryDrafts } from "./question-delivery-drafts.js";
import { questionDeliverySlot } from "./question-delivery-publication.js";
import { readResponseDrafts } from "./response-drafts.js";
import { writeTransaction } from "./database.js";
import { LearningError } from "../contracts/learning-error.js";
import { confirmReadingDraft, readingActivityView, readingStatus, requireAvailableTool, saveReadingAnswer, saveReadingSelection, studentSubmissionView, } from "./reading-progress.js";
import { studentResults } from "./student-results.js";
import { activitySubmissions, finishActivity, recordSubmission, recoverReceipt } from "./submission-store.js";
import { loadWorkVersion, saveWorkVersion } from "./work-versions.js";
export function saveDraft(database, registry, student, activityId, input) {
    return writeTransaction(database, () => {
        const activity = loadStudentActivity(database, student, activityId);
        if ("ranges" in input && activity.kind === "reading")
            return saveReadingSelection(database, registry, activity, input);
        if ("choices" in input && activity.kind === "reading")
            return saveReadingAnswer(database, registry, activity, input);
        if ("range" in input && activity.kind === "single") {
            requireAvailableTool(registry, activity.step, "textRange");
            const selection = selectText(activity.material, activity.step, input.range);
            const draft = saveWorkVersion(database, { activityId }, selection, input.workId);
            return draftReceipt.parse({ draft, selection });
        }
        throw new LearningError(422, "INVALID_DRAFT");
    });
}
export function submitDraft(database, registry, student, activityId, input, clock, checkpoint) {
    return writeTransaction(database, () => {
        const activity = loadStudentActivity(database, student, activityId);
        if (activity.kind === "reading")
            return confirmReadingDraft(database, registry, activity, input, clock, checkpoint);
        if (activity.stepAttemptId !== input.stepAttemptId)
            throw new LearningError(403, "FORBIDDEN");
        const repeated = recoverReceipt(database, input);
        if (repeated)
            return repeated;
        if (input.slotId !== activity.step.slotId)
            throw new LearningError(422, "INVALID_SLOT");
        requireAvailableTool(registry, activity.step, "textRange");
        if (activity.completed)
            throw new LearningError(409, "ALREADY_SUBMITTED");
        loadWorkVersion(database, { activityId }, input.draft);
        const receipt = recordSubmission(database, input, [{ targetId: activity.step.targetId, unitId: "wholeSelection" }], clock());
        finishActivity(database, activityId, receipt.id);
        return receipt;
    });
}
export function readActivity(database, student, activityId) {
    const activity = loadStudentActivity(database, student, activityId);
    const submissions = activitySubmissions(database, activityId);
    if (activity.kind !== "reading")
        return singleActivityView(activity, submissions);
    const view = readingActivityView(database, activity, submissions);
    const delivery = questionDeliverySlot(activity.step);
    if (delivery)
        return questionDeliveryActivityView(database, activity, view, delivery[0], submissions);
    return legacyReadingActivityView(database, activity, view);
}
function legacyReadingActivityView(database, activity, view) {
    const { activityId } = activity;
    if (activity.completed)
        return view;
    const response = Object.values(activity.step.submit.slots).find(slot => slot.type === "oneResponsePerQuestion");
    if (response) {
        const responseDrafts = readResponseDrafts(database, activityId, activity.stepAttemptId);
        return responseDrafts.length > 0 ? { ...view, responseDrafts } : view;
    }
    const { stepAttemptId, choiceSnapshotRevisions } = activity;
    const active = choiceSnapshotRevisions.length > 0 ? { ...view, choiceSnapshotRevisions } : view;
    const choiceDrafts = readChoiceDrafts(database, activityId, stepAttemptId);
    return choiceDrafts.length > 0 ? { ...active, choiceDrafts } : active;
}
function questionDeliveryActivityView(database, activity, view, slotId, submissions) {
    const submitted = submissions.filter(item => item.receipt.stepAttemptId === activity.stepAttemptId);
    const questionDeliveries = submitted.map(item => studentSubmissionView(activity, item)).filter(item => item.receipt || item.questionDelivery);
    const questionDeliveryDrafts = activity.completed ? [] :
        readOpenDeliveryDrafts(database, activity, slotId, new Set(submitted.map(item => item.receipt.slotId)));
    return { ...view, questionDeliveries, questionDeliveryDrafts };
}
function singleActivityView(activity, [first]) {
    const { kind, completed, ...previous } = activity;
    return {
        ...previous,
        status: completed ? "completed" : "active",
        submission: first ? submissionView(first) : null,
    };
}
export function readSubmission(database, student, activityId, submissionId) {
    const activity = loadStudentActivity(database, student, activityId);
    const result = activitySubmissions(database, activityId).find(item => item.receipt.id === submissionId);
    if (!result)
        throw new LearningError(403, "FORBIDDEN");
    return activity.kind === "reading" ? studentSubmissionView(activity, result) : submissionView(result);
}
export function readStudentFragment(database, student, activityId, submissionId) {
    const submission = readSubmission(database, student, activityId, submissionId);
    if (!("selection" in submission) || !submission.selection)
        throw new LearningError(403, "FORBIDDEN");
    return submission.selection;
}
export function readStudentResults(database, student, activityId, resource) {
    const activity = loadStudentActivity(database, student, activityId);
    if (activity.kind !== "reading")
        throw new LearningError(403, "FORBIDDEN");
    const results = studentResults(database, activity);
    if (resource === "assessment")
        return { assessment: results.assessment };
    if (resource === "review") {
        if (!results.review)
            throw new LearningError(403, "FORBIDDEN");
        return results.review;
    }
    return {
        activityId, status: readingStatus(activity), redoOf: activity.redoOf,
        submissions: activitySubmissions(database, activityId).map(submitted => studentSubmissionView(activity, submitted)),
        ...results,
    };
}
function submissionView(submitted) {
    return { receipt: submitted.receipt, selection: selectionSchema.parse(submitted.content) };
}
