import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { ChoiceDraftInput, ChoiceDraftScope, CurrentChoiceDraftMode, UnversionedChoiceDraftInput } from "../contracts/choice-draft.ts";
import type { ReadingActivity } from "./activity.ts";
import { LearningError } from "./learning-error.ts";
export declare class ChoiceDraftConflict extends LearningError {
    readonly current: Readonly<{
        revision: number;
        choice: string | null;
    }>;
    constructor(current: ChoiceDraftConflict["current"], code?: "ANSWER_REVISION_CONFLICT" | "OPERATION_CONFLICT");
}
declare const storedVersion: z.ZodObject<{
    workId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    revision: z.ZodInt;
    changeCount: z.ZodInt;
    content: z.ZodString;
}, z.core.$strip>;
declare function decodeChoice({ content, ...version }: z.infer<typeof storedVersion>): {
    questionVersion: number;
    choice: string;
    workId: string;
    slotId: string;
    questionId: string;
    revision: number;
    changeCount: number;
};
export declare function draftReceipt({ workId, ...draft }: ReturnType<typeof decodeChoice>): {
    questionVersion: number;
    choice: string;
    slotId: string;
    questionId: string;
    revision: number;
    changeCount: number;
};
export declare function readChoiceDrafts(database: DatabaseSync, activityId: string, stepAttemptId: string): {
    questionVersion: number;
    choice: string;
    slotId: string;
    questionId: string;
    revision: number;
    changeCount: number;
}[];
type DraftInput = ChoiceDraftInput | UnversionedChoiceDraftInput;
type DraftQuestion = ReadingActivity["practice"]["questions"][number];
export declare function saveChoiceDraft(database: DatabaseSync, student: string, activityId: string, input: DraftInput, clock: () => Date): {
    questionVersion: number;
    choice: string;
    slotId: string;
    questionId: string;
    revision: number;
    changeCount: number;
};
export declare function saveCurrentChoiceDraft(database: DatabaseSync, student: string, activityId: string, input: DraftInput, mode: CurrentChoiceDraftMode, clock: () => Date): {
    questionVersion: number;
    choice: string;
    slotId: string;
    questionId: string;
    revision: number;
    changeCount: number;
};
export declare function readChoiceRevision(database: DatabaseSync, workId: string, revision: number): {
    questionVersion: number;
    choice: string;
    workId: string;
    slotId: string;
    questionId: string;
    revision: number;
    changeCount: number;
};
export declare function requireDraftQuestion(activity: ReadingActivity, input: ChoiceDraftScope): {
    id: string;
    version?: number | undefined;
    prompt: string;
    options: Record<string, string>;
};
export declare function requireWritableChoice(question: DraftQuestion, choice: string): void;
export declare function readChoiceHead(database: DatabaseSync, activityId: string, { stepAttemptId, slotId, questionId }: ChoiceDraftScope): {
    questionVersion: number;
    choice: string;
    workId: string;
    slotId: string;
    questionId: string;
    revision: number;
    changeCount: number;
} | undefined;
export declare function appendChoiceVersion(database: DatabaseSync, activityId: string, input: DraftInput, current: ReturnType<typeof readChoiceHead>, clock: () => Date, actor?: "student" | "reviewer"): {
    workId: string;
    slotId: string;
    questionId: string;
    revision: number;
    questionVersion: number;
    choice: string;
    changeCount: number;
};
export {};
