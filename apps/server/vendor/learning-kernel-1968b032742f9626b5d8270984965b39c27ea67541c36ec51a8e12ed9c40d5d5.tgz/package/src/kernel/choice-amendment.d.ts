import type { DatabaseSync } from "node:sqlite";
import type { AuthorizeChoiceDraftAmendment, ChoiceDraftAmendmentInput, ChoiceDraftAmendmentScope } from "../contracts/choice-amendment.ts";
export declare function readChoiceDraftForAmendment(database: DatabaseSync, reviewer: string, activityId: string, scope: ChoiceDraftAmendmentScope, authorize?: AuthorizeChoiceDraftAmendment): {
    questionVersion: number;
    choice: string;
    slotId: string;
    questionId: string;
    revision: number;
    changeCount: number;
} | {
    slotId: string;
    questionId: string;
    questionVersion: number;
    choice: null;
    revision: number;
    changeCount: number;
};
export declare function amendChoiceDraft(database: DatabaseSync, reviewer: string, activityId: string, input: ChoiceDraftAmendmentInput, clock: () => Date, authorize?: AuthorizeChoiceDraftAmendment): {
    questionVersion: number;
    choice: string;
    slotId: string;
    questionId: string;
    revision: number;
    changeCount: number;
};
