import { z } from "zod";
import { choiceConfirmationInput, confirmationKey } from "./contracts/choice-confirmation.js";
import { choiceDraftAmendmentInput } from "./contracts/choice-amendment.js";
import { choiceDraftScope, choiceDraftInput, currentChoiceDraftMode } from "./contracts/choice-draft.js";
import { choiceEvaluators } from "./contracts/choice-evaluation.js";
import { preparedVersionInput } from "./contracts/prepared-activity.js";
import { id, publicationSchema, startInput, versionRef } from "./contracts/reading.js";
import { readingPublicationSchema } from "./contracts/reading-publication.js";
import { startActivity } from "./kernel/activity.js";
import { amendChoiceDraft, readChoiceDraftForAmendment } from "./kernel/choice-amendment.js";
import { confirmChoices, recoverChoiceConfirmation } from "./kernel/choice-confirmation.js";
import { readChoiceDraftActivity } from "./kernel/choice-draft-activity.js";
import { saveChoiceDraft, saveCurrentChoiceDraft } from "./kernel/choice-drafts.js";
import { openDatabase, readTransaction } from "./kernel/database.js";
import { LearningError } from "./kernel/learning-error.js";
import { replacePreparedActivityVersion } from "./kernel/prepared-activity.js";
import { registerPublication } from "./kernel/publication.js";
import { readActivity } from "./kernel/submission.js";
const runtimeOptions = z.strictObject({
    databasePath: z.string().min(1),
    choiceEvaluators: choiceEvaluators.default([]),
    authorizeChoiceDraftAmendment: z.custom(value => typeof value === "function").optional(),
    verifyOriginal: z.custom(value => typeof value === "function").optional(),
    authorizeConfirmationRecovery: z.custom(value => typeof value === "function").optional(),
});
const studentPrincipal = z.strictObject({ role: z.literal("student"), id });
const reviewerPrincipal = z.strictObject({ role: z.literal("reviewer"), id });
const publishedStartInput = startInput.extend({ practiceVersion: versionRef.shape.version });
const uuid = z.uuid();
const clock = () => new Date();
export { LearningError };
export { verifyActivityBindings } from "./kernel/activity-bindings.js";
export { ChoiceConfirmationConflict } from "./kernel/choice-confirmation.js";
export { ChoiceDraftConflict } from "./kernel/choice-drafts.js";
function principalId(schema, principal) {
    const parsed = schema.safeParse(principal);
    if (!parsed.success)
        throw new LearningError(403, "FORBIDDEN");
    return parsed.data.id;
}
export function openLearningRuntime(options) {
    const settings = runtimeOptions.parse(options);
    const database = openDatabase(settings.databasePath);
    return {
        publish(input) {
            registerPublication(database, input, settings.choiceEvaluators);
        },
        start(principal, input) {
            return startActivity(database, principalId(studentPrincipal, principal), publishedStartInput.parse(input), clock);
        },
        prepare(principal, input) {
            return startActivity(database, principalId(studentPrincipal, principal), publishedStartInput.parse(input), clock, undefined, "prepare");
        },
        replacePreparedActivityVersion(principal, activityId, input) {
            return replacePreparedActivityVersion(database, principalId(studentPrincipal, principal), uuid.parse(activityId), preparedVersionInput.parse(input));
        },
        read(principal, activityId) {
            return readTransaction(database, () => readActivity(database, principalId(studentPrincipal, principal), uuid.parse(activityId)));
        },
        readChoiceDraftActivity(principal, activityId) {
            return readChoiceDraftActivity(database, principalId(studentPrincipal, principal), uuid.parse(activityId));
        },
        saveChoiceDraft(principal, activityId, input) {
            return saveChoiceDraft(database, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceDraftInput.parse(input), clock);
        },
        saveCurrentChoiceDraft(principal, activityId, input, mode = "save") {
            return saveCurrentChoiceDraft(database, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceDraftInput.parse(input), currentChoiceDraftMode.parse(mode), clock);
        },
        readChoiceDraftForAmendment(principal, activityId, scope) {
            return readChoiceDraftForAmendment(database, principalId(reviewerPrincipal, principal), uuid.parse(activityId), choiceDraftScope.parse(scope), settings.authorizeChoiceDraftAmendment);
        },
        amendChoiceDraft(principal, activityId, input) {
            return amendChoiceDraft(database, principalId(reviewerPrincipal, principal), uuid.parse(activityId), choiceDraftAmendmentInput.parse(input), clock, settings.authorizeChoiceDraftAmendment);
        },
        confirmChoices(principal, activityId, input) {
            return confirmChoices(database, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceConfirmationInput.parse(input), clock, settings.verifyOriginal);
        },
        recoverChoiceConfirmation(principal, activityId, key) {
            return recoverChoiceConfirmation(database, principalId(studentPrincipal, principal), uuid.parse(activityId), confirmationKey.parse(key), settings.authorizeConfirmationRecovery, settings.choiceEvaluators);
        },
        close() {
            database.close();
        },
    };
}
