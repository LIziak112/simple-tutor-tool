import { z } from "zod";
import type { AuthorizeConfirmedReview, AuthorizeConfirmedVerdict } from "./verdict.ts";
export declare const orderedTextFormat: z.ZodLiteral<"orderedTextBlanks">;
export declare const titledTextFormat: z.ZodLiteral<"textWithOptionalTitle">;
export declare const choiceAndResponseFormat: z.ZodEnum<{
    booleanOrString: "booleanOrString";
    choice: "choice";
    optionIndexArray: "optionIndexArray";
}>;
export declare function orderedQuestionValues<T>(values: Record<string, T>): {
    [k: string]: T;
};
export declare const questionDeliveryMode: z.ZodDiscriminatedUnion<[z.ZodObject<{
    mode: z.ZodLiteral<"whole">;
}, z.core.$strict>, z.ZodObject<{
    mode: z.ZodLiteral<"perQuestion">;
    questionSlots: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodString>, z.ZodTransform<{
        [k: string]: string;
    }, Record<string, string>>>;
}, z.core.$strict>], "mode">;
declare const questionDeliveryKey: z.ZodDiscriminatedUnion<[z.ZodObject<{
    response: z.ZodLiteral<"choice">;
    acceptedChoice: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    response: z.ZodLiteral<"booleanOrString">;
    acceptedResponse: z.ZodBoolean;
}, z.core.$strict>, z.ZodObject<{
    response: z.ZodLiteral<"optionIndexArray">;
    acceptedIndexes: z.ZodArray<z.ZodInt>;
}, z.core.$strict>, z.ZodObject<{
    response: z.ZodLiteral<"orderedTextBlanks">;
    acceptedBlanks: z.ZodArray<z.ZodArray<z.ZodString>>;
}, z.core.$strict>, z.ZodObject<{
    response: z.ZodLiteral<"textWithOptionalTitle">;
}, z.core.$strict>], "response">;
export declare const questionDeliveryScoringKey: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    acceptedByQuestion: z.ZodPipe<z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
        response: z.ZodLiteral<"choice">;
        acceptedChoice: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        response: z.ZodLiteral<"booleanOrString">;
        acceptedResponse: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        response: z.ZodLiteral<"optionIndexArray">;
        acceptedIndexes: z.ZodArray<z.ZodInt>;
    }, z.core.$strict>, z.ZodObject<{
        response: z.ZodLiteral<"orderedTextBlanks">;
        acceptedBlanks: z.ZodArray<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        response: z.ZodLiteral<"textWithOptionalTitle">;
    }, z.core.$strict>], "response">>, z.ZodTransform<{
        [k: string]: {
            response: "choice";
            acceptedChoice: string;
        } | {
            response: "booleanOrString";
            acceptedResponse: boolean;
        } | {
            response: "optionIndexArray";
            acceptedIndexes: number[];
        } | {
            response: "orderedTextBlanks";
            acceptedBlanks: string[][];
        } | {
            response: "textWithOptionalTitle";
        };
    }, Record<string, {
        response: "choice";
        acceptedChoice: string;
    } | {
        response: "booleanOrString";
        acceptedResponse: boolean;
    } | {
        response: "optionIndexArray";
        acceptedIndexes: number[];
    } | {
        response: "orderedTextBlanks";
        acceptedBlanks: string[][];
    } | {
        response: "textWithOptionalTitle";
    }>>>;
}, z.core.$strict>;
export declare const questionDeliveryReviewBasis: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    reviewCriteria: z.ZodString;
}, z.core.$strict>;
export declare const questionDeliveryReviewMode: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<"verdicts">, z.ZodLiteral<"choiceConfirmation">]>>;
export type AuthorizeQuestionDeliveryReview = AuthorizeConfirmedReview;
export type AuthorizeQuestionDeliveryVerdict = AuthorizeConfirmedVerdict;
export declare const questionDeliveryDraftInput: z.ZodObject<{
    questionVersion: z.ZodInt;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    operationId: z.ZodString;
    baseRevision: z.ZodInt;
    value: z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodBoolean, z.ZodString]>, z.ZodArray<z.ZodInt>, z.ZodArray<z.ZodString>, z.ZodPipe<z.ZodObject<{
        body: z.ZodString;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodTransform<{
        body: string;
        title?: string;
    }, {
        body: string;
        title?: string | undefined;
    }>>]>;
}, z.core.$strict>;
export declare const questionDeliveryDraftValue: z.ZodObject<{
    questionVersion: z.ZodInt;
    value: z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodBoolean, z.ZodString]>, z.ZodArray<z.ZodInt>, z.ZodArray<z.ZodString>, z.ZodPipe<z.ZodObject<{
        body: z.ZodString;
        title: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodTransform<{
        body: string;
        title?: string;
    }, {
        body: string;
        title?: string | undefined;
    }>>]>;
}, z.core.$strict>;
export declare const questionDeliveryInput: z.ZodDiscriminatedUnion<[z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    operationId: z.ZodString;
    slotId: z.ZodString;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        questionVersion: z.ZodInt;
        revision: z.ZodInt;
        original: z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"frozen">;
            documentId: z.ZodString;
            versionId: z.ZodString;
            sha256: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"none">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"missing">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"uncollected">;
        }, z.core.$strict>], "state">;
    }, z.core.$strict>>;
    source: z.ZodLiteral<"whole">;
}, z.core.$strict>, z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    operationId: z.ZodString;
    slotId: z.ZodString;
    source: z.ZodLiteral<"question">;
    questions: z.ZodTuple<[z.ZodObject<{
        questionId: z.ZodString;
        questionVersion: z.ZodInt;
        revision: z.ZodInt;
        original: z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"frozen">;
            documentId: z.ZodString;
            versionId: z.ZodString;
            sha256: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"none">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"missing">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"uncollected">;
        }, z.core.$strict>], "state">;
    }, z.core.$strict>], null>;
}, z.core.$strict>, z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    operationId: z.ZodString;
    slotId: z.ZodString;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        questionVersion: z.ZodInt;
        revision: z.ZodInt;
        original: z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"frozen">;
            documentId: z.ZodString;
            versionId: z.ZodString;
            sha256: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"none">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"missing">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"uncollected">;
        }, z.core.$strict>], "state">;
    }, z.core.$strict>>;
    source: z.ZodLiteral<"finish">;
}, z.core.$strict>], "source">;
export declare const questionDelivery: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"questionDelivery">;
    slotId: z.ZodString;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        questionVersion: z.ZodInt;
        revision: z.ZodInt;
        original: z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"frozen">;
            documentId: z.ZodString;
            versionId: z.ZodString;
            sha256: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"none">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"missing">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"uncollected">;
        }, z.core.$strict>], "state">;
        value: z.ZodNullable<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodBoolean, z.ZodString]>, z.ZodArray<z.ZodInt>, z.ZodArray<z.ZodString>, z.ZodPipe<z.ZodObject<{
            body: z.ZodString;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodTransform<{
            body: string;
            title?: string;
        }, {
            body: string;
            title?: string | undefined;
        }>>]>>;
    }, z.core.$strict>>;
    source: z.ZodEnum<{
        question: "question";
        whole: "whole";
    }>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"questionDelivery">;
    slotId: z.ZodString;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        questionVersion: z.ZodInt;
        revision: z.ZodInt;
        original: z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"frozen">;
            documentId: z.ZodString;
            versionId: z.ZodString;
            sha256: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"none">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"missing">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"uncollected">;
        }, z.core.$strict>], "state">;
        value: z.ZodNullable<z.ZodUnion<readonly [z.ZodUnion<readonly [z.ZodBoolean, z.ZodString]>, z.ZodArray<z.ZodInt>, z.ZodArray<z.ZodString>, z.ZodPipe<z.ZodObject<{
            body: z.ZodString;
            title: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodTransform<{
            body: string;
            title?: string;
        }, {
            body: string;
            title?: string | undefined;
        }>>]>>;
    }, z.core.$strict>>;
    source: z.ZodLiteral<"finish">;
    requestQuestions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        questionVersion: z.ZodInt;
        revision: z.ZodInt;
        original: z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"frozen">;
            documentId: z.ZodString;
            versionId: z.ZodString;
            sha256: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"none">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"missing">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"uncollected">;
        }, z.core.$strict>], "state">;
    }, z.core.$strict>>;
}, z.core.$strict>], "source">;
export declare function readQuestionDelivery(content: unknown): {
    kind: "questionDelivery";
    slotId: string;
    questions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
        value: string | boolean | string[] | number[] | {
            body: string;
            title?: string;
        } | null;
    }[];
    source: "question" | "whole";
} | {
    kind: "questionDelivery";
    slotId: string;
    questions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
        value: string | boolean | string[] | number[] | {
            body: string;
            title?: string;
        } | null;
    }[];
    source: "finish";
    requestQuestions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
    }[];
} | undefined;
export type QuestionDeliveryDraftInput = z.infer<typeof questionDeliveryDraftInput>;
export type QuestionDeliveryInput = z.infer<typeof questionDeliveryInput>;
export type QuestionDelivery = z.infer<typeof questionDelivery>;
export type QuestionDeliveryKey = z.infer<typeof questionDeliveryKey>;
export type QuestionDeliveryFormat = QuestionDeliveryKey["response"];
export declare function questionDeliveryIntent(delivery: QuestionDelivery): {
    questionId: string;
    questionVersion: number;
    revision: number;
    original: {
        state: "frozen";
        documentId: string;
        versionId: string;
        sha256?: string | undefined;
    } | {
        state: "none";
    } | {
        state: "missing";
    } | {
        state: "uncollected";
    };
}[];
export declare function questionDeliveryView({ source, slotId, questions }: QuestionDelivery): {
    source: "finish" | "question" | "whole";
    slotId: string;
    questions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
        value: string | boolean | string[] | number[] | {
            body: string;
            title?: string;
        } | null;
    }[];
};
export {};
