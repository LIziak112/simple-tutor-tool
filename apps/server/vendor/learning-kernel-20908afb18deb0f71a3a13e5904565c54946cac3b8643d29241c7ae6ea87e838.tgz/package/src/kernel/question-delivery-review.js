import { readChoiceConfirmation } from "../contracts/choice-confirmation.js";
import { questionDeliveryView, readQuestionDelivery } from "../contracts/question-delivery.js";
import { loadActivity } from "./activity.js";
import { readTransaction, writeTransaction } from "./database.js";
import { LearningError } from "./learning-error.js";
import { confirmedWorkForOperation } from "./question-confirmation.js";
import { requireQuestionDeliverySlot } from "./question-delivery-drafts.js";
import { confirmedDeliveryAssessment, readManualReviewBasis, readManualReviewQuestions } from "./question-delivery-evaluation.js";
import { boundOutput } from "./reading-progress.js";
import { appendReview, repeatedReview } from "./verdict-history.js";
import { questionVerdictStates, submissionAssessmentTarget } from "./verdict-state.js";
export function readQuestionDeliveryReview(database, reviewerId, activityId, key, authorize) {
    return readTransaction(database, () => {
        const { activity, receipt, content } = authorizedReview(database, reviewerId, activityId, key, authorize);
        const manualReview = activity.practice.grading.manualReview;
        if (!manualReview)
            throw new LearningError(404, "REVIEW_NOT_FOUND");
        const basis = readManualReviewBasis(database, receipt, manualReview.keyRef);
        const questions = readManualReviewQuestions(database, receipt, content.questions);
        return { ...reviewedDelivery(activity, receipt, content), basis, questions };
    });
}
export function readQuestionDeliveryVerdicts(database, reviewerId, activityId, key, authorize) {
    return readTransaction(database, () => {
        const { activity, receipt, content } = authorizedReview(database, reviewerId, activityId, key, authorize);
        const target = requireAssessment(database, receipt.id);
        const manualReview = activity.practice.grading.manualReview;
        const { automatic, review } = confirmedDeliveryAssessment(activity, content);
        const assessmentIds = new Set([...automatic, ...review].map(({ questionId }) => questionId));
        const confirmed = content.questions.filter(({ questionId }) => assessmentIds.has(questionId));
        const questions = reviewedVerdicts(database, target, confirmed, automatic);
        const reviewed = { ...reviewedDelivery(activity, receipt, { ...content, questions: confirmed }), targetId: target.targetId, questions };
        if (manualReview)
            return { ...reviewed, assessment: "manual", basis: readManualReviewBasis(database, receipt, manualReview.keyRef) };
        if (automatic.length)
            return { ...reviewed, assessment: "automatic" };
        return { ...reviewed, assessment: "teacherReview" };
    });
}
export function readChoiceConfirmationVerdicts(database, reviewerId, activityId, key, authorize) {
    return readTransaction(database, () => {
        const { activity, receipt, content } = authorizedConfirmation(database, reviewerId, activityId, key, authorize);
        const confirmation = readChoiceConfirmation(content);
        if (!confirmation)
            throw new LearningError(404, "REVIEW_NOT_FOUND");
        const target = requireAssessment(database, receipt.id);
        const questions = reviewedVerdicts(database, target, confirmation.questions, confirmation.questions);
        const { id, version } = activity.practice;
        return { receipt, practice: { id, version }, confirmation, targetId: target.targetId, assessment: "automatic", questions };
    });
}
function reviewedVerdicts(database, target, positions, automatic) {
    const states = questionVerdictStates(database, target, positions, "replace");
    const pending = new Set(target.status === "pending" ? automatic.map(({ questionId }) => questionId) : []);
    return states.map(({ questionId, questionVersion, revision, automatic, effective }) => {
        const state = { questionId, questionVersion, revision, ...automatic && { automatic } };
        if (effective)
            return { ...state, status: "judged", effective };
        return { ...state, status: pending.has(questionId) ? "pendingEvaluation" : "needsReview" };
    });
}
export function writeQuestionDeliveryVerdict(database, reviewerId, activityId, key, command, authorize, clock, mode) {
    return writeTransaction(database, () => {
        const { activity, receipt, content, scope } = reviewConfirmation(database, reviewerId, activityId, key);
        const { delivery, questionVersion, targetId } = requireVerdictPosition(activity, receipt, content, command, mode);
        const { questionId, action } = command;
        if (authorize?.({ ...scope, targetId, questionId, questionVersion, action }) !== true) {
            throw new LearningError(403, "FORBIDDEN");
        }
        const target = requireAssessment(database, receipt.id);
        if (target.targetId !== targetId)
            throw new Error("评估目标与冻结提交不一致");
        if (delivery) {
            const { automatic, review } = confirmedDeliveryAssessment(activity, delivery);
            if (![...automatic, ...review].some(question => question.questionId === questionId))
                throw new LearningError(403, "FORBIDDEN");
        }
        return repeatedReview(database, activityId, reviewerId, command)
            ?? appendReview(database, activityId, reviewerId, command, clock, "replace");
    });
}
function requireVerdictPosition(activity, receipt, content, command, mode) {
    const delivery = mode === undefined ? readQuestionDelivery(content) : undefined;
    const confirmation = mode === "choiceConfirmation" ? readChoiceConfirmation(content) : delivery;
    if (!confirmation || command.submissionId !== receipt.id)
        throw new LearningError(403, "FORBIDDEN");
    const slot = delivery ? requireQuestionDeliverySlot(activity, delivery.slotId) : boundOutput(activity.step, receipt.slotId);
    const question = confirmation.questions.find(frozen => frozen.questionId === command.questionId);
    if (!question || command.targetId !== slot.targetId)
        throw new LearningError(403, "FORBIDDEN");
    return { delivery, questionVersion: question.questionVersion, targetId: slot.targetId };
}
function authorizedReview(database, reviewerId, activityId, key, authorize) {
    const recovered = authorizedConfirmation(database, reviewerId, activityId, key, authorize);
    const content = readQuestionDelivery(recovered.content);
    if (!content)
        throw new LearningError(404, "REVIEW_NOT_FOUND");
    return { ...recovered, content };
}
function authorizedConfirmation(database, reviewerId, activityId, key, authorize) {
    const recovered = reviewConfirmation(database, reviewerId, activityId, key);
    if (authorize?.(recovered.scope) !== true)
        throw new LearningError(403, "FORBIDDEN");
    return recovered;
}
function reviewedDelivery({ practice: { id, version } }, receipt, content) {
    return { receipt, practice: { id, version }, confirmation: questionDeliveryView(content) };
}
function requireAssessment(database, submissionId) {
    const target = submissionAssessmentTarget(database, submissionId);
    if (!target)
        throw new LearningError(404, "REVIEW_NOT_FOUND");
    return target;
}
function reviewConfirmation(database, reviewerId, activityId, key) {
    const { stepAttemptId, operationId } = key;
    const studentId = database.prepare(`
    SELECT a.student_id AS studentId FROM activities a
    JOIN step_attempts t ON t.activity_id = a.id
    LEFT JOIN reading_reviews r ON r.activity_id = a.id
    WHERE a.id = ? AND t.id = ? AND (r.activity_id IS NULL OR (r.reviewer_id = ? AND r.reviewer_active = 1))
  `).get(activityId, stepAttemptId, reviewerId)?.studentId;
    if (typeof studentId !== "string")
        throw new LearningError(403, "FORBIDDEN");
    const activity = loadActivity(database, studentId, activityId);
    if (activity.kind !== "reading" || activity.stepAttemptId !== stepAttemptId)
        throw new LearningError(403, "FORBIDDEN");
    const recovered = confirmedWorkForOperation(database, activityId, key);
    if (!recovered)
        throw new LearningError(403, "FORBIDDEN");
    const { id: submissionId, slotId } = recovered.receipt;
    const scope = { reviewerId, studentId, activityId, stepAttemptId, operationId, submissionId, slotId };
    return { activity, ...recovered, scope };
}
