import { z } from "zod";
import { activeTeacherVerdict, verdictHistory } from "./verdict-history.js";
const assessment = z.strictObject({ submissionId: z.uuid(), targetId: z.string(), status: z.enum(["pending", "done"]) });
const storedAutomatic = z.strictObject({
    questionId: z.string(), correct: z.literal([0, 1]).transform(Boolean), valid: z.literal([0, 1]).transform(Boolean),
});
export function assessmentTarget(database, activityId) {
    return findAssessmentTarget(database, "submission_id = (SELECT submission_id FROM completions WHERE activity_id = ?)", activityId);
}
export function submissionAssessmentTarget(database, submissionId) {
    return findAssessmentTarget(database, "submission_id = ?", submissionId);
}
function findAssessmentTarget(database, condition, id) {
    const target = database.prepare(`
    SELECT submission_id AS submissionId, target_id AS targetId, status
    FROM evaluation_tasks WHERE ${condition}
  `).get(id);
    return target ? assessment.parse(target) : undefined;
}
export function readAutomaticVerdicts(database, { submissionId, targetId }) {
    return database.prepare(`
    SELECT question_id AS questionId, correct, valid FROM automatic_verdicts WHERE submission_id = ? AND target_id = ?
  `).all(submissionId, targetId).map(row => storedAutomatic.parse(row));
}
export function assessmentVerdictMode(activity) {
    const from = activity.practice.grading.assessment?.from;
    const slot = from?.stepId === activity.step.id ? activity.step.submit.slots[from.slotId] : undefined;
    return slot?.type === "oneChoicePerQuestion" && slot.confirmFromDrafts ? "replace" : "undo";
}
export function questionVerdicts(database, activity, target) {
    const questions = activity.practice.questions.map(({ id: questionId, prompt }) => ({ questionId, prompt }));
    return questionVerdictStates(database, target, questions, assessmentVerdictMode(activity));
}
export function questionVerdictStates(database, target, questions, mode) {
    const automatic = readAutomaticVerdicts(database, target);
    const history = verdictHistory(database, target);
    return questions.map(question => {
        const { questionId } = question;
        const questionHistory = history.filter(event => event.questionId === questionId);
        const original = automatic.find(item => item.questionId === questionId);
        const automaticBasis = original && { correct: original.correct, valid: original.valid };
        const effective = activeTeacherVerdict(questionHistory, mode) ?? effectiveAutomatic(automaticBasis);
        return {
            ...question, submissionId: target.submissionId, targetId: target.targetId,
            revision: questionHistory.at(-1)?.revision ?? 0, effective, automatic: automaticBasis, history: questionHistory,
        };
    });
}
function effectiveAutomatic(verdict) {
    return verdict?.valid ? { source: "automatic", correct: verdict.correct } : undefined;
}
