import type { DatabaseSync } from "node:sqlite";
import type { ConfirmationKey } from "../contracts/choice-confirmation.ts";
import type { AuthorizeConfirmedReview, AuthorizeConfirmedVerdict, VerdictCommand } from "../contracts/verdict.ts";
export declare function readQuestionDeliveryReview(database: DatabaseSync, reviewerId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeConfirmedReview | undefined): {
    basis: {
        id: string;
        version: number;
        reviewCriteria: string;
    };
    questions: {
        questionId: string;
        questionVersion: number;
        status: "needsReview";
    }[];
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: string | boolean | string[] | number[] | {
                body: string;
                title?: string;
            } | null;
        }[];
    };
};
export declare function readQuestionDeliveryVerdicts(database: DatabaseSync, reviewerId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeConfirmedReview | undefined): {
    targetId: string;
    questions: ({
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        status: "judged";
        effective: {
            source: "teacherReview";
            id: string;
            correct: boolean;
        } | {
            source: "automatic";
            correct: boolean;
        };
    } | {
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        status: "needsReview" | "pendingEvaluation";
    })[];
    assessment: "manual";
    basis: {
        id: string;
        version: number;
        reviewCriteria: string;
    };
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: string | boolean | string[] | number[] | {
                body: string;
                title?: string;
            } | null;
        }[];
    };
} | {
    targetId: string;
    questions: ({
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        status: "judged";
        effective: {
            source: "teacherReview";
            id: string;
            correct: boolean;
        } | {
            source: "automatic";
            correct: boolean;
        };
    } | {
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        status: "needsReview" | "pendingEvaluation";
    })[];
    assessment: "automatic";
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: string | boolean | string[] | number[] | {
                body: string;
                title?: string;
            } | null;
        }[];
    };
} | {
    targetId: string;
    questions: ({
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        status: "judged";
        effective: {
            source: "teacherReview";
            id: string;
            correct: boolean;
        } | {
            source: "automatic";
            correct: boolean;
        };
    } | {
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        status: "needsReview" | "pendingEvaluation";
    })[];
    assessment: "teacherReview";
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: string | boolean | string[] | number[] | {
                body: string;
                title?: string;
            } | null;
        }[];
    };
};
export declare function readChoiceConfirmationVerdicts(database: DatabaseSync, reviewerId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeConfirmedReview | undefined): {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        kind: "choiceConfirmation";
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            choice: string | null;
        }[];
    };
    targetId: string;
    assessment: "automatic";
    questions: ({
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        status: "judged";
        effective: {
            source: "teacherReview";
            id: string;
            correct: boolean;
        } | {
            source: "automatic";
            correct: boolean;
        };
    } | {
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        status: "needsReview" | "pendingEvaluation";
    })[];
};
export declare function writeQuestionDeliveryVerdict(database: DatabaseSync, reviewerId: string, activityId: string, key: ConfirmationKey, command: VerdictCommand, authorize: AuthorizeConfirmedVerdict | undefined, clock: () => Date, mode?: "choiceConfirmation"): {
    submissionId: string;
    targetId: string;
    questionId: string;
    id: string;
    revision: number;
};
