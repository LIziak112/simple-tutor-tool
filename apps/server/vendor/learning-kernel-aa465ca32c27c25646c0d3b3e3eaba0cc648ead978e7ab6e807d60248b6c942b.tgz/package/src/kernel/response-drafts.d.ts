import type { DatabaseSync } from "node:sqlite";
import type { z } from "zod";
import type { CurrentChoiceDraftMode } from "../contracts/choice-draft.ts";
import type { ResponseDraftInput, ResponseFormat, ResponseValue, StoredResponseValue } from "../contracts/response.ts";
import type { ReadingActivity } from "./activity.ts";
import { QuestionDraftConflict } from "./question-draft-store.ts";
export declare class ResponseDraftConflict extends QuestionDraftConflict<{
    revision: number;
    value: ResponseValue | null;
}> {
}
export declare class IndexResponseDraftConflict extends QuestionDraftConflict<{
    revision: number;
    value: number[] | null;
}> {
    readonly questionId: string | undefined;
    constructor(current: {
        revision: number;
        value: number[] | null;
    }, code?: "ANSWER_REVISION_CONFLICT" | "OPERATION_CONFLICT", questionId?: string);
}
type DraftInput<Value> = Omit<ResponseDraftInput, "value"> & {
    value: Value;
};
type DraftContent<Value> = Pick<DraftInput<Value>, "questionVersion" | "value">;
export type ResponseDraftMode<Value> = {
    format: ResponseFormat;
    schema: z.ZodType<DraftContent<Value>>;
    Conflict: typeof QuestionDraftConflict<{
        revision: number;
        value: Value | null;
    }>;
};
export declare const scalarResponseDrafts: ResponseDraftMode<ResponseValue>;
export declare const indexResponseDrafts: ResponseDraftMode<number[]>;
export declare function responseSlot(activity: ReadingActivity, slotId: string, format: ResponseFormat): {
    source: string;
    targetId: string;
    type: "oneResponsePerQuestion";
    input: "booleanOrString" | "optionIndexArray";
    confirmFromDrafts: {
        allowUnanswered: boolean;
    };
};
export declare function readResponseDrafts<Value extends StoredResponseValue>(database: DatabaseSync, activityId: string, stepAttemptId: string, { schema }: ResponseDraftMode<Value>): Omit<{
    workId: string;
    slotId: string;
    questionId: string;
    workVersion: number;
    revision: number;
    changeCount: number;
} & DraftContent<Value>, "workId" | "workVersion">[];
export declare function saveResponseDraft<Value extends StoredResponseValue>(database: DatabaseSync, studentId: string, activityId: string, input: DraftInput<Value>, mode: CurrentChoiceDraftMode, clock: () => Date, draftMode: ResponseDraftMode<Value>): Omit<{
    workId: string;
    workVersion: number;
    slotId: string;
    questionId: string;
    questionVersion: number;
    value: Value;
    revision: number;
    changeCount: number;
}, "workId" | "workVersion">;
export {};
