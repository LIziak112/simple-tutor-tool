import { indexResponseDraftValue, responseDraftValue, sameStoredResponse } from "../contracts/response.js";
import { loadStudentReadingActivity } from "./activity.js";
import { recordChoiceDraftChange } from "./choice-draft-activity.js";
import { writeTransaction } from "./database.js";
import { LearningError } from "./learning-error.js";
import { isLatestQuestionDraftOperation, publicDraft, QuestionDraftConflict, readQuestionDraftHead, readQuestionDraftOperation, readQuestionDrafts, rememberQuestionDraftOperation, } from "./question-draft-store.js";
import { boundOutput } from "./reading-progress.js";
import { saveWorkVersion } from "./work-versions.js";
export class ResponseDraftConflict extends QuestionDraftConflict {
}
export class IndexResponseDraftConflict extends QuestionDraftConflict {
    questionId;
    constructor(current, code, questionId) {
        super(current, code);
        this.questionId = questionId;
    }
}
export const scalarResponseDrafts = {
    format: "booleanOrString", schema: responseDraftValue, Conflict: ResponseDraftConflict,
};
export const indexResponseDrafts = {
    format: "optionIndexArray", schema: indexResponseDraftValue, Conflict: IndexResponseDraftConflict,
};
export function responseSlot(activity, slotId, format) {
    const slot = boundOutput(activity.step, slotId);
    if (slot.type !== "oneResponsePerQuestion" || slot.input !== format)
        throw new LearningError(422, "INVALID_SLOT");
    return slot;
}
export function readResponseDrafts(database, activityId, stepAttemptId, { schema }) {
    return readQuestionDrafts(database, activityId, stepAttemptId, schema);
}
export function saveResponseDraft(database, studentId, activityId, input, mode, clock, draftMode) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, input.stepAttemptId);
        if (activity.completed)
            throw new LearningError(409, "ALREADY_SUBMITTED");
        responseSlot(activity, input.slotId, draftMode.format);
        const question = requireQuestionVersion(activity, input);
        if (typeof input.value === "object" && input.value.some(index => !Object.hasOwn(question.options, String(index)))) {
            throw new LearningError(422, "INVALID_OPTION_INDEX");
        }
        return saveCurrentResponse(database, activityId, input, mode, clock, draftMode);
    });
}
function requireQuestionVersion(activity, input) {
    const question = activity.practice.questions.find(question => question.id === input.questionId);
    if (!question)
        throw new LearningError(422, "INVALID_QUESTION");
    if (question.version !== input.questionVersion)
        throw new LearningError(409, "QUESTION_REVISION_STALE");
    return question;
}
function saveCurrentResponse(database, activityId, input, mode, clock, { schema, Conflict }) {
    const current = readQuestionDraftHead(database, activityId, input, schema);
    const previous = readQuestionDraftOperation(database, activityId, input, schema);
    if (previous && current)
        return publicDraft(replayResponseOperation(database, input, current, previous, Conflict));
    const state = current ?? { revision: 0, value: null };
    if (mode === "replayLatestOnly")
        throw new LearningError(409, "DRAFT_REPLAY_REQUIRED");
    if (state.revision !== input.baseRevision)
        throw new Conflict({ revision: state.revision, value: state.value });
    const written = current && sameStoredResponse(current.value, input.value) ? current : appendResponse(database, activityId, input, current, clock);
    rememberQuestionDraftOperation(database, input, written);
    return publicDraft(written);
}
function replayResponseOperation(database, input, current, previous, Conflict) {
    if (isLatestQuestionDraftOperation(database, current.workId, input.operationId)
        && previous.baseRevision === input.baseRevision && sameStoredResponse(previous.draft.value, input.value))
        return current;
    throw new Conflict({ revision: current.revision, value: current.value }, "OPERATION_CONFLICT");
}
function appendResponse(database, activityId, input, current, clock) {
    const { stepAttemptId, slotId, questionId, questionVersion, value } = input;
    recordChoiceDraftChange(database, activityId, clock());
    const draft = saveWorkVersion(database, { activityId, step: { id: stepAttemptId, slotId, questionId } }, { questionVersion, value }, current?.workId);
    return {
        workId: draft.id, workVersion: draft.version, slotId, questionId, questionVersion, value,
        revision: (current?.revision ?? 0) + 1, changeCount: (current?.changeCount ?? 0) + 1,
    };
}
