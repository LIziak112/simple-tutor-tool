import { z } from "zod";
import { indexResponseScoringKeySchema, responseScoringKeySchema } from "../contracts/reading-publication.js";
import { findResponseEvaluator, responseVerdict } from "../contracts/response-evaluation.js";
import { loadEvaluationKey, recordEvaluation } from "./evaluation.js";
import { LearningError } from "./learning-error.js";
import { assessmentTarget, readAutomaticVerdicts } from "./verdict-state.js";
export function scalarResponseEvaluation(database, registered) {
    return (activity, receipt, confirmation) => recoverResponseEvaluation(database, activity, receipt, confirmation.questions, (ref, key, context) => {
        const evaluate = requireEvaluator(registered, ref);
        const { acceptedResponses } = responseScoringKeySchema.parse(key);
        return question => {
            const acceptedResponse = acceptedResponses[question.questionId];
            if (typeof acceptedResponse !== "boolean")
                throw new Error("冻结的原值评分键缺少题目");
            return evaluate({ ...context, practice: { ...context.practice }, ...question, acceptedResponse });
        };
    });
}
export function indexResponseEvaluation(database, registered) {
    return (activity, receipt, confirmation) => recoverResponseEvaluation(database, activity, receipt, confirmation.questions, (ref, key, context) => {
        const evaluate = requireEvaluator(registered, ref);
        const { acceptedIndexes } = indexResponseScoringKeySchema.parse(key);
        return question => {
            const correctIndexes = acceptedIndexes[question.questionId];
            if (!correctIndexes)
                throw new Error("冻结的索引评分键缺少题目");
            return evaluate({
                ...context, practice: { ...context.practice }, ...question,
                value: question.value?.slice() ?? null, acceptedIndexes: [...correctIndexes],
            });
        };
    });
}
function requireEvaluator(registered, ref) {
    const evaluate = findResponseEvaluator(registered, ref);
    if (!evaluate)
        throw new LearningError(503, "EVALUATOR_UNAVAILABLE");
    return evaluate;
}
function recoverResponseEvaluation(database, activity, receipt, confirmed, prepareEvaluation) {
    const assessment = activity.practice.grading.assessment;
    const target = assessmentTarget(database, activity.activityId);
    if (!assessment || target?.submissionId !== receipt.id)
        throw new Error("已确认的原值评分任务不存在");
    const evaluator = assessment.evaluator;
    if (target.status === "pending") {
        const { id, version } = activity.practice;
        const evaluate = prepareEvaluation(evaluator, loadEvaluationKey(database, receipt.id), {
            activityId: activity.activityId, stepAttemptId: receipt.stepAttemptId, slotId: receipt.slotId, practice: { id, version },
        });
        const outcomes = confirmed.map(({ questionId, questionVersion, value }) => ({
            questionId, result: responseVerdict.parse(evaluate({ questionId, questionVersion, value })),
        }));
        completeResponseEvaluation(database, target, outcomes);
    }
    const outcomes = storedOutcomes(database, target);
    const questions = confirmed.map(({ questionId, questionVersion }) => {
        const result = outcomes.get(questionId);
        if (!result)
            throw new Error("已执行的原值评估缺少判定或待评事实");
        return { questionId, questionVersion, result };
    });
    return {
        evaluator, questionCount: questions.length,
        correctCount: questions.filter(({ result }) => result.status === "judged" && result.correct).length,
        needsReviewCount: questions.filter(({ result }) => result.status === "needsReview").length, questions,
    };
}
function completeResponseEvaluation(database, target, outcomes) {
    const requireReview = database.prepare("INSERT INTO response_review_requirements (submission_id, question_id) VALUES (?, ?)");
    const judged = outcomes.flatMap(({ questionId, result }) => {
        if (result.status === "judged")
            return [{ questionId, correct: result.correct }];
        requireReview.run(target.submissionId, questionId);
        return [];
    });
    recordEvaluation(database, target, judged);
}
const storedRequirement = z.strictObject({ questionId: z.string() });
function storedOutcomes(database, target) {
    const outcomes = new Map();
    for (const { questionId, correct, valid } of readAutomaticVerdicts(database, target)) {
        if (!valid)
            throw new Error("已执行的原值评估包含无效自动判定");
        outcomes.set(questionId, { status: "judged", correct });
    }
    const pending = database.prepare("SELECT question_id AS questionId FROM response_review_requirements WHERE submission_id = ?").all(target.submissionId);
    for (const row of pending) {
        const { questionId } = storedRequirement.parse(row);
        if (outcomes.has(questionId))
            throw new Error("同一道题同时处于已评与待评");
        outcomes.set(questionId, { status: "needsReview" });
    }
    return outcomes;
}
