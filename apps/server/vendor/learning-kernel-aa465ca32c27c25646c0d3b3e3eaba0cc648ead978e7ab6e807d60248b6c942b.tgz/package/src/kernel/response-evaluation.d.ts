import type { DatabaseSync } from "node:sqlite";
import type { SubmissionReceipt } from "../contracts/reading.ts";
import type { IndexResponseEvaluatorRegistration, ResponseEvaluatorRegistration } from "../contracts/response-evaluation.ts";
import type { IndexResponseConfirmation, ResponseConfirmation } from "../contracts/response.ts";
import type { ReadingActivity } from "./activity.ts";
export declare function scalarResponseEvaluation(database: DatabaseSync, registered: readonly ResponseEvaluatorRegistration[]): (activity: ReadingActivity, receipt: SubmissionReceipt, confirmation: ResponseConfirmation) => {
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    needsReviewCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        result: {
            status: "judged";
            correct: boolean;
        } | {
            status: "needsReview";
        };
    }[];
};
export declare function indexResponseEvaluation(database: DatabaseSync, registered: readonly IndexResponseEvaluatorRegistration[]): (activity: ReadingActivity, receipt: SubmissionReceipt, confirmation: IndexResponseConfirmation) => {
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    needsReviewCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        result: {
            status: "judged";
            correct: boolean;
        } | {
            status: "needsReview";
        };
    }[];
};
