export const textSelectionCapability = {
    id: "text-selection",
    version: 1,
    audience: "student",
    requiredInputs: ["material"],
    optionalInputs: [],
    outputs: ["textRange"],
};
export const choiceKeyCapability = {
    id: "choice-key",
    version: 1,
    audience: "server",
    requiredInputs: ["oneChoicePerQuestion", "scoringKey"],
    optionalInputs: [],
    outputs: ["questionVerdict"],
};
const capabilities = [
    textSelectionCapability,
    {
        id: "passage-select",
        version: 1,
        audience: "student",
        requiredInputs: ["material"],
        optionalInputs: [],
        outputs: ["passageSelection"],
    },
    {
        id: "single-choice-group",
        version: 1,
        audience: "student",
        requiredInputs: ["questions"],
        optionalInputs: ["material", "passageSelection", "oneChoicePerQuestion"],
        outputs: ["oneChoicePerQuestion"],
    },
    choiceKeyCapability,
];
export function readingCapability(reference) {
    return capabilities.find(capability => capability.id === reference.id && capability.version === reference.version);
}
export function isReservedReadingCapability(id) {
    return capabilities.some(capability => capability.id === id);
}
export function studentTool(reference) {
    const capability = readingCapability(reference);
    return capability?.audience === "student" ? capability : undefined;
}
