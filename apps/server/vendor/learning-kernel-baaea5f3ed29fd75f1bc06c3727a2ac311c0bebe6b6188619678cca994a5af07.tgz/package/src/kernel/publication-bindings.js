import { choiceKeyCapability, readingCapability, studentTool } from "../builtins/reading-capabilities.js";
import { findChoiceEvaluator } from "../contracts/choice-evaluation.js";
export function validateBindings({ practice, scoringKey }, issue, registered) {
    const earlierSteps = new Map();
    const positions = new Set();
    for (const [index, step] of practice.steps.entries()) {
        const report = (path, message) => issue(["practice", "steps", index, ...path], message);
        if (earlierSteps.has(step.id))
            report(["id"], "步骤标识重复");
        if (step.requires !== practice.steps[index - 1]?.id)
            report(["requires"], "须引用紧邻的前序步骤");
        const transition = index === practice.steps.length - 1 ? "finish" : "advance";
        if (step.afterConfirmation !== transition)
            report(["afterConfirmation"], "确认后的动作与步骤顺序不一致");
        const inputs = resolveInputs(step, earlierSteps, positions, report);
        validateTool(step, inputs, report);
        validateSlots(step, inputs, practice.goals, report);
        validateChoiceConfirmation(step, practice, report);
        earlierSteps.set(step.id, step);
    }
    if (positions.size > 0 && !practice.material)
        issue(["practice", "material"], "绑定材料输入时须声明材料版本");
    validateGrading(practice.grading, earlierSteps, registered, issue);
    validateAssessmentPolicy(practice, scoringKey, issue);
    validateQuestions(practice, issue);
}
function validateChoiceConfirmation(step, practice, issue) {
    const requested = Object.values(step.submit.slots).find(slot => slot.type === "oneChoicePerQuestion");
    if (!requested?.confirmFromDrafts)
        return;
    if (practice.steps.length !== 1 || step.submit.purpose !== "finalAnswer" || requested.reasonTargetId) {
        issue(["submit", "slots"], "草稿确认要求一个单步整卷单选槽");
    }
    if (practice.questions.some(question => question.version === undefined)) {
        issue(["submit", "slots"], "草稿确认须固定每道题的版本");
    }
}
function validateQuestions(practice, issue) {
    const ids = new Set();
    for (const [index, question] of practice.questions.entries()) {
        if (ids.has(question.id))
            issue(["practice", "questions", index, "id"], "题指标识重复");
        ids.add(question.id);
    }
    if (practice.questions.length === 0 && practice.steps.some(step => Object.values(step.inputs).some(input => input.from === "questions"))) {
        issue(["practice", "questions"], "绑定题目输入时须声明至少一题");
    }
}
function resolveInputs(step, earlierSteps, positions, issue) {
    const inputs = new Map();
    for (const [name, input] of Object.entries(step.inputs)) {
        if (input.from === "material") {
            if (positions.has(input.positionId))
                issue(["inputs", name, "positionId"], "材料使用位置重复");
            positions.add(input.positionId);
        }
        if (input.from === "submission") {
            if (!earlierSteps.has(input.stepId)) {
                issue(["inputs", name, "stepId"], "须引用前序步骤");
                continue;
            }
            const slot = findSlot(earlierSteps, input);
            if (!slot || slot.type === "reuse") {
                issue(["inputs", name, "slotId"], "须引用前序步骤已有的原始交付槽位");
                continue;
            }
            inputs.set(name, slot.type);
        }
        else {
            inputs.set(name, input.from);
        }
    }
    return inputs;
}
function validateTool(step, inputs, issue) {
    const capability = studentTool(step.tool);
    if (!capability) {
        issue(["tool"], "须绑定已登记且允许学生调用的工具版本");
        return;
    }
    const types = new Set(inputs.values());
    if (capability.requiredInputs.some(type => !types.has(type))) {
        issue(["inputs"], "缺少工具要求的输入类型");
    }
    const acceptedInputs = new Set([...capability.requiredInputs, ...capability.optionalInputs]);
    for (const [name, type] of inputs) {
        if (!acceptedInputs.has(type)) {
            issue(["inputs", name], "工具不接受此输入类型");
        }
    }
    validateOutputs(step.submit.slots, capability.outputs, issue);
}
function validateOutputs(slots, outputs, issue) {
    const entries = Object.entries(slots);
    for (const [name, slot] of entries) {
        if (slot.type !== "reuse" && !outputs.includes(slot.type)) {
            issue(["submit", "slots", name, "type"], "槽位类型与工具输出不一致");
        }
    }
    if (entries.filter(([, slot]) => slot.type !== "reuse").length !== 1) {
        issue(["submit", "slots"], "步骤须恰有一个新交付槽位");
    }
}
function validateSlots(step, inputs, goals, issue) {
    for (const [name, slot] of Object.entries(step.submit.slots)) {
        const path = ["submit", "slots", name];
        if (!sourceMatchesSlot(slot, inputs.get(slot.source))) {
            issue([...path, "source"], "槽位须引用本步骤中类型匹配的输入");
        }
        if (slot.type !== "reuse" && !Object.hasOwn(goals, slot.targetId)) {
            issue([...path, "targetId"], "槽位引用的目标不存在");
        }
        if (slot.type === "oneChoicePerQuestion" && slot.reasonTargetId && !Object.hasOwn(goals, slot.reasonTargetId)) {
            issue([...path, "reasonTargetId"], "理由引用的目标不存在");
        }
    }
}
function sourceMatchesSlot(slot, input) {
    switch (slot.type) {
        case "passageSelection": return input === "material";
        case "oneChoicePerQuestion": return input === "questions";
        case "reuse": return input === "passageSelection" || input === "oneChoicePerQuestion";
    }
}
function validateGrading(grading, steps, registered, issue) {
    const { selectionFeedback, assessment } = grading;
    if (selectionFeedback && findSlot(steps, selectionFeedback.from)?.type !== "passageSelection") {
        issue(["practice", "grading", "selectionFeedback", "from"], "评语须绑定选区交付槽位");
    }
    if (!assessment)
        return;
    const slot = findSlot(steps, assessment.from);
    if (slot?.type !== "oneChoicePerQuestion") {
        issue(["practice", "grading", "assessment", "from"], "逐题评估须绑定单选交付槽位");
        return;
    }
    validateAssessmentEvaluator(slot, assessment.evaluator, registered, issue);
}
function validateAssessmentEvaluator(slot, evaluator, registered, issue) {
    const path = ["practice", "grading", "assessment", "evaluator"];
    if (slot.confirmFromDrafts) {
        if (!findChoiceEvaluator(registered, evaluator)) {
            issue(path, "草稿确认槽须注册精确版本的宿主评估器，内置评分用于旧声明");
        }
        return;
    }
    if (readingCapability(evaluator) !== choiceKeyCapability) {
        issue(path, "须绑定获准读取评分键并输出逐题判定的服务端评估器");
    }
}
function validateAssessmentPolicy(practice, key, issue) {
    const { assessment } = practice.grading;
    const { passageScore, review, ownSubmission } = practice.policy.student;
    if (review && !passageScore)
        issue(["practice", "policy", "student", "review"], "开放复盘须声明整篇公布条件");
    if (Boolean(assessment) !== Boolean(key))
        issue(["scoringKey"], "评分声明与固定评分键须成对提供");
    if (!assessment && (passageScore || ownSubmission.onFinal.length)) {
        issue(["practice", "policy", "student", "passageScore"], "公布成绩须声明评估槽位和规则");
    }
    if (assessment && key)
        validateKey(practice, assessment.keyRef, key, issue);
}
function findSlot(steps, reference) {
    const slots = steps.get(reference.stepId)?.submit.slots;
    return slots && Object.hasOwn(slots, reference.slotId) ? slots[reference.slotId] : undefined;
}
function validateKey(practice, reference, key, issue) {
    if (reference.id !== key.id || reference.version !== key.version) {
        issue(["practice", "grading", "assessment", "keyRef"], "评估引用的评分键版本与发布评分键不一致");
    }
    const questions = new Set(practice.questions.map(question => question.id));
    for (const question of practice.questions) {
        const answer = key.acceptedChoices[question.id];
        if (answer === undefined || !Object.hasOwn(question.options, answer)) {
            issue(["scoringKey", "acceptedChoices", question.id], "评分键须指向本题存在的选项");
        }
    }
    for (const question of Object.keys(key.acceptedChoices)) {
        if (!questions.has(question))
            issue(["scoringKey", "acceptedChoices", question], "评分键引用的题目不存在");
    }
}
