import type { ChoiceEvaluatorRegistration } from "../contracts/choice-evaluation.ts";
import type { ReadingPublication } from "../contracts/reading-publication.ts";
type Issue = (path: (string | number)[], message: string) => void;
export declare function validateBindings({ practice, scoringKey }: ReadingPublication, issue: Issue, registered: readonly ChoiceEvaluatorRegistration[]): void;
export {};
