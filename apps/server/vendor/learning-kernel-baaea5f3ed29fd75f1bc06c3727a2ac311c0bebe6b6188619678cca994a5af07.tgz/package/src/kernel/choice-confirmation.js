import { readChoiceConfirmation } from "../contracts/choice-confirmation.js";
import { loadStudentReadingActivity } from "./activity.js";
import { ChoiceDraftConflict, readChoiceDrafts } from "./choice-drafts.js";
import { recoverChoiceEvaluation } from "./choice-evaluation.js";
import { writeTransaction } from "./database.js";
import { queueEvaluation } from "./evaluation.js";
import { LearningError } from "./learning-error.js";
import { boundOutput, requireBeforeDeadline } from "./reading-progress.js";
import { finishActivity, recordSubmission, submissionForOperation } from "./submission-store.js";
import { loadWorkVersion, saveWorkVersion } from "./work-versions.js";
export class ChoiceConfirmationConflict extends ChoiceDraftConflict {
    questionId;
    constructor(questionId, current) {
        super(current);
        this.questionId = questionId;
    }
}
export function confirmChoices(database, studentId, activityId, input, clock, verifyOriginal) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, input.stepAttemptId);
        const previous = confirmationForOperation(database, activityId, input);
        if (previous)
            return recoverReceipt(previous, input);
        const slot = requireConfirmationSlot(activity, input.slotId);
        const now = clock();
        requireBeforeDeadline(activity, now);
        const questions = freezeAnswers(database, activity, input, slot.confirmFromDrafts.allowUnanswered);
        verifyOriginals(questions, { studentId, activityId, stepAttemptId: input.stepAttemptId, operationId: input.operationId }, input.slotId, verifyOriginal);
        const content = { kind: "choiceConfirmation", questions };
        const draft = saveWorkVersion(database, confirmationScope(activityId, input.stepAttemptId, input.slotId), content);
        const observations = questions.flatMap(({ questionId, choice }) => choice === null ? [] : [{ targetId: slot.targetId, unitId: `question:${questionId}` }]);
        const receipt = recordSubmission(database, { ...input, draft }, observations, now);
        queueEvaluation(database, activity, receipt, slot.targetId);
        finishActivity(database, activityId, receipt.id);
        return receipt;
    });
}
export function recoverChoiceConfirmation(database, studentId, activityId, key, authorize, registered) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, key.stepAttemptId);
        if (authorize?.({ studentId, activityId, stepAttemptId: key.stepAttemptId, operationId: key.operationId }) !== true) {
            throw new LearningError(403, "FORBIDDEN");
        }
        const recovered = confirmationForOperation(database, activityId, key);
        if (!recovered?.confirmation)
            throw new LearningError(404, "CONFIRMATION_NOT_FOUND");
        const { receipt, confirmation } = recovered;
        const { id, version } = activity.practice;
        const evaluation = recoverChoiceEvaluation(database, activity, receipt, confirmation, registered);
        const drafts = draftsByQuestion(database, activityId, receipt);
        const choiceDraftChangeCounts = confirmation.questions.map(question => ({
            questionId: question.questionId, changeCount: confirmedChangeCount(question, drafts.get(question.questionId)),
        }));
        return { receipt, practice: { id, version }, confirmation, choiceDraftChangeCounts, ...(evaluation ? { evaluation } : {}) };
    });
}
function requireConfirmationSlot(activity, slotId) {
    if (activity.completed)
        throw new LearningError(409, "ALREADY_SUBMITTED");
    const slot = boundOutput(activity.step, slotId);
    if (slot.type !== "oneChoicePerQuestion" || !slot.confirmFromDrafts)
        throw new LearningError(422, "INVALID_SLOT");
    return { targetId: slot.targetId, confirmFromDrafts: slot.confirmFromDrafts };
}
function freezeAnswers(database, activity, input, allowUnanswered) {
    const frozen = activity.practice.questions;
    const selected = new Map(input.questions.map(question => [question.questionId, question]));
    if (selected.size !== frozen.length || selected.size !== input.questions.length) {
        throw new LearningError(422, "INVALID_QUESTION_SET");
    }
    const heads = confirmationHeads(database, activity, input);
    return frozen.map(question => {
        const requested = selected.get(question.id);
        if (!requested)
            throw new LearningError(422, "INVALID_QUESTION_SET");
        if (requested.questionVersion !== question.version)
            throw new LearningError(409, "QUESTION_REVISION_STALE");
        const current = heads.get(question.id) ?? { revision: 0, choice: null };
        if (requested.revision !== current.revision) {
            throw new ChoiceConfirmationConflict(question.id, { revision: current.revision, choice: current.choice });
        }
        if (current.choice === null && !allowUnanswered)
            throw new LearningError(422, "UNANSWERED_QUESTION");
        return { ...requested, choice: current.choice };
    });
}
function confirmationHeads(database, activity, input) {
    const heads = new Map();
    for (const { slotId, questionId, revision } of activity.choiceSnapshotRevisions) {
        if (slotId === input.slotId)
            heads.set(questionId, { revision, choice: null });
    }
    for (const [questionId, draft] of draftsByQuestion(database, activity.activityId, input)) {
        heads.set(questionId, draft);
    }
    return heads;
}
function draftsByQuestion(database, activityId, { stepAttemptId, slotId }) {
    return new Map(readChoiceDrafts(database, activityId, stepAttemptId)
        .filter(draft => draft.slotId === slotId).map(draft => [draft.questionId, draft]));
}
function confirmedChangeCount(question, draft) {
    if (question.choice === null)
        return 0;
    if (draft?.revision !== question.revision || draft.choice !== question.choice || draft.questionVersion !== question.questionVersion) {
        throw new Error("已确认作答缺少对应的草稿版本");
    }
    return draft.changeCount;
}
function verifyOriginals(questions, scope, slotId, verify) {
    for (const { questionId, questionVersion, original } of questions) {
        if (!verify && original.state === "uncollected")
            continue;
        if (verify?.({ ...scope, slotId, questionId, questionVersion, original: { ...original } }) !== true) {
            throw new LearningError(409, "ORIGINAL_NOT_VERIFIED");
        }
    }
}
function confirmationScope(activityId, stepAttemptId, slotId) {
    return { activityId, step: { id: stepAttemptId, slotId } };
}
function confirmationForOperation(database, activityId, input) {
    const previous = submissionForOperation(database, input);
    if (!previous)
        return undefined;
    const { receipt, draft } = previous;
    const content = loadWorkVersion(database, confirmationScope(activityId, receipt.stepAttemptId, receipt.slotId), draft);
    return { receipt, confirmation: readChoiceConfirmation(content) };
}
function recoverReceipt(previous, input) {
    const { receipt, confirmation } = previous;
    const intent = confirmation?.questions.map(({ choice, ...selection }) => selection);
    if (receipt.slotId !== input.slotId || !intent
        || questionIntent(intent) !== questionIntent(input.questions)) {
        throw new LearningError(409, "OPERATION_CONFLICT");
    }
    return receipt;
}
function questionIntent(questions) {
    return JSON.stringify(questions.toSorted((a, b) => a.questionId === b.questionId ? 0 : a.questionId < b.questionId ? -1 : 1));
}
