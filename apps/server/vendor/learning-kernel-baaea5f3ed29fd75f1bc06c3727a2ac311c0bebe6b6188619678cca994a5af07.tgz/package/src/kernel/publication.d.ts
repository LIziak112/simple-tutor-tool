import type { DatabaseSync } from "node:sqlite";
import type { ChoiceEvaluatorRegistration } from "../contracts/choice-evaluation.ts";
export declare function registerPublication(database: DatabaseSync, input: unknown, registered?: readonly ChoiceEvaluatorRegistration[]): void;
