import { z } from "zod";
declare const originalEvidence: z.ZodDiscriminatedUnion<[z.ZodObject<{
    state: z.ZodLiteral<"frozen">;
    documentId: z.ZodString;
    versionId: z.ZodString;
    sha256: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    state: z.ZodLiteral<"none">;
}, z.core.$strict>, z.ZodObject<{
    state: z.ZodLiteral<"missing">;
}, z.core.$strict>, z.ZodObject<{
    state: z.ZodLiteral<"uncollected">;
}, z.core.$strict>], "state">;
export declare const confirmationKey: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    operationId: z.ZodString;
}, z.core.$strict>;
export declare const choiceConfirmationInput: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    operationId: z.ZodString;
    slotId: z.ZodString;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        questionVersion: z.ZodInt;
        revision: z.ZodInt;
        original: z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"frozen">;
            documentId: z.ZodString;
            versionId: z.ZodString;
            sha256: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"none">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"missing">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"uncollected">;
        }, z.core.$strict>], "state">;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const choiceConfirmation: z.ZodObject<{
    kind: z.ZodLiteral<"choiceConfirmation">;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        questionVersion: z.ZodInt;
        revision: z.ZodInt;
        original: z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"frozen">;
            documentId: z.ZodString;
            versionId: z.ZodString;
            sha256: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"none">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"missing">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"uncollected">;
        }, z.core.$strict>], "state">;
        choice: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare function readChoiceConfirmation(content: unknown): {
    kind: "choiceConfirmation";
    questions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
        choice: string | null;
    }[];
} | undefined;
export type ChoiceConfirmationInput = z.infer<typeof choiceConfirmationInput>;
export type ConfirmationKey = z.infer<typeof confirmationKey>;
export type ChoiceConfirmation = z.infer<typeof choiceConfirmation>;
export type ConfirmationScope = {
    studentId: string;
    activityId: string;
    stepAttemptId: string;
    operationId: string;
};
export type VerifyOriginal = (scope: ConfirmationScope & {
    slotId: string;
    questionId: string;
    questionVersion: number;
    original: Readonly<z.infer<typeof originalEvidence>>;
}) => boolean;
export type AuthorizeConfirmationRecovery = (scope: ConfirmationScope) => boolean;
export {};
