import { z } from "zod";
import type { AuthorizeConfirmationRecovery, ChoiceConfirmationInput, ConfirmationKey, VerifyOriginal } from "./contracts/choice-confirmation.ts";
import type { AuthorizeChoiceDraftAmendment, ChoiceDraftAmendmentInput, ChoiceDraftAmendmentScope } from "./contracts/choice-amendment.ts";
import type { ChoiceDraftInput, CurrentChoiceDraftMode, UnversionedChoiceDraftInput } from "./contracts/choice-draft.ts";
import type { AuthorizeChoiceSnapshotRevision, ChoiceSnapshotRevisionInput, ChoiceSnapshotReviewerScope, HasChoiceSnapshotEvidence } from "./contracts/choice-snapshot.ts";
import type { PreparedActivityVersionInput, PreparedActivityVersionReceipt } from "./contracts/prepared-activity.ts";
import { publicationSchema } from "./contracts/reading.ts";
import { readingPublicationSchema } from "./contracts/reading-publication.ts";
import { LearningError } from "./kernel/learning-error.ts";
import { readActivity } from "./kernel/submission.ts";
declare const runtimeOptions: z.ZodObject<{
    databasePath: z.ZodString;
    choiceEvaluators: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        evaluate: z.ZodCustom<import("./contracts/choice-evaluation.ts").ChoiceEvaluator, import("./contracts/choice-evaluation.ts").ChoiceEvaluator>;
    }, z.core.$strict>>>;
    authorizeChoiceDraftAmendment: z.ZodOptional<z.ZodCustom<AuthorizeChoiceDraftAmendment, AuthorizeChoiceDraftAmendment>>;
    authorizeChoiceSnapshotRevision: z.ZodOptional<z.ZodCustom<AuthorizeChoiceSnapshotRevision, AuthorizeChoiceSnapshotRevision>>;
    hasChoiceSnapshotEvidence: z.ZodOptional<z.ZodCustom<HasChoiceSnapshotEvidence, HasChoiceSnapshotEvidence>>;
    verifyOriginal: z.ZodOptional<z.ZodCustom<VerifyOriginal, VerifyOriginal>>;
    authorizeConfirmationRecovery: z.ZodOptional<z.ZodCustom<AuthorizeConfirmationRecovery, AuthorizeConfirmationRecovery>>;
}, z.core.$strict>;
declare const studentPrincipal: z.ZodObject<{
    role: z.ZodLiteral<"student">;
    id: z.ZodString;
}, z.core.$strict>;
declare const reviewerPrincipal: z.ZodObject<{
    role: z.ZodLiteral<"reviewer">;
    id: z.ZodString;
}, z.core.$strict>;
declare const publishedStartInput: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
    practiceId: z.ZodString;
    practiceVersion: z.ZodInt;
}, z.core.$strict>;
export { LearningError };
export { verifyActivityBindings } from "./kernel/activity-bindings.ts";
export type { AuthorizeChoiceSnapshotRevision, ChoiceSnapshotRevisionInput, ChoiceSnapshotReviewerScope, HasChoiceSnapshotEvidence };
export type { AuthorizeChoiceDraftAmendment, ChoiceDraftAmendmentInput, ChoiceDraftAmendmentScope };
export type ReviewerPrincipal = z.input<typeof reviewerPrincipal>;
export type { ActivityBindingClaims, TeacherAmendmentBinding, TeacherAmendmentBindingClaims } from "./contracts/activity-bindings.ts";
export type { PreparedActivityVersionInput, PreparedActivityVersionReceipt };
export type { ChoiceEvaluationInput, ChoiceEvaluator, ChoiceEvaluatorRegistration } from "./contracts/choice-evaluation.ts";
export { ChoiceConfirmationConflict } from "./kernel/choice-confirmation.ts";
export type { ChoiceDraftActivity } from "./kernel/choice-draft-activity.ts";
export { ChoiceSnapshotRevisionConflict } from "./kernel/choice-snapshot.ts";
export { ChoiceDraftConflict } from "./kernel/choice-drafts.ts";
export type { ChoiceDraftInput, AuthorizeConfirmationRecovery, ChoiceConfirmationInput, ConfirmationKey, CurrentChoiceDraftMode, UnversionedChoiceDraftInput, VerifyOriginal };
export type PublicationInput = z.input<typeof publicationSchema> | z.input<typeof readingPublicationSchema>;
export type StudentPrincipal = z.input<typeof studentPrincipal>;
export type PublishedStartInput = z.input<typeof publishedStartInput>;
export type StudentActivity = ReturnType<typeof readActivity>;
export declare function openLearningRuntime(options: z.input<typeof runtimeOptions>): {
    publish(input: PublicationInput): void;
    start(principal: StudentPrincipal, input: PublishedStartInput): {
        activityId: string;
        stepAttemptId: string;
        startedAt: string;
    };
    prepare(principal: StudentPrincipal, input: PublishedStartInput): {
        activityId: string;
        stepAttemptId: string;
        startedAt: string;
    };
    replacePreparedActivityVersion(principal: StudentPrincipal, activityId: string, input: PreparedActivityVersionInput): PreparedActivityVersionReceipt;
    read(principal: StudentPrincipal, activityId: string): StudentActivity;
    readChoiceDraftActivity(principal: StudentPrincipal, activityId: string): {
        firstChangedAt: string | null;
        lastChangedAt: string | null;
    } | undefined;
    saveChoiceDraft(principal: StudentPrincipal, activityId: string, input: ChoiceDraftInput | UnversionedChoiceDraftInput): {
        questionVersion: number;
        choice: string;
        slotId: string;
        questionId: string;
        revision: number;
        changeCount: number;
    };
    saveCurrentChoiceDraft(principal: StudentPrincipal, activityId: string, input: ChoiceDraftInput | UnversionedChoiceDraftInput, mode?: CurrentChoiceDraftMode): {
        questionVersion: number;
        choice: string;
        slotId: string;
        questionId: string;
        revision: number;
        changeCount: number;
    };
    readChoiceDraftForAmendment(principal: ReviewerPrincipal, activityId: string, scope: ChoiceDraftAmendmentScope): {
        slotId: string;
        questionId: string;
        questionVersion: number;
        choice: string | null;
        revision: number;
        changeCount: number;
    };
    amendChoiceDraft(principal: ReviewerPrincipal, activityId: string, input: ChoiceDraftAmendmentInput): {
        questionVersion: number;
        choice: string;
        slotId: string;
        questionId: string;
        revision: number;
        changeCount: number;
    };
    reviseChoiceSnapshot(principal: ReviewerPrincipal, activityId: string, input: ChoiceSnapshotRevisionInput): {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
        previousQuestionVersion: number;
    };
    confirmChoices(principal: StudentPrincipal, activityId: string, input: ChoiceConfirmationInput): {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    recoverChoiceConfirmation(principal: StudentPrincipal, activityId: string, key: ConfirmationKey): {
        receipt: {
            id: string;
            stepAttemptId: string;
            slotId: string;
            confirmedAt: string;
        };
        practice: {
            id: string;
            version: number;
        };
        confirmation: {
            kind: "choiceConfirmation";
            questions: {
                questionId: string;
                questionVersion: number;
                revision: number;
                original: {
                    state: "frozen";
                    documentId: string;
                    versionId: string;
                    sha256?: string | undefined;
                } | {
                    state: "none";
                } | {
                    state: "missing";
                } | {
                    state: "uncollected";
                };
                choice: string | null;
            }[];
        };
        choiceDraftChangeCounts: {
            questionId: string;
            changeCount: number;
        }[];
        evaluation?: {
            evaluator: {
                id: string;
                version: number;
            };
            questionCount: number;
            correctCount: number;
            questions: {
                questionId: string;
                questionVersion: number;
                correct: boolean;
            }[];
        };
    };
    close(): void;
};
