import { DatabaseSync } from "node:sqlite";
export declare function openDatabase(path: string): DatabaseSync;
export declare function writeTransaction<Result>(database: DatabaseSync, write: () => Result): Result;
export declare function readTransaction<Result>(database: DatabaseSync, read: () => Result): Result;
