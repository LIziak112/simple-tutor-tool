import type { DatabaseSync } from "node:sqlite";
import type { SaveInput, SubmitInput } from "../contracts/reading.ts";
import type { ReadingAnswerInput, ReadingSaveInput } from "../contracts/reading-runtime.ts";
import type { RuntimeCheckpoint } from "./runtime-checkpoint.ts";
import type { StoredSubmission } from "./submission-store.ts";
export declare function saveDraft(database: DatabaseSync, student: string, activityId: string, input: SaveInput | ReadingSaveInput | ReadingAnswerInput): {
    draft: {
        id: string;
        version: number;
    };
    selection: {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        range: {
            paragraphId: string;
            start: number;
            end: number;
        };
        text: string;
    };
} | {
    draft: {
        id: string;
        version: number;
    };
    selection: {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        ranges: {
            role: string;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
            text: string;
        }[];
    };
} | {
    draft: {
        id: string;
        version: number;
    };
    answer: {
        choices: Record<string, string>;
        references: Record<string, string>;
        reason?: {
            text: string;
            independent: boolean;
        } | undefined;
    };
};
export declare function submitDraft(database: DatabaseSync, student: string, activityId: string, input: SubmitInput, clock: () => Date, checkpoint?: RuntimeCheckpoint): {
    id: string;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export declare function readActivity(database: DatabaseSync, student: string, activityId: string): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    title: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    };
    step: {
        id: string;
        instructions: string;
        tool: {
            id: "text-selection";
            version: 1;
        };
        positionId: string;
        slotId: string;
        targetId: string;
    };
    status: "active" | "completed";
    submission: {
        receipt: {
            id: string;
            stepAttemptId: string;
            slotId: string;
            confirmedAt: string;
        };
        selection: {
            material: {
                id: string;
                version: number;
            };
            positionId: string;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
            text: string;
        };
    } | null;
} | {
    assessment?: never;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
        } | {
            from: "questions";
            questions: import("./activity.ts").ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
        } | {
            from: "questions";
            questions: import("./activity.ts").ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
        } | {
            from: "questions";
            questions: import("./activity.ts").ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
} | {
    assessment?: never;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
        } | {
            from: "questions";
            questions: import("./activity.ts").ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    choiceDrafts: {
        questionVersion: number;
        choice: string;
        slotId: string;
        questionId: string;
        revision: number;
        changeCount: number;
    }[];
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
        } | {
            from: "questions";
            questions: import("./activity.ts").ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    choiceDrafts: {
        questionVersion: number;
        choice: string;
        slotId: string;
        questionId: string;
        revision: number;
        changeCount: number;
    }[];
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
        } | {
            from: "questions";
            questions: import("./activity.ts").ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    choiceDrafts: {
        questionVersion: number;
        choice: string;
        slotId: string;
        questionId: string;
        revision: number;
        changeCount: number;
    }[];
};
export declare function readSubmission(database: DatabaseSync, student: string, activityId: string, submissionId: string): {
    receipt?: StoredSubmission["receipt"];
    confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
    selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
    answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
        references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
    };
} | {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    selection: {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        range: {
            paragraphId: string;
            start: number;
            end: number;
        };
        text: string;
    };
};
export declare function readStudentFragment(database: DatabaseSync, student: string, activityId: string, submissionId: string): {
    material: {
        id: string;
        version: number;
    };
    positionId: string;
    ranges: {
        role: string;
        range: {
            paragraphId: string;
            start: number;
            end: number;
        };
        text: string;
    }[];
} | {
    material: {
        id: string;
        version: number;
    };
    positionId: string;
    range: {
        paragraphId: string;
        start: number;
        end: number;
    };
    text: string;
};
export declare function readStudentResults(database: DatabaseSync, student: string, activityId: string, resource: "assessment" | "review" | "export"): {
    byQuestion: {
        questionId: string;
        correct: boolean;
    }[] | undefined;
    selectionFeedback: string | undefined;
} | {
    assessment: {
        status: "pending";
    } | {
        status: "complete";
    } | undefined;
} | {
    assessment?: never;
    review?: never;
    activityId: string;
    status: string;
    redoOf: string | undefined;
    submissions: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    }[];
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
    activityId: string;
    status: string;
    redoOf: string | undefined;
    submissions: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    }[];
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
    activityId: string;
    status: string;
    redoOf: string | undefined;
    submissions: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    }[];
};
