import type { ChoiceEvaluatorRegistration } from "../contracts/choice-evaluation.ts";
import type { ResponseEvaluatorRegistration } from "../contracts/response-evaluation.ts";
import type { ReadingPublication } from "../contracts/reading-publication.ts";
type Issue = (path: (string | number)[], message: string) => void;
export declare function validateBindings(publication: ReadingPublication, issue: Issue, registered: readonly ChoiceEvaluatorRegistration[], responses?: readonly ResponseEvaluatorRegistration[]): void;
export {};
