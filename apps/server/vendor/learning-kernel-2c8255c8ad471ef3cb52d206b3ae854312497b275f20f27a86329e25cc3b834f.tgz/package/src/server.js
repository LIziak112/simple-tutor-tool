import { z } from "zod";
import { choiceConfirmationInput, confirmationKey } from "./contracts/choice-confirmation.js";
import { choiceDraftAmendmentInput } from "./contracts/choice-amendment.js";
import { choiceDraftScope, choiceDraftInput, currentChoiceDraftMode } from "./contracts/choice-draft.js";
import { choiceEvaluators } from "./contracts/choice-evaluation.js";
import { choiceSnapshotRevisionInput } from "./contracts/choice-snapshot.js";
import { questionDeliveryDraftInput, questionDeliveryInput } from "./contracts/question-delivery.js";
import { preparedVersionInput } from "./contracts/prepared-activity.js";
import { id, publicationSchema, startInput, versionRef } from "./contracts/reading.js";
import { readingPublicationSchema } from "./contracts/reading-publication.js";
import { indexResponseDraftInput, responseDraftInput } from "./contracts/response.js";
import { indexResponseEvaluators, orderedTextEvaluators, responseEvaluators } from "./contracts/response-evaluation.js";
import { startActivity } from "./kernel/activity.js";
import { amendChoiceDraft, readChoiceDraftForAmendment } from "./kernel/choice-amendment.js";
import { confirmChoices, recoverChoiceConfirmation } from "./kernel/choice-confirmation.js";
import { readChoiceDraftActivity } from "./kernel/choice-draft-activity.js";
import { saveChoiceDraft, saveCurrentChoiceDraft } from "./kernel/choice-drafts.js";
import { reviseChoiceSnapshot } from "./kernel/choice-snapshot.js";
import { openDatabase, readTransaction } from "./kernel/database.js";
import { LearningError } from "./kernel/learning-error.js";
import { replacePreparedActivityVersion } from "./kernel/prepared-activity.js";
import { confirmQuestionDelivery, recoverQuestionDelivery } from "./kernel/question-delivery-confirmation.js";
import { saveQuestionDeliveryDraft } from "./kernel/question-delivery-drafts.js";
import { registerPublication } from "./kernel/publication.js";
import { confirmResponses, indexResponses, recoverResponseConfirmation, scalarResponses } from "./kernel/response-confirmation.js";
import { indexResponseDrafts, saveResponseDraft, scalarResponseDrafts } from "./kernel/response-drafts.js";
import { indexResponseEvaluation, scalarResponseEvaluation } from "./kernel/response-evaluation.js";
import { readActivity } from "./kernel/submission.js";
const runtimeOptions = z.strictObject({
    databasePath: z.string().min(1),
    choiceEvaluators: choiceEvaluators.default([]),
    responseEvaluators: responseEvaluators.default([]),
    indexResponseEvaluators: indexResponseEvaluators.default([]),
    orderedTextEvaluators: orderedTextEvaluators.default([]),
    authorizeChoiceDraftAmendment: z.custom(value => typeof value === "function").optional(),
    authorizeChoiceSnapshotRevision: z.custom(value => typeof value === "function").optional(),
    hasChoiceSnapshotEvidence: z.custom(value => typeof value === "function").optional(),
    verifyOriginal: z.custom(value => typeof value === "function").optional(),
    authorizeConfirmationRecovery: z.custom(value => typeof value === "function").optional(),
});
const studentPrincipal = z.strictObject({ role: z.literal("student"), id });
const reviewerPrincipal = z.strictObject({ role: z.literal("reviewer"), id });
const publishedStartInput = startInput.extend({ practiceVersion: versionRef.shape.version });
const uuid = z.uuid();
const clock = () => new Date();
export { LearningError };
export { verifyActivityBindings } from "./kernel/activity-bindings.js";
export { QuestionDeliveryConflict } from "./kernel/question-delivery-drafts.js";
export { ChoiceConfirmationConflict } from "./kernel/choice-confirmation.js";
export { ChoiceSnapshotRevisionConflict } from "./kernel/choice-snapshot.js";
export { ChoiceDraftConflict } from "./kernel/choice-drafts.js";
export { ResponseConfirmationConflict } from "./kernel/response-confirmation.js";
export { IndexResponseDraftConflict, ResponseDraftConflict } from "./kernel/response-drafts.js";
function principalId(schema, principal) {
    const parsed = schema.safeParse(principal);
    if (!parsed.success)
        throw new LearningError(403, "FORBIDDEN");
    return parsed.data.id;
}
export function openLearningRuntime(options) {
    const settings = runtimeOptions.parse(options);
    const database = openDatabase(settings.databasePath);
    const registered = {
        choice: settings.choiceEvaluators, scalar: settings.responseEvaluators, indexes: settings.indexResponseEvaluators,
        orderedText: settings.orderedTextEvaluators,
    };
    const evaluateScalarResponse = scalarResponseEvaluation(database, settings.responseEvaluators);
    const evaluateIndexResponse = indexResponseEvaluation(database, settings.indexResponseEvaluators);
    return {
        publish(input) {
            registerPublication(database, input, registered);
        },
        start(principal, input) {
            return startActivity(database, principalId(studentPrincipal, principal), publishedStartInput.parse(input), clock);
        },
        prepare(principal, input) {
            return startActivity(database, principalId(studentPrincipal, principal), publishedStartInput.parse(input), clock, undefined, "prepare");
        },
        replacePreparedActivityVersion(principal, activityId, input) {
            return replacePreparedActivityVersion(database, principalId(studentPrincipal, principal), uuid.parse(activityId), preparedVersionInput.parse(input));
        },
        read(principal, activityId) {
            return readTransaction(database, () => readActivity(database, principalId(studentPrincipal, principal), uuid.parse(activityId)));
        },
        readChoiceDraftActivity(principal, activityId) {
            return readChoiceDraftActivity(database, principalId(studentPrincipal, principal), uuid.parse(activityId));
        },
        saveChoiceDraft(principal, activityId, input) {
            return saveChoiceDraft(database, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceDraftInput.parse(input), clock);
        },
        saveCurrentChoiceDraft(principal, activityId, input, mode = "save") {
            return saveCurrentChoiceDraft(database, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceDraftInput.parse(input), currentChoiceDraftMode.parse(mode), clock);
        },
        readChoiceDraftForAmendment(principal, activityId, scope) {
            return readChoiceDraftForAmendment(database, principalId(reviewerPrincipal, principal), uuid.parse(activityId), choiceDraftScope.parse(scope), settings.authorizeChoiceDraftAmendment);
        },
        amendChoiceDraft(principal, activityId, input) {
            return amendChoiceDraft(database, principalId(reviewerPrincipal, principal), uuid.parse(activityId), choiceDraftAmendmentInput.parse(input), clock, settings.authorizeChoiceDraftAmendment);
        },
        reviseChoiceSnapshot(principal, activityId, input) {
            return reviseChoiceSnapshot(database, principalId(reviewerPrincipal, principal), uuid.parse(activityId), choiceSnapshotRevisionInput.parse(input), clock, {
                authorize: settings.authorizeChoiceSnapshotRevision, hasEvidence: settings.hasChoiceSnapshotEvidence,
            });
        },
        confirmChoices(principal, activityId, input) {
            return confirmChoices(database, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceConfirmationInput.parse(input), clock, settings.verifyOriginal);
        },
        recoverChoiceConfirmation(principal, activityId, key) {
            return recoverChoiceConfirmation(database, principalId(studentPrincipal, principal), uuid.parse(activityId), confirmationKey.parse(key), settings.authorizeConfirmationRecovery, settings.choiceEvaluators);
        },
        saveResponseDraft(principal, activityId, input, mode = "save") {
            return saveResponseDraft(database, principalId(studentPrincipal, principal), uuid.parse(activityId), responseDraftInput.parse(input), currentChoiceDraftMode.parse(mode), clock, scalarResponseDrafts);
        },
        confirmResponses(principal, activityId, input) {
            return confirmResponses(database, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceConfirmationInput.parse(input), clock, scalarResponses, settings.verifyOriginal);
        },
        recoverResponseConfirmation(principal, activityId, key) {
            return recoverResponseConfirmation(database, principalId(studentPrincipal, principal), uuid.parse(activityId), confirmationKey.parse(key), settings.authorizeConfirmationRecovery, scalarResponses, evaluateScalarResponse);
        },
        saveIndexResponseDraft(principal, activityId, input, mode = "save") {
            return saveResponseDraft(database, principalId(studentPrincipal, principal), uuid.parse(activityId), indexResponseDraftInput.parse(input), currentChoiceDraftMode.parse(mode), clock, indexResponseDrafts);
        },
        confirmIndexResponses(principal, activityId, input) {
            return confirmResponses(database, principalId(studentPrincipal, principal), uuid.parse(activityId), choiceConfirmationInput.parse(input), clock, indexResponses, settings.verifyOriginal);
        },
        recoverIndexResponseConfirmation(principal, activityId, key) {
            return recoverResponseConfirmation(database, principalId(studentPrincipal, principal), uuid.parse(activityId), confirmationKey.parse(key), settings.authorizeConfirmationRecovery, indexResponses, evaluateIndexResponse);
        },
        saveQuestionDeliveryDraft(principal, activityId, input, mode = "save") {
            return saveQuestionDeliveryDraft(database, principalId(studentPrincipal, principal), uuid.parse(activityId), questionDeliveryDraftInput.parse(input), currentChoiceDraftMode.parse(mode), clock);
        },
        confirmQuestionDelivery(principal, activityId, input) {
            return confirmQuestionDelivery(database, principalId(studentPrincipal, principal), uuid.parse(activityId), questionDeliveryInput.parse(input), clock, settings.verifyOriginal, settings.authorizeConfirmationRecovery);
        },
        recoverQuestionDelivery(principal, activityId, key) {
            return recoverQuestionDelivery(database, principalId(studentPrincipal, principal), uuid.parse(activityId), confirmationKey.parse(key), settings.authorizeConfirmationRecovery, registered);
        },
        close() {
            database.close();
        },
    };
}
