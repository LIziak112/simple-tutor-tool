import type { ChoiceEvaluatorRegistration } from "../contracts/choice-evaluation.ts";
import type { IndexResponseEvaluatorRegistration, OrderedTextEvaluatorRegistration, ResponseEvaluatorRegistration } from "../contracts/response-evaluation.ts";
import type { ReadingPublication } from "../contracts/reading-publication.ts";
type Issue = (path: (string | number)[], message: string) => void;
export type PublicationEvaluators = {
    choice?: readonly ChoiceEvaluatorRegistration[];
    scalar?: readonly ResponseEvaluatorRegistration[];
    indexes?: readonly IndexResponseEvaluatorRegistration[];
    orderedText?: readonly OrderedTextEvaluatorRegistration[];
};
export declare function validateBindings(publication: ReadingPublication, issue: Issue, registered: PublicationEvaluators): void;
export {};
