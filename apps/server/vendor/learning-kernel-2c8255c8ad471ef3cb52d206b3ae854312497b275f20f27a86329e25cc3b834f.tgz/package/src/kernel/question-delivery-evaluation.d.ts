import type { DatabaseSync } from "node:sqlite";
import type { QuestionDelivery } from "../contracts/question-delivery.ts";
import type { SubmissionReceipt } from "../contracts/reading.ts";
import type { ReadingActivity } from "./activity.ts";
import type { PublicationEvaluators } from "./publication-bindings.ts";
export declare function recoverQuestionDeliveryEvaluation(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, delivery: QuestionDelivery, registered: PublicationEvaluators): {
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    needsReviewCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        result: {
            status: "judged";
            correct: boolean;
        } | {
            status: "needsReview";
        };
    }[];
};
