import type { DatabaseSync } from "node:sqlite";
import type { ChoiceDraftScope } from "../contracts/choice-draft.ts";
import type { ReadingPublication } from "../contracts/reading-publication.ts";
export declare const choiceSnapshotOffsetForWork = "COALESCE((SELECT MAX(s.revision) FROM choice_snapshot_revisions s\n  WHERE s.step_attempt_id = w.step_attempt_id AND s.slot_id = w.slot_id AND s.question_id = w.question_id), 0)";
type FrozenQuestion = ReadingPublication["practice"]["questions"][number];
type SnapshotScope = Pick<ChoiceDraftScope, "stepAttemptId" | "slotId" | "questionId">;
export declare function effectiveChoiceQuestions(database: DatabaseSync, stepAttemptId: string, published: readonly FrozenQuestion[]): {
    questions: ({
        id: string;
        version?: number | undefined;
        prompt: string;
        options: Record<string, string>;
        response?: "booleanOrString" | "choice" | "optionIndexArray" | undefined;
    } | {
        id: string;
        version?: number | undefined;
        prompt: string;
        response: "orderedTextBlanks";
        blankCount: number;
        options: Record<string, never>;
    })[];
    choiceSnapshotRevisions: {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
    }[];
};
export declare function choiceRevisionBeforeAnswers(database: DatabaseSync, { stepAttemptId, slotId, questionId }: SnapshotScope): number;
export declare function revisedChoiceKey(database: DatabaseSync, { stepAttemptId, slotId, questionId }: SnapshotScope, questionVersion: number): string | undefined;
export {};
