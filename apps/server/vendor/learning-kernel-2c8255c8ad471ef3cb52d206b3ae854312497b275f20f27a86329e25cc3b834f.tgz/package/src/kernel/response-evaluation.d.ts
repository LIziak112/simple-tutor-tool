import type { DatabaseSync } from "node:sqlite";
import type { SubmissionReceipt, VersionRef } from "../contracts/reading.ts";
import type { IndexResponseEvaluatorRegistration, ResponseEvaluationInput, ResponseEvaluatorRegistration, ResponseVerdict } from "../contracts/response-evaluation.ts";
import type { IndexResponseConfirmation, ResponseConfirmation, StoredResponseValue } from "../contracts/response.ts";
import type { ReadingActivity } from "./activity.ts";
import { assessmentTarget } from "./verdict-state.ts";
export type EvaluationQuestion<Value> = {
    questionId: string;
    questionVersion: number;
    value: Value | null;
};
type EvaluationContext = Omit<ResponseEvaluationInput, keyof EvaluationQuestion<StoredResponseValue> | "acceptedResponse">;
type PrepareEvaluation<Value> = (ref: VersionRef, key: unknown, context: EvaluationContext) => (question: EvaluationQuestion<Value>) => ResponseVerdict;
export declare function scalarResponseEvaluation(database: DatabaseSync, registered: readonly ResponseEvaluatorRegistration[]): (activity: ReadingActivity, receipt: SubmissionReceipt, confirmation: ResponseConfirmation) => {
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    needsReviewCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        result: {
            status: "judged";
            correct: boolean;
        } | {
            status: "needsReview";
        };
    }[];
};
export declare function indexResponseEvaluation(database: DatabaseSync, registered: readonly IndexResponseEvaluatorRegistration[]): (activity: ReadingActivity, receipt: SubmissionReceipt, confirmation: IndexResponseConfirmation) => {
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    needsReviewCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        result: {
            status: "judged";
            correct: boolean;
        } | {
            status: "needsReview";
        };
    }[];
};
export declare function recoverEvaluatedResponses<Value extends StoredResponseValue>(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, confirmed: readonly EvaluationQuestion<Value>[], prepareEvaluation: PrepareEvaluation<Value>, target: ReturnType<typeof assessmentTarget>): {
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    needsReviewCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        result: {
            status: "judged";
            correct: boolean;
        } | {
            status: "needsReview";
        };
    }[];
};
export {};
