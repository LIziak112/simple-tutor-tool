import type { DatabaseSync } from "node:sqlite";
import type { AuthorizeConfirmationRecovery, ConfirmationKey, VerifyOriginal } from "../contracts/choice-confirmation.ts";
import type { QuestionDeliveryInput } from "../contracts/question-delivery.ts";
import type { PublicationEvaluators } from "./publication-bindings.ts";
export declare function confirmQuestionDelivery(database: DatabaseSync, studentId: string, activityId: string, input: QuestionDeliveryInput, clock: () => Date, verifyOriginal?: VerifyOriginal, authorize?: AuthorizeConfirmationRecovery): {
    id: string;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export declare function recoverQuestionDelivery(database: DatabaseSync, studentId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeConfirmationRecovery | undefined, registered: PublicationEvaluators): {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: string | boolean | string[] | number[] | null;
        }[];
    };
    requestQuestions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
    }[];
    draftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
    evaluation: {
        evaluator: {
            id: string;
            version: number;
        };
        questionCount: number;
        correctCount: number;
        needsReviewCount: number;
        questions: {
            questionId: string;
            questionVersion: number;
            result: {
                status: "judged";
                correct: boolean;
            } | {
                status: "needsReview";
            };
        }[];
    };
};
