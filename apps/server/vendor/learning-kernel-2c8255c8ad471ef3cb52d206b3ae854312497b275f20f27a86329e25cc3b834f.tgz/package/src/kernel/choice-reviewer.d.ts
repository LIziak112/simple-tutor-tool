import type { DatabaseSync } from "node:sqlite";
import type { ChoiceReviewerScope } from "../contracts/choice-amendment.ts";
import type { ChoiceDraftScope } from "../contracts/choice-draft.ts";
export declare function requireChoiceReviewerActivity(database: DatabaseSync, reviewerId: string, activityId: string, question: ChoiceDraftScope, authorize: (scope: ChoiceReviewerScope) => boolean | undefined): {
    activity: {
        activityId: string;
        stepAttemptId: string;
        startedAt: string;
        completed: boolean;
        kind: "reading";
        material: {
            id: string;
            version: number;
            source: string;
            title: string;
            paragraphs: {
                id: string;
                text: string;
            }[];
        } | undefined;
        practice: {
            id: string;
            version: number;
            formatVersion: 1;
            title: string;
            material?: {
                id: string;
                version: number;
            } | undefined;
            goals: Record<string, string>;
            steps: [{
                id: string;
                requires?: string | undefined;
                instructions: string;
                tool: {
                    id: string;
                    version: number;
                };
                inputs: Record<string, {
                    from: "material";
                    positionId: string;
                    material?: {
                        id: string;
                        version: number;
                    } | undefined;
                } | {
                    from: "questions";
                } | {
                    stepId: string;
                    slotId: string;
                    from: "submission";
                    readOnly: true;
                }>;
                submit: {
                    purpose: "finalAnswer" | "stepEvidence";
                    slots: Record<string, {
                        type: "reuse";
                        source: string;
                    } | {
                        source: string;
                        targetId: string;
                        type: "passageSelection";
                        oneRangePerRole: Record<string, string>;
                        distinctParagraphs: boolean;
                        evidenceUnit: "wholeSelection";
                    } | {
                        source: string;
                        targetId: string;
                        type: "oneChoicePerQuestion";
                        reasonTargetId?: string | undefined;
                        confirmFromDrafts?: {
                            allowUnanswered: boolean;
                        } | undefined;
                    } | {
                        source: string;
                        targetId: string;
                        type: "oneResponsePerQuestion";
                        input: "booleanOrString" | "optionIndexArray";
                        confirmFromDrafts: {
                            allowUnanswered: boolean;
                        };
                    } | {
                        source: string;
                        targetId: string;
                        type: "questionDelivery";
                        delivery: {
                            mode: "whole";
                        } | {
                            mode: "perQuestion";
                            questionSlots: {
                                [k: string]: string;
                            };
                        };
                        confirmFromDrafts: {
                            allowUnanswered: boolean;
                        };
                    }>;
                };
                afterConfirmation: "advance" | "finish";
            }, ...{
                id: string;
                requires?: string | undefined;
                instructions: string;
                tool: {
                    id: string;
                    version: number;
                };
                inputs: Record<string, {
                    from: "material";
                    positionId: string;
                    material?: {
                        id: string;
                        version: number;
                    } | undefined;
                } | {
                    from: "questions";
                } | {
                    stepId: string;
                    slotId: string;
                    from: "submission";
                    readOnly: true;
                }>;
                submit: {
                    purpose: "finalAnswer" | "stepEvidence";
                    slots: Record<string, {
                        type: "reuse";
                        source: string;
                    } | {
                        source: string;
                        targetId: string;
                        type: "passageSelection";
                        oneRangePerRole: Record<string, string>;
                        distinctParagraphs: boolean;
                        evidenceUnit: "wholeSelection";
                    } | {
                        source: string;
                        targetId: string;
                        type: "oneChoicePerQuestion";
                        reasonTargetId?: string | undefined;
                        confirmFromDrafts?: {
                            allowUnanswered: boolean;
                        } | undefined;
                    } | {
                        source: string;
                        targetId: string;
                        type: "oneResponsePerQuestion";
                        input: "booleanOrString" | "optionIndexArray";
                        confirmFromDrafts: {
                            allowUnanswered: boolean;
                        };
                    } | {
                        source: string;
                        targetId: string;
                        type: "questionDelivery";
                        delivery: {
                            mode: "whole";
                        } | {
                            mode: "perQuestion";
                            questionSlots: {
                                [k: string]: string;
                            };
                        };
                        confirmFromDrafts: {
                            allowUnanswered: boolean;
                        };
                    }>;
                };
                afterConfirmation: "advance" | "finish";
            }[]];
            grading: {
                selectionFeedback?: {
                    from: {
                        stepId: string;
                        slotId: string;
                    };
                    criterion: string;
                } | undefined;
                assessment?: {
                    from: {
                        stepId: string;
                        slotId: string;
                    };
                    evaluator: {
                        id: string;
                        version: number;
                    };
                    keyRef: {
                        id: string;
                        version: number;
                    };
                    unit: "question";
                    effectiveVerdictOrder: ["teacherReview", "automatic"];
                } | undefined;
            };
            policy: {
                timeLimit?: {
                    minutes: number;
                    startsAt: "instanceStarted";
                    onDeadline: "keepDraftAndClose";
                } | undefined;
                offline: "onlineOnly";
                redo: "newInstanceOnAuthorization";
                student: {
                    ownSubmission: {
                        scope: "ownConfirmedSubmissions";
                        fields: ("ownChoices" | "ownResponses" | "receipt" | "submittedQuotes")[];
                        onFinal: "passageGradingStatus"[];
                    };
                    passageScore?: {
                        whenAll: ["finalConfirmed", "allQuestionsJudged"];
                        group: "wholePassage";
                        fields: ("correctCount" | "questionCount")[];
                        allowSubsets: false;
                        drilldown: false;
                    } | undefined;
                    review?: {
                        requires: "passageScore";
                        while: "reviewOpen";
                        byQuestion: "effectiveVerdict"[];
                        byQuoteSet: "learnerFeedback"[];
                    } | undefined;
                };
                reviewer: {
                    scope: "assignedReviewer";
                    fields: ("gradingBasis" | "learnerFeedback" | "studentChoices" | "submittedQuotes" | "verdictHistory")[];
                    actions: ("commentOnQuotes" | "reviseQuestionVerdict")[];
                };
                manager: {
                    scope: "assigningTeacher";
                    actions: ("authorizeRedo" | "closeReview" | "openReview")[];
                };
                externalAi: "disabled";
            };
            questions: ({
                id: string;
                version?: number | undefined;
                prompt: string;
                options: Record<string, string>;
                response?: "booleanOrString" | "choice" | "optionIndexArray" | undefined;
            } | {
                id: string;
                version?: number | undefined;
                prompt: string;
                response: "orderedTextBlanks";
                blankCount: number;
                options: Record<string, never>;
            })[];
        };
        step: {
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: "booleanOrString" | "optionIndexArray";
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        };
        choiceSnapshotRevisions: {
            slotId: string;
            questionId: string;
            questionVersion: number;
            revision: number;
        }[];
        redoOf: string | undefined;
        practiceVersion: number | undefined;
    };
    scope: {
        reviewerId: string;
        studentId: string;
        activityId: string;
        stepAttemptId: string;
        slotId: string;
        questionId: string;
        questionVersion: number;
    };
};
