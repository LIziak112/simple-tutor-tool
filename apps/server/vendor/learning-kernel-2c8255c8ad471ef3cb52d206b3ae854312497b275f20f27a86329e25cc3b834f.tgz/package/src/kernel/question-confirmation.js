import { hasStoredResponse, sameStoredResponse } from "../contracts/response.js";
import { queueEvaluation } from "./evaluation.js";
import { LearningError } from "./learning-error.js";
import { finishActivity, recordSubmission, submissionForOperation } from "./submission-store.js";
import { loadWorkVersion, saveWorkVersion } from "./work-versions.js";
export function confirmedDraftChangeCount(question, draft, field) {
    if (question[field] === null)
        return 0;
    if (draft?.revision !== question.revision || !sameStoredResponse(draft[field], question[field]) || draft.questionVersion !== question.questionVersion) {
        throw new Error("已确认作答缺少对应的草稿版本");
    }
    return draft.changeCount;
}
export function requireConfirmationRecovery(scope, authorize) {
    if (authorize?.(scope) !== true)
        throw new LearningError(403, "FORBIDDEN");
}
export function mapConfirmationQuestions(activity, revisions, project) {
    const frozen = activity.practice.questions;
    const selected = new Map(revisions.map(question => [question.questionId, question]));
    if (selected.size !== frozen.length || selected.size !== revisions.length) {
        throw new LearningError(422, "INVALID_QUESTION_SET");
    }
    return frozen.map(question => {
        const requested = selected.get(question.id);
        if (!requested)
            throw new LearningError(422, "INVALID_QUESTION_SET");
        if (requested.questionVersion !== question.version)
            throw new LearningError(409, "QUESTION_REVISION_STALE");
        return project(requested);
    });
}
export function writeQuestionConfirmation(database, activity, studentId, input, targetId, content, now, verify, { slotId = input.slotId, finishes = true } = {}) {
    const { activityId } = activity;
    const write = { ...input, slotId };
    const { stepAttemptId } = write;
    verifyQuestionOriginals(studentId, activityId, write, content.questions, verify);
    const draft = saveWorkVersion(database, workScope(activityId, stepAttemptId, slotId), content);
    const observations = content.questions.flatMap(question => hasStoredResponse("choice" in question ? question.choice : question.value)
        ? [{ targetId, unitId: `question:${question.questionId}` }] : []);
    const receipt = recordSubmission(database, { ...write, draft }, observations, now);
    queueEvaluation(database, activity, receipt, targetId, input.slotId);
    if (finishes)
        finishActivity(database, activityId, receipt.id);
    return receipt;
}
function verifyQuestionOriginals(studentId, activityId, { stepAttemptId, slotId, operationId }, questions, verify) {
    for (const { questionId, questionVersion, original } of questions) {
        if (!verify && original.state === "uncollected")
            continue;
        if (verify?.({ studentId, activityId, stepAttemptId, slotId, operationId, questionId, questionVersion, original: { ...original } }) !== true) {
            throw new LearningError(409, "ORIGINAL_NOT_VERIFIED");
        }
    }
}
export function confirmedWorkForOperation(database, activityId, input) {
    const previous = submissionForOperation(database, input);
    if (!previous)
        return undefined;
    const { receipt, draft } = previous;
    return { receipt, content: loadWorkVersion(database, workScope(activityId, receipt.stepAttemptId, receipt.slotId), draft) };
}
export function replayQuestionConfirmation(receipt, intent, input) {
    if (receipt.slotId !== input.slotId || !intent || !sameQuestionIntent(intent, input.questions)) {
        throw new LearningError(409, "OPERATION_CONFLICT");
    }
    return receipt;
}
export function sameQuestionIntent(left, right) {
    return questionIntent(left) === questionIntent(right);
}
function questionIntent(questions) {
    return JSON.stringify(questions.toSorted((a, b) => a.questionId === b.questionId ? 0 : a.questionId < b.questionId ? -1 : 1));
}
function workScope(activityId, stepAttemptId, slotId) {
    return { activityId, step: { id: stepAttemptId, slotId } };
}
