import { questionDeliveryIntent, questionDeliveryView, readQuestionDelivery } from "../contracts/question-delivery.js";
import { hasStoredResponse } from "../contracts/response.js";
import { loadStudentReadingActivity } from "./activity.js";
import { writeTransaction } from "./database.js";
import { LearningError } from "./learning-error.js";
import { confirmedDraftChangeCount, confirmedWorkForOperation, mapConfirmationQuestions, requireConfirmationRecovery, sameQuestionIntent, writeQuestionConfirmation, } from "./question-confirmation.js";
import { deliveryDraftHead, QuestionDeliveryConflict, questionDeliveryPosition, requireFrozenQuestion, requireQuestionDeliverySlot, } from "./question-delivery-drafts.js";
import { recoverQuestionDeliveryEvaluation } from "./question-delivery-evaluation.js";
import { requireBeforeDeadline } from "./reading-progress.js";
import { submittedSlots } from "./submission-store.js";
export function confirmQuestionDelivery(database, studentId, activityId, input, clock, verifyOriginal, authorize) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, input.stepAttemptId);
        const previous = confirmedWorkForOperation(database, activityId, input);
        if (previous) {
            requireConfirmationRecovery({ studentId, activityId, stepAttemptId: input.stepAttemptId, operationId: input.operationId }, authorize);
            const content = readQuestionDelivery(previous.content);
            if (!content || content.source !== input.source || content.slotId !== input.slotId || !sameQuestionIntent(questionDeliveryIntent(content), input.questions)) {
                throw new LearningError(409, "OPERATION_CONFLICT");
            }
            return previous.receipt;
        }
        if (activity.completed)
            throw new LearningError(409, "ALREADY_SUBMITTED");
        const slot = requireQuestionDeliverySlot(activity, input.slotId);
        const now = clock();
        requireBeforeDeadline(activity, now);
        const { requestQuestions, selected, ...placement } = deliveryPlacement(database, activity, input, slot);
        const questions = selected.map(question => freezeDeliveryDraft(database, activity, input.slotId, slot, question));
        const content = { kind: "questionDelivery", slotId: input.slotId, questions };
        const submitted = input.source === "finish" ? { ...content, source: input.source, requestQuestions } : { ...content, source: input.source };
        return writeQuestionConfirmation(database, activity, studentId, input, slot.targetId, submitted, now, verifyOriginal, placement);
    });
}
function deliveryPlacement(database, activity, input, slot) {
    if ((input.source === "whole") !== (slot.delivery.mode === "whole"))
        throw new LearningError(422, "INVALID_SLOT");
    const submitted = submittedSlots(database, activity.stepAttemptId);
    if (input.source === "question") {
        const [question] = input.questions;
        requireFrozenQuestion(activity, question);
        const slotId = questionDeliveryPosition(slot, input.slotId, question.questionId);
        if (submitted.has(slotId))
            throw new LearningError(409, "ALREADY_SUBMITTED");
        return { slotId, finishes: submitted.size + 1 === activity.practice.questions.length, selected: [question], requestQuestions: [question] };
    }
    const requestQuestions = mapConfirmationQuestions(activity, input.questions, question => question);
    const selected = requestQuestions.filter(question => !submitted.has(questionDeliveryPosition(slot, input.slotId, question.questionId)));
    if (!selected.length)
        throw new LearningError(409, "ALREADY_SUBMITTED");
    return { slotId: input.slotId, finishes: true, selected, requestQuestions };
}
function freezeDeliveryDraft(database, activity, logicalSlotId, slot, question) {
    const slotId = questionDeliveryPosition(slot, logicalSlotId, question.questionId);
    const head = deliveryDraftHead(database, activity, slotId, question.questionId);
    const { revision, value } = head ?? { revision: 0, value: null };
    if (revision !== question.revision)
        throw new QuestionDeliveryConflict({ revision, value }, "ANSWER_REVISION_CONFLICT", question.questionId);
    if (!hasStoredResponse(value) && !slot.confirmFromDrafts.allowUnanswered)
        throw new LearningError(422, "UNANSWERED_QUESTION");
    return { ...question, value };
}
export function recoverQuestionDelivery(database, studentId, activityId, key, authorize, registered) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, key.stepAttemptId);
        requireConfirmationRecovery({ studentId, activityId, stepAttemptId: key.stepAttemptId, operationId: key.operationId }, authorize);
        const recovered = confirmedWorkForOperation(database, activityId, key);
        const content = recovered && readQuestionDelivery(recovered.content);
        if (!recovered || !content)
            throw new LearningError(404, "CONFIRMATION_NOT_FOUND");
        const { receipt } = recovered;
        const { id, version } = activity.practice;
        const slot = requireQuestionDeliverySlot(activity, content.slotId);
        const draftChangeCounts = content.questions.map(question => {
            const slotId = questionDeliveryPosition(slot, content.slotId, question.questionId);
            const draft = deliveryDraftHead(database, activity, slotId, question.questionId);
            return { questionId: question.questionId, changeCount: confirmedDraftChangeCount(question, draft || undefined, "value") };
        });
        const evaluation = recoverQuestionDeliveryEvaluation(database, activity, receipt, content, registered);
        return {
            receipt, practice: { id, version }, confirmation: questionDeliveryView(content), requestQuestions: questionDeliveryIntent(content),
            draftChangeCounts, evaluation,
        };
    });
}
