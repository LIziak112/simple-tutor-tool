import type { DatabaseSync } from "node:sqlite";
import type { PublicationEvaluators } from "./publication-bindings.ts";
export declare function registerPublication(database: DatabaseSync, input: unknown, registered?: PublicationEvaluators): void;
