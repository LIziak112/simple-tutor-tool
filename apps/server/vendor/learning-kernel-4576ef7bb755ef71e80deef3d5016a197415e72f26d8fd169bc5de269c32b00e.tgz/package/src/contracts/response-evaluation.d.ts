import { z } from "zod";
import type { ChoiceEvaluationInput } from "./choice-evaluation.ts";
import type { VersionRef } from "./reading.ts";
import type { ResponseValue } from "./response.ts";
export declare const responseVerdict: z.ZodDiscriminatedUnion<[z.ZodObject<{
    status: z.ZodLiteral<"judged">;
    correct: z.ZodBoolean;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodLiteral<"needsReview">;
}, z.core.$strict>], "status">;
export type ResponseVerdict = z.infer<typeof responseVerdict>;
export type ResponseEvaluationInput = Readonly<Omit<ChoiceEvaluationInput, "choice" | "acceptedChoice"> & {
    value: ResponseValue | null;
    acceptedResponse: boolean;
}>;
export type ResponseEvaluator = (input: ResponseEvaluationInput) => ResponseVerdict;
declare const registration: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<ResponseEvaluator, ResponseEvaluator>;
}, z.core.$strict>;
export declare const responseEvaluators: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<ResponseEvaluator, ResponseEvaluator>;
}, z.core.$strict>>;
export type ResponseEvaluatorRegistration = z.infer<typeof registration>;
export declare function findResponseEvaluator(registered: readonly ResponseEvaluatorRegistration[], { id, version }: VersionRef): ResponseEvaluator | undefined;
export {};
