import { z } from "zod";
import { choiceConfirmationInput, confirmedQuestionRevision } from "./choice-confirmation.js";
import { versionedChoiceDraftInput } from "./choice-draft.js";
export const responseValue = z.union([z.boolean(), z.string()]);
export const responseDraftValue = versionedChoiceDraftInput.pick({ questionVersion: true }).extend({ value: responseValue });
export const responseDraftInput = versionedChoiceDraftInput.omit({ choice: true }).extend({ value: responseValue });
export const responseConfirmation = z.strictObject({
    kind: z.literal("responseConfirmation"),
    questions: z.array(confirmedQuestionRevision.extend({ value: responseValue.nullable() })).min(1),
});
const responseConfirmationKind = responseConfirmation.pick({ kind: true }).loose();
export function readResponseConfirmation(content) {
    return responseConfirmationKind.safeParse(content).success ? responseConfirmation.parse(content) : undefined;
}
