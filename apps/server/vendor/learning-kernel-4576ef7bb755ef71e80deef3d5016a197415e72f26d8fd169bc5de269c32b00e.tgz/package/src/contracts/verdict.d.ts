import { z } from "zod";
export declare const verdictLocation: z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    questionId: z.ZodString;
}, z.core.$strict>;
export declare const verdictCommand: z.ZodDiscriminatedUnion<[z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    questionId: z.ZodString;
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
    expectedRevision: z.ZodInt;
    reason: z.ZodString;
    action: z.ZodLiteral<"override">;
    correct: z.ZodBoolean;
}, z.core.$strict>, z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    questionId: z.ZodString;
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
    expectedRevision: z.ZodInt;
    reason: z.ZodString;
    action: z.ZodLiteral<"withdraw">;
    withdrawId: z.ZodUUID;
}, z.core.$strict>], "action">;
export declare const verdictReceipt: z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    questionId: z.ZodString;
    id: z.ZodUUID;
    revision: z.ZodInt;
}, z.core.$strict>;
export type VerdictCommand = z.infer<typeof verdictCommand>;
export type VerdictLocation = z.infer<typeof verdictLocation>;
