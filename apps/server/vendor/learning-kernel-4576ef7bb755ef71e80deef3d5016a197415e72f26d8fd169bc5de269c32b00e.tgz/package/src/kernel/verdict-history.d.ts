import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { VerdictCommand, VerdictLocation } from "../contracts/verdict.ts";
declare const storedEvent: z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    questionId: z.ZodString;
    id: z.ZodUUID;
    revision: z.ZodInt;
    reviewerId: z.ZodString;
    reason: z.ZodString;
    reviewedAt: z.ZodISODateTime;
    action: z.ZodEnum<{
        override: "override";
        withdraw: "withdraw";
    }>;
    correct: z.ZodNullable<z.ZodLiteral<0 | 1>>;
    withdrawId: z.ZodNullable<z.ZodUUID>;
}, z.core.$strict>;
type Event = z.infer<typeof storedEvent>;
export declare function verdictHistory(database: DatabaseSync, assessment: Pick<VerdictLocation, "submissionId" | "targetId">): {
    submissionId: string;
    targetId: string;
    questionId: string;
    id: string;
    revision: number;
    reviewerId: string;
    reason: string;
    reviewedAt: string;
    action: "override" | "withdraw";
    correct: 0 | 1 | null;
    withdrawId: string | null;
}[];
export declare function activeTeacherVerdict(history: Event[]): {
    source: "teacherReview";
    id: string;
    correct: boolean;
} | undefined;
export declare function eventView(event: Event): {
    submissionId: string;
    targetId: string;
    questionId: string;
    id: string;
    revision: number;
    reviewerId: string;
    reason: string;
    reviewedAt: string;
    action: "override" | "withdraw";
    correct: boolean | undefined;
    withdrawId: string | undefined;
};
export declare function repeatedReview(database: DatabaseSync, activityId: string, reviewer: string, command: VerdictCommand): {
    id: string;
    submissionId: string;
    targetId: string;
    questionId: string;
    revision: number;
} | undefined;
export declare function appendReview(database: DatabaseSync, activityId: string, reviewer: string, command: VerdictCommand, clock: () => Date): {
    id: `${string}-${string}-${string}-${string}-${string}`;
    submissionId: string;
    targetId: string;
    questionId: string;
    revision: number;
};
export {};
