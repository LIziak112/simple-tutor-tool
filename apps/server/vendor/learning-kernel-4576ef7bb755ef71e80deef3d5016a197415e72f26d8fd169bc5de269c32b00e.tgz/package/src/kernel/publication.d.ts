import type { DatabaseSync } from "node:sqlite";
import type { ChoiceEvaluatorRegistration } from "../contracts/choice-evaluation.ts";
import type { ResponseEvaluatorRegistration } from "../contracts/response-evaluation.ts";
export declare function registerPublication(database: DatabaseSync, input: unknown, registered?: readonly ChoiceEvaluatorRegistration[], responses?: readonly ResponseEvaluatorRegistration[]): void;
