import { responseDraftValue } from "../contracts/response.js";
import { loadStudentReadingActivity } from "./activity.js";
import { recordChoiceDraftChange } from "./choice-draft-activity.js";
import { writeTransaction } from "./database.js";
import { LearningError } from "./learning-error.js";
import { isLatestQuestionDraftOperation, publicDraft, QuestionDraftConflict, readQuestionDraftHead, readQuestionDraftOperation, readQuestionDrafts, rememberQuestionDraftOperation, } from "./question-draft-store.js";
import { boundOutput } from "./reading-progress.js";
import { saveWorkVersion } from "./work-versions.js";
export class ResponseDraftConflict extends QuestionDraftConflict {
}
export function responseSlot(activity, slotId) {
    const slot = boundOutput(activity.step, slotId);
    if (slot.type !== "oneResponsePerQuestion")
        throw new LearningError(422, "INVALID_SLOT");
    return slot;
}
export function readResponseDrafts(database, activityId, stepAttemptId) {
    return readQuestionDrafts(database, activityId, stepAttemptId, responseDraftValue);
}
export function saveResponseDraft(database, studentId, activityId, input, mode, clock) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, input.stepAttemptId);
        if (activity.completed)
            throw new LearningError(409, "ALREADY_SUBMITTED");
        responseSlot(activity, input.slotId);
        requireQuestionVersion(activity, input);
        return saveCurrentResponse(database, activityId, input, mode, clock);
    });
}
function requireQuestionVersion(activity, input) {
    const question = activity.practice.questions.find(question => question.id === input.questionId);
    if (!question)
        throw new LearningError(422, "INVALID_QUESTION");
    if (question.version !== input.questionVersion)
        throw new LearningError(409, "QUESTION_REVISION_STALE");
}
function saveCurrentResponse(database, activityId, input, mode, clock) {
    const current = readQuestionDraftHead(database, activityId, input, responseDraftValue);
    const previous = readQuestionDraftOperation(database, activityId, input, responseDraftValue);
    if (previous && current)
        return replayResponseOperation(database, input, current, previous);
    const state = current ?? { revision: 0, value: null };
    if (mode === "replayLatestOnly")
        throw new LearningError(409, "DRAFT_REPLAY_REQUIRED");
    if (state.revision !== input.baseRevision)
        throw new ResponseDraftConflict({ revision: state.revision, value: state.value });
    const written = current?.value === input.value ? current : appendResponse(database, activityId, input, current, clock);
    rememberQuestionDraftOperation(database, input, written);
    return publicDraft(written);
}
function replayResponseOperation(database, input, current, previous) {
    if (isLatestQuestionDraftOperation(database, current.workId, input.operationId)
        && previous.baseRevision === input.baseRevision && previous.draft.value === input.value)
        return publicDraft(current);
    throw new ResponseDraftConflict({ revision: current.revision, value: current.value }, "OPERATION_CONFLICT");
}
function appendResponse(database, activityId, input, current, clock) {
    const { stepAttemptId, slotId, questionId, questionVersion, value } = input;
    recordChoiceDraftChange(database, activityId, clock());
    const draft = saveWorkVersion(database, { activityId, step: { id: stepAttemptId, slotId, questionId } }, { questionVersion, value }, current?.workId);
    return {
        workId: draft.id, workVersion: draft.version, slotId, questionId, questionVersion, value,
        revision: (current?.revision ?? 0) + 1, changeCount: (current?.changeCount ?? 0) + 1,
    };
}
