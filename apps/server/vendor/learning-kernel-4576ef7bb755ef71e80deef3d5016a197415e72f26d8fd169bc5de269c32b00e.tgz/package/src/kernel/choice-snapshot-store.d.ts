import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { ChoiceDraftScope } from "../contracts/choice-draft.ts";
import { readingQuestion } from "../contracts/reading-publication.ts";
export declare const choiceSnapshotOffsetForWork = "COALESCE((SELECT MAX(s.revision) FROM choice_snapshot_revisions s\n  WHERE s.step_attempt_id = w.step_attempt_id AND s.slot_id = w.slot_id AND s.question_id = w.question_id), 0)";
type FrozenQuestion = z.infer<typeof readingQuestion>;
type SnapshotScope = Pick<ChoiceDraftScope, "stepAttemptId" | "slotId" | "questionId">;
export declare function effectiveChoiceQuestions(database: DatabaseSync, stepAttemptId: string, published: readonly FrozenQuestion[]): {
    questions: {
        id: string;
        version?: number | undefined;
        prompt: string;
        options: Record<string, string>;
    }[];
    choiceSnapshotRevisions: {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
    }[];
};
export declare function choiceRevisionBeforeAnswers(database: DatabaseSync, { stepAttemptId, slotId, questionId }: SnapshotScope): number;
export declare function revisedChoiceKey(database: DatabaseSync, { stepAttemptId, slotId, questionId }: SnapshotScope, questionVersion: number): string | undefined;
export {};
