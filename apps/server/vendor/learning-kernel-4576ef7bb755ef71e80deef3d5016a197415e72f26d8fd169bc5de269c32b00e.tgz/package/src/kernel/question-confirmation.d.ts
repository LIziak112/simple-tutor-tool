import type { DatabaseSync } from "node:sqlite";
import type { AuthorizeConfirmationRecovery, ChoiceConfirmation, ChoiceConfirmationInput, ConfirmationKey, ConfirmationScope, VerifyOriginal } from "../contracts/choice-confirmation.ts";
import type { ResponseConfirmation } from "../contracts/response.ts";
import type { SubmissionReceipt } from "../contracts/reading.ts";
import type { ReadingActivity } from "./activity.ts";
type QuestionRevision = ChoiceConfirmationInput["questions"][number];
type ConfirmedValue<Key extends "choice" | "value"> = Pick<QuestionRevision, "revision" | "questionVersion"> & Record<Key, string | boolean | null>;
export declare function confirmedDraftChangeCount<Key extends "choice" | "value">(question: ConfirmedValue<Key>, draft: (ConfirmedValue<Key> & {
    changeCount: number;
}) | undefined, field: Key): number;
export declare function requireConfirmationRecovery(scope: ConfirmationScope, authorize?: AuthorizeConfirmationRecovery): void;
export declare function mapConfirmationQuestions<T>(activity: ReadingActivity, revisions: readonly QuestionRevision[], project: (question: QuestionRevision) => T): T[];
export declare function writeQuestionConfirmation(database: DatabaseSync, activity: ReadingActivity, studentId: string, input: ChoiceConfirmationInput, targetId: string, content: ChoiceConfirmation | ResponseConfirmation, now: Date, verify?: VerifyOriginal): {
    id: `${string}-${string}-${string}-${string}-${string}`;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export declare function confirmedWorkForOperation(database: DatabaseSync, activityId: string, input: ConfirmationKey): {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    content: unknown;
} | undefined;
export declare function replayQuestionConfirmation(receipt: SubmissionReceipt, intent: QuestionRevision[] | undefined, input: ChoiceConfirmationInput): {
    id: string;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export {};
