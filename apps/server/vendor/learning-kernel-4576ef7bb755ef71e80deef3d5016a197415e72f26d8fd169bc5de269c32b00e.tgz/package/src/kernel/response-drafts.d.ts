import type { DatabaseSync } from "node:sqlite";
import type { CurrentChoiceDraftMode } from "../contracts/choice-draft.ts";
import type { ResponseDraftInput, ResponseValue } from "../contracts/response.ts";
import type { ReadingActivity } from "./activity.ts";
import { QuestionDraftConflict } from "./question-draft-store.ts";
export declare class ResponseDraftConflict extends QuestionDraftConflict<{
    revision: number;
    value: ResponseValue | null;
}> {
}
export declare function responseSlot(activity: ReadingActivity, slotId: string): {
    source: string;
    targetId: string;
    type: "oneResponsePerQuestion";
    input: "booleanOrString";
    confirmFromDrafts: {
        allowUnanswered: boolean;
    };
};
export declare function readResponseDrafts(database: DatabaseSync, activityId: string, stepAttemptId: string): Omit<{
    workId: string;
    slotId: string;
    questionId: string;
    workVersion: number;
    revision: number;
    changeCount: number;
} & {
    questionVersion: number;
    value: string | boolean;
}, "workId" | "workVersion">[];
export declare function saveResponseDraft(database: DatabaseSync, studentId: string, activityId: string, input: ResponseDraftInput, mode: CurrentChoiceDraftMode, clock: () => Date): Omit<{
    workId: string;
    workVersion: number;
    slotId: string;
    questionId: string;
    questionVersion: number;
    value: string | boolean;
    revision: number;
    changeCount: number;
}, "workId" | "workVersion">;
