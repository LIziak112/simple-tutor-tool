import type { DatabaseSync } from "node:sqlite";
import type { SubmissionReceipt } from "../contracts/reading.ts";
import type { ReadingActivity } from "./activity.ts";
import type { RuntimeCheckpoint } from "./runtime-checkpoint.ts";
export declare function queueEvaluation(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, targetId: string): void;
export declare function evaluatePending(database: DatabaseSync, checkpoint?: RuntimeCheckpoint): void;
export declare function loadEvaluationKey(database: DatabaseSync, submissionId: string): unknown;
export declare function recordEvaluation(database: DatabaseSync, { submissionId, targetId }: {
    submissionId: string;
    targetId: string;
}, verdicts: readonly {
    questionId: string;
    correct: boolean;
}[], checkpoint?: RuntimeCheckpoint): void;
