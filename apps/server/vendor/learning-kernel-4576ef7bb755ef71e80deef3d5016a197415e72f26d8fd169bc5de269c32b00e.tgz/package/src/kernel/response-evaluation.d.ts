import type { DatabaseSync } from "node:sqlite";
import type { SubmissionReceipt } from "../contracts/reading.ts";
import type { ResponseEvaluatorRegistration } from "../contracts/response-evaluation.ts";
import type { ResponseConfirmation } from "../contracts/response.ts";
import type { ReadingActivity } from "./activity.ts";
export declare function recoverResponseEvaluation(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, confirmation: ResponseConfirmation, registered: readonly ResponseEvaluatorRegistration[]): {
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    needsReviewCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        result: {
            status: "judged";
            correct: boolean;
        } | {
            status: "needsReview";
        };
    }[];
};
