import { readResponseConfirmation } from "../contracts/response.js";
import { loadStudentReadingActivity } from "./activity.js";
import { writeTransaction } from "./database.js";
import { LearningError } from "./learning-error.js";
import { confirmedDraftChangeCount, confirmedWorkForOperation, mapConfirmationQuestions, replayQuestionConfirmation, requireConfirmationRecovery, writeQuestionConfirmation, } from "./question-confirmation.js";
import { requireBeforeDeadline } from "./reading-progress.js";
import { readResponseDrafts, ResponseDraftConflict, responseSlot } from "./response-drafts.js";
import { recoverResponseEvaluation } from "./response-evaluation.js";
export class ResponseConfirmationConflict extends ResponseDraftConflict {
    questionId;
    constructor(questionId, current) {
        super(current);
        this.questionId = questionId;
    }
}
export function confirmResponses(database, studentId, activityId, input, clock, verifyOriginal) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, input.stepAttemptId);
        const previous = confirmedWorkForOperation(database, activityId, input);
        if (previous) {
            const intent = readResponseConfirmation(previous.content)?.questions.map(({ value, ...revision }) => revision);
            return replayQuestionConfirmation(previous.receipt, intent, input);
        }
        if (activity.completed)
            throw new LearningError(409, "ALREADY_SUBMITTED");
        const slot = responseSlot(activity, input.slotId);
        const now = clock();
        requireBeforeDeadline(activity, now);
        const questions = freezeResponses(database, activity, input, slot.confirmFromDrafts.allowUnanswered);
        return writeQuestionConfirmation(database, activity, studentId, input, slot.targetId, { kind: "responseConfirmation", questions }, now, verifyOriginal);
    });
}
export function recoverResponseConfirmation(database, studentId, activityId, key, authorize, registered) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, key.stepAttemptId);
        requireConfirmationRecovery({ studentId, activityId, stepAttemptId: key.stepAttemptId, operationId: key.operationId }, authorize);
        const previous = confirmedWorkForOperation(database, activityId, key);
        const confirmation = previous && readResponseConfirmation(previous.content);
        if (!previous || !confirmation)
            throw new LearningError(404, "CONFIRMATION_NOT_FOUND");
        const { receipt } = previous;
        const { id, version } = activity.practice;
        const evaluation = recoverResponseEvaluation(database, activity, receipt, confirmation, registered);
        const drafts = draftsOfResponses(database, activityId, receipt);
        const responseDraftChangeCounts = confirmation.questions.map(question => ({
            questionId: question.questionId, changeCount: confirmedDraftChangeCount(question, drafts.get(question.questionId), "value"),
        }));
        return { receipt, practice: { id, version }, confirmation, responseDraftChangeCounts, evaluation };
    });
}
function freezeResponses(database, activity, input, allowUnanswered) {
    const drafts = draftsOfResponses(database, activity.activityId, input);
    return mapConfirmationQuestions(activity, input.questions, requested => {
        const current = drafts.get(requested.questionId) ?? { revision: 0, value: null };
        if (requested.revision !== current.revision) {
            throw new ResponseConfirmationConflict(requested.questionId, { revision: current.revision, value: current.value });
        }
        if (current.value === null && !allowUnanswered)
            throw new LearningError(422, "UNANSWERED_QUESTION");
        return { ...requested, value: current.value };
    });
}
function draftsOfResponses(database, activityId, { stepAttemptId, slotId }) {
    return new Map(readResponseDrafts(database, activityId, stepAttemptId).filter(draft => draft.slotId === slotId)
        .map(draft => [draft.questionId, draft]));
}
