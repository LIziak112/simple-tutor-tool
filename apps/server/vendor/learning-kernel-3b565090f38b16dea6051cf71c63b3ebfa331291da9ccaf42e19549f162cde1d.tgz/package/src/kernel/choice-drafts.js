import { z } from "zod";
import { choiceDraftValue } from "../contracts/choice-draft.js";
import { loadStudentReadingActivity } from "./activity.js";
import { recordChoiceDraftChange } from "./choice-draft-activity.js";
import { writeTransaction } from "./database.js";
import { LearningError } from "./learning-error.js";
import { boundOutput } from "./reading-progress.js";
import { saveWorkVersion } from "./work-versions.js";
export class ChoiceDraftConflict extends LearningError {
    current;
    constructor(current, code = "ANSWER_REVISION_CONFLICT") {
        super(409, code);
        this.current = current;
    }
}
const storedVersion = z.object({
    workId: z.uuid(), slotId: z.string(), questionId: z.string(), revision: z.int().positive(), content: z.string(),
});
const storedOperation = storedVersion.extend({ baseRevision: z.int().nonnegative() });
const currentDrafts = `
  SELECT w.id AS workId, w.slot_id AS slotId, w.question_id AS questionId, v.version AS revision, v.selection AS content
  FROM works w JOIN work_versions v ON v.work_id = w.id
    AND v.version = (SELECT MAX(version) FROM work_versions WHERE work_id = w.id)
  WHERE w.activity_id = ? AND w.step_attempt_id = ? AND w.question_id IS NOT NULL
`;
function decodeChoice({ content, ...version }) {
    return { ...version, ...choiceDraftValue.parse(JSON.parse(content)) };
}
function draftReceipt({ workId, ...draft }) {
    return { ...draft, changeCount: draft.revision };
}
export function readChoiceDrafts(database, activityId, stepAttemptId) {
    return database.prepare(currentDrafts + "ORDER BY w.slot_id, w.question_id").all(activityId, stepAttemptId)
        .map(row => draftReceipt(decodeChoice(storedVersion.parse(row))));
}
export function saveChoiceDraft(database, student, activityId, input, clock) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, student, activityId, input.stepAttemptId);
        if (input.operationId !== undefined)
            return draftReceipt(saveVersionedChoice(database, activity, input, clock));
        requireWritableChoice(requireDraftQuestion(activity, input), input.choice);
        return draftReceipt(saveUnversionedChoice(database, activityId, input, clock));
    });
}
export function saveCurrentChoiceDraft(database, student, activityId, input, mode, clock) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, student, activityId, input.stepAttemptId);
        const question = requireDraftQuestion(activity, input);
        if (input.operationId !== undefined)
            return draftReceipt(saveAtCurrentHead(database, activityId, question, input, mode, clock));
        requireSaveMode(mode);
        requireWritableChoice(question, input.choice);
        return draftReceipt(saveUnversionedChoice(database, activityId, input, clock));
    });
}
function saveAtCurrentHead(database, activityId, question, input, mode, clock) {
    const current = readChoiceHead(database, activityId, input);
    if (current && isLatestOperation(database, current.workId, input.operationId)) {
        if (current.choice !== input.choice)
            throw new ChoiceDraftConflict({ revision: current.revision, choice: current.choice });
        return current;
    }
    requireSaveMode(mode);
    requireWritableChoice(question, input.choice);
    const head = writeAtRevision(database, activityId, input, current, clock);
    rememberVersionedChoice(database, input, head);
    return head;
}
function requireSaveMode(mode) {
    if (mode === "replayLatestOnly")
        throw new LearningError(409, "DRAFT_REPLAY_REQUIRED");
}
function isLatestOperation(database, workId, operationId) {
    return Boolean(database.prepare(`
    SELECT 1 FROM choice_draft_latest_operations WHERE work_id = ? AND operation_id = ?
  `).get(workId, operationId));
}
function saveVersionedChoice(database, activity, input, clock) {
    const { activityId } = activity;
    const previous = recoverOperation(database, activityId, input);
    if (previous)
        return previous;
    requireWritableChoice(requireDraftQuestion(activity, input), input.choice);
    const current = readChoiceHead(database, activityId, input);
    const head = writeAtRevision(database, activityId, input, current, clock);
    rememberVersionedChoice(database, input, head);
    return head;
}
function rememberVersionedChoice(database, input, head) {
    database.prepare(`
    INSERT INTO choice_draft_operations (work_id, operation_id, base_revision, revision)
    VALUES (?, ?, ?, ?) ON CONFLICT (work_id, operation_id) DO NOTHING
  `).run(head.workId, input.operationId, input.baseRevision, head.revision);
    database.prepare(`
    INSERT INTO choice_draft_latest_operations (work_id, operation_id) VALUES (?, ?)
    ON CONFLICT (work_id) DO UPDATE SET operation_id = excluded.operation_id
  `).run(head.workId, input.operationId);
}
function saveUnversionedChoice(database, activityId, input, clock) {
    const current = readChoiceHead(database, activityId, input);
    if (current && database.prepare("SELECT 1 FROM choice_draft_operations WHERE work_id = ? LIMIT 1").get(current.workId)) {
        throw new ChoiceDraftConflict({ revision: current.revision, choice: current.choice });
    }
    return appendChoiceVersion(database, activityId, input, current, clock);
}
function recoverOperation(database, activityId, input) {
    const row = database.prepare(`
    SELECT w.id AS workId, w.slot_id AS slotId, w.question_id AS questionId, o.base_revision AS baseRevision,
      o.revision, v.selection AS content
    FROM choice_draft_operations o
    JOIN works w ON w.id = o.work_id
    JOIN work_versions v ON v.work_id = o.work_id AND v.version = o.revision
    WHERE w.activity_id = ? AND w.step_attempt_id = ? AND w.slot_id = ? AND w.question_id = ? AND o.operation_id = ?
  `).get(activityId, input.stepAttemptId, input.slotId, input.questionId, input.operationId);
    if (!row)
        return undefined;
    const { baseRevision, ...stored } = storedOperation.parse(row);
    const draft = decodeChoice(stored);
    if (draft.questionVersion !== input.questionVersion)
        throw new LearningError(409, "OPERATION_CONFLICT");
    if (baseRevision !== input.baseRevision || draft.choice !== input.choice) {
        const current = readChoiceHead(database, activityId, input);
        if (current?.questionVersion !== input.questionVersion)
            throw new LearningError(409, "OPERATION_CONFLICT");
        throw new ChoiceDraftConflict({ revision: current.revision, choice: current.choice }, "OPERATION_CONFLICT");
    }
    return draft;
}
function requireDraftQuestion(activity, input) {
    if (activity.completed)
        throw new LearningError(409, "ALREADY_SUBMITTED");
    const slot = boundOutput(activity.step, input.slotId);
    if (slot.type !== "oneChoicePerQuestion" || activity.step.inputs[slot.source]?.from !== "questions") {
        throw new LearningError(422, "INVALID_SLOT");
    }
    const question = activity.practice.questions.find(question => question.id === input.questionId);
    if (!question)
        throw new LearningError(422, "INVALID_QUESTION");
    if (question.version !== input.questionVersion)
        throw new LearningError(409, "QUESTION_REVISION_STALE");
    return question;
}
function requireWritableChoice(question, choice) {
    if (!Object.hasOwn(question.options, choice))
        throw new LearningError(422, "INVALID_CHOICE");
}
function readChoiceHead(database, activityId, { stepAttemptId, slotId, questionId }) {
    const row = database.prepare(currentDrafts + "AND w.slot_id = ? AND w.question_id = ?")
        .get(activityId, stepAttemptId, slotId, questionId);
    return row && decodeChoice(storedVersion.parse(row));
}
function writeAtRevision(database, activityId, input, current, clock) {
    if (current?.choice === input.choice)
        return current;
    const { revision, choice } = current ?? { revision: 0, choice: null };
    if (revision !== input.baseRevision)
        throw new ChoiceDraftConflict({ revision, choice });
    return appendChoiceVersion(database, activityId, input, current, clock);
}
function appendChoiceVersion(database, activityId, input, current, clock) {
    const { stepAttemptId, slotId, questionId, questionVersion, choice } = input;
    if (current?.choice !== choice)
        recordChoiceDraftChange(database, activityId, clock());
    const scope = { activityId, step: { id: stepAttemptId, slotId, questionId } };
    const draft = saveWorkVersion(database, scope, { questionVersion, choice }, current?.workId);
    return { workId: draft.id, slotId, questionId, revision: draft.version, questionVersion, choice };
}
