import { randomUUID } from "node:crypto";
import { readChoiceConfirmation } from "../contracts/choice-confirmation.js";
import { studentTool } from "../builtins/reading-capabilities.js";
import { selectedText } from "../builtins/selection.js";
import { readingAnswer, readingSelection } from "../contracts/reading-runtime.js";
import { queueEvaluation } from "./evaluation.js";
import { LearningError } from "./learning-error.js";
import { answerObservations, findSource, verifyAnswerReferences } from "./reading-answers.js";
import { studentResults } from "./student-results.js";
import { finishActivity, recordSubmission, recoverReceipt } from "./submission-store.js";
import { loadWorkVersion, saveWorkVersion } from "./work-versions.js";
function stepForAttempt(database, activity, attemptId) {
    const row = database.prepare("SELECT step_id FROM step_attempts WHERE id = ? AND activity_id = ?")
        .get(attemptId, activity.activityId);
    const step = activity.practice.steps.find(step => step.id === row?.step_id);
    if (!step)
        throw new LearningError(403, "FORBIDDEN");
    return step;
}
export function boundOutput(step, slotId) {
    const slot = step.submit.slots[slotId];
    if (!slot || slot.type === "reuse" || !studentTool(step.tool)?.outputs.includes(slot.type)) {
        throw new LearningError(422, "INVALID_SLOT");
    }
    return slot;
}
function workScope(activity, input) {
    return { activityId: activity.activityId, step: { id: input.stepAttemptId, slotId: input.slotId } };
}
export function saveReadingSelection(database, activity, input) {
    const step = stepForAttempt(database, activity, input.stepAttemptId);
    const slot = boundOutput(step, input.slotId);
    if (slot.type !== "passageSelection")
        throw new LearningError(422, "INVALID_SLOT");
    const source = step.inputs[slot.source];
    const { material } = activity;
    if (source?.from !== "material" || !material)
        throw new LearningError(409, "PRACTICE_NOT_RUNNABLE");
    const selection = {
        material: { id: material.id, version: material.version },
        positionId: source.positionId,
        ranges: input.ranges.map(({ role, ...range }) => {
            if (!Object.hasOwn(slot.oneRangePerRole, role))
                throw new LearningError(422, "INVALID_SELECTION");
            return { role, range, text: selectedText(material, range) };
        }),
    };
    const draft = saveWorkVersion(database, workScope(activity, input), selection, input.workId);
    return { draft, selection };
}
export function saveReadingAnswer(database, activity, input) {
    const step = stepForAttempt(database, activity, input.stepAttemptId);
    if (boundOutput(step, input.slotId).type !== "oneChoicePerQuestion")
        throw new LearningError(422, "INVALID_SLOT");
    const { choices, references, reason } = input;
    const answer = readingAnswer.parse({ choices, references, reason });
    verifyAnswerReferences(database, activity.activityId, step, answer);
    return { draft: saveWorkVersion(database, workScope(activity, input), answer, input.workId), answer };
}
export function confirmReadingDraft(database, activity, input, clock, checkpoint) {
    const step = stepForAttempt(database, activity, input.stepAttemptId);
    const repeated = recoverReceipt(database, input);
    if (repeated)
        return repeated;
    if (activity.completed || activity.stepAttemptId !== input.stepAttemptId) {
        throw new LearningError(409, "ALREADY_SUBMITTED");
    }
    const confirmedAt = clock();
    requireBeforeDeadline(activity, confirmedAt);
    const slot = boundOutput(step, input.slotId);
    rejectDraftConfirmation(slot);
    const content = loadWorkVersion(database, workScope(activity, input), input.draft);
    const observations = readingObservations(database, activity, slot, content);
    const receipt = recordSubmission(database, input, observations, confirmedAt);
    if (slot.type === "oneChoicePerQuestion")
        queueEvaluation(database, activity, receipt, slot.targetId);
    if (step.afterConfirmation === "finish")
        finishActivity(database, activity.activityId, receipt.id);
    else
        advanceReading(database, activity);
    checkpoint?.({ point: "beforeConfirmationCommit", operationId: input.operationId });
    return receipt;
}
function rejectDraftConfirmation(slot) {
    if (slot.type === "oneChoicePerQuestion" && slot.confirmFromDrafts)
        throw new LearningError(422, "INVALID_SLOT");
}
export function requireBeforeDeadline(activity, confirmedAt) {
    const limit = activity.practice.policy.timeLimit;
    if (!limit)
        return;
    const deadline = Date.parse(activity.startedAt) + limit.minutes * 60_000;
    if (confirmedAt.getTime() >= deadline)
        throw new LearningError(409, "DEADLINE_PASSED");
}
function readingObservations(database, activity, slot, content) {
    if (slot.type === "oneChoicePerQuestion") {
        const answer = readingAnswer.parse(content);
        verifyAnswerReferences(database, activity.activityId, activity.step, answer);
        return answerObservations(activity, slot, answer);
    }
    const selection = readingSelection.parse(content);
    validateSelection(selection, Object.keys(slot.oneRangePerRole), slot.distinctParagraphs);
    return [{ targetId: slot.targetId, unitId: slot.evidenceUnit }];
}
function validateSelection(selection, requiredRoles, distinctParagraphs) {
    const roles = new Set(selection.ranges.map(item => item.role));
    if (selection.ranges.length !== requiredRoles.length || requiredRoles.some(role => !roles.has(role))) {
        throw new LearningError(422, "INCOMPLETE_SELECTION");
    }
    const paragraphs = new Set(selection.ranges.map(item => item.range.paragraphId));
    if (distinctParagraphs && paragraphs.size !== selection.ranges.length) {
        throw new LearningError(422, "SELECTION_REQUIRES_DISTINCT_PARAGRAPHS");
    }
}
function advanceReading(database, activity) {
    const ordinal = activity.practice.steps.indexOf(activity.step) + 1;
    const next = activity.practice.steps[ordinal];
    if (!next)
        throw new Error("已发布声明缺少下一步");
    database.prepare("INSERT INTO step_attempts (id, activity_id, step_id, ordinal) VALUES (?, ?, ?, ?)")
        .run(randomUUID(), activity.activityId, next.id, ordinal);
}
export function readingActivityView(database, activity, submissions) {
    const { activityId, stepAttemptId, startedAt, step, practice, completed } = activity;
    const submitted = submissions.find(item => item.receipt.stepAttemptId === stepAttemptId);
    const materialBound = Object.values(step.inputs).some(input => input.from === "material");
    const status = completed ? "completed" : "active";
    return {
        formatVersion: practice.formatVersion,
        activityId, stepAttemptId, startedAt, material: materialBound ? activity.material : undefined, redoOf: activity.redoOf,
        title: practice.title,
        step: { id: step.id, instructions: step.instructions, tool: step.tool, submit: step.submit },
        status,
        inputs: readingInputs(activity, submissions),
        submission: submitted ? studentSubmissionView(activity, submitted) : undefined,
        ...studentResults(database, activity),
    };
}
function readingInputs(activity, submissions) {
    const { completed, practice, step } = activity;
    return Object.fromEntries(Object.entries(step.inputs).flatMap(([name, input]) => {
        switch (input.from) {
            case "material": return [[name, { from: input.from, positionId: input.positionId }]];
            case "questions": return [[name, { from: input.from, questions: practice.questions }]];
            case "submission": {
                const submitted = findSource(submissions, input);
                if (!submitted)
                    throw new Error("前序步骤缺少已确认的输入");
                const view = completed ? studentSubmissionView(activity, submitted) : readingSubmissionView(submitted);
                return Object.keys(view).length ? [[name, { from: input.from, ...view }]] : [];
            }
        }
    }));
}
export function studentSubmissionView(activity, submitted) {
    const fields = new Set(activity.practice.policy.student.ownSubmission.fields);
    const receipt = fields.has("receipt") ? { receipt: submitted.receipt } : {};
    const confirmation = readChoiceConfirmation(submitted.content);
    if (confirmation)
        return fields.has("ownChoices") ? { ...receipt, confirmation } : receipt;
    const view = readingSubmissionView(submitted);
    if (view.selection && fields.has("submittedQuotes"))
        return { ...receipt, selection: view.selection };
    if (!view.answer || !fields.has("ownChoices"))
        return receipt;
    const { references, ...answer } = view.answer;
    return { ...receipt, answer: fields.has("receipt") ? { ...answer, references } : answer };
}
export function readingSubmissionView(submitted) {
    const confirmation = readChoiceConfirmation(submitted.content);
    if (confirmation) {
        const choices = Object.fromEntries(confirmation.questions.flatMap(({ questionId, choice }) => choice === null ? [] : [[questionId, choice]]));
        return { receipt: submitted.receipt, answer: { choices, references: {} } };
    }
    const selection = readingSelection.safeParse(submitted.content);
    if (selection.success)
        return { receipt: submitted.receipt, selection: selection.data };
    return { receipt: submitted.receipt, answer: readingAnswer.parse(submitted.content) };
}
