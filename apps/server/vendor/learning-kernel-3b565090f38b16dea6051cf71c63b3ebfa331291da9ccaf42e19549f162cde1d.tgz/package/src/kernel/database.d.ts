import { DatabaseSync } from "node:sqlite";
export declare function openDatabase(path: string): DatabaseSync;
export declare function writeTransaction<Result>(database: DatabaseSync, write: () => Result): Result;
