import { z } from "zod";
export declare const choiceDraftValue: z.ZodObject<{
    questionVersion: z.ZodInt;
    choice: z.ZodString;
}, z.core.$strict>;
declare const unversionedChoiceDraftInput: z.ZodObject<{
    questionVersion: z.ZodInt;
    choice: z.ZodString;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
}, z.core.$strict>;
declare const versionedChoiceDraftInput: z.ZodObject<{
    questionVersion: z.ZodInt;
    choice: z.ZodString;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    operationId: z.ZodString;
    baseRevision: z.ZodInt;
}, z.core.$strict>;
export declare const choiceDraftInput: z.ZodUnion<readonly [z.ZodObject<{
    questionVersion: z.ZodInt;
    choice: z.ZodString;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    operationId: z.ZodString;
    baseRevision: z.ZodInt;
}, z.core.$strict>, z.ZodObject<{
    questionVersion: z.ZodInt;
    choice: z.ZodString;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
}, z.core.$strict>]>;
export declare const currentChoiceDraftMode: z.ZodEnum<{
    replayLatestOnly: "replayLatestOnly";
    save: "save";
}>;
export type CurrentChoiceDraftMode = z.infer<typeof currentChoiceDraftMode>;
export type ChoiceDraftInput = z.infer<typeof versionedChoiceDraftInput>;
export type UnversionedChoiceDraftInput = z.infer<typeof unversionedChoiceDraftInput> & {
    operationId?: never;
    baseRevision?: never;
};
export {};
