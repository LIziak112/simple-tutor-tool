import { z } from "zod";
import { choiceConfirmationInput, confirmationKey } from "./contracts/choice-confirmation.js";
import { choiceDraftInput, currentChoiceDraftMode } from "./contracts/choice-draft.js";
import { choiceEvaluators } from "./contracts/choice-evaluation.js";
import { id, publicationSchema, startInput, versionRef } from "./contracts/reading.js";
import { readingPublicationSchema } from "./contracts/reading-publication.js";
import { startActivity } from "./kernel/activity.js";
import { confirmChoices, recoverChoiceConfirmation } from "./kernel/choice-confirmation.js";
import { readChoiceDraftActivity } from "./kernel/choice-draft-activity.js";
import { saveChoiceDraft, saveCurrentChoiceDraft } from "./kernel/choice-drafts.js";
import { openDatabase } from "./kernel/database.js";
import { LearningError } from "./kernel/learning-error.js";
import { registerPublication } from "./kernel/publication.js";
import { readActivity } from "./kernel/submission.js";
const runtimeOptions = z.strictObject({
    databasePath: z.string().min(1),
    choiceEvaluators: choiceEvaluators.default([]),
    verifyOriginal: z.custom(value => typeof value === "function").optional(),
    authorizeConfirmationRecovery: z.custom(value => typeof value === "function").optional(),
});
const studentPrincipal = z.strictObject({ role: z.literal("student"), id });
const publishedStartInput = startInput.extend({ practiceVersion: versionRef.shape.version });
const uuid = z.uuid();
const clock = () => new Date();
export { LearningError };
export { ChoiceConfirmationConflict } from "./kernel/choice-confirmation.js";
export { ChoiceDraftConflict } from "./kernel/choice-drafts.js";
function studentId(principal) {
    const parsed = studentPrincipal.safeParse(principal);
    if (!parsed.success)
        throw new LearningError(403, "FORBIDDEN");
    return parsed.data.id;
}
export function openLearningRuntime(options) {
    const settings = runtimeOptions.parse(options);
    const database = openDatabase(settings.databasePath);
    return {
        publish(input) {
            registerPublication(database, input, settings.choiceEvaluators);
        },
        start(principal, input) {
            return startActivity(database, studentId(principal), publishedStartInput.parse(input), clock);
        },
        read(principal, activityId) {
            return readActivity(database, studentId(principal), uuid.parse(activityId));
        },
        readChoiceDraftActivity(principal, activityId) {
            return readChoiceDraftActivity(database, studentId(principal), uuid.parse(activityId));
        },
        saveChoiceDraft(principal, activityId, input) {
            return saveChoiceDraft(database, studentId(principal), uuid.parse(activityId), choiceDraftInput.parse(input), clock);
        },
        saveCurrentChoiceDraft(principal, activityId, input, mode = "save") {
            return saveCurrentChoiceDraft(database, studentId(principal), uuid.parse(activityId), choiceDraftInput.parse(input), currentChoiceDraftMode.parse(mode), clock);
        },
        confirmChoices(principal, activityId, input) {
            return confirmChoices(database, studentId(principal), uuid.parse(activityId), choiceConfirmationInput.parse(input), clock, settings.verifyOriginal);
        },
        recoverChoiceConfirmation(principal, activityId, key) {
            return recoverChoiceConfirmation(database, studentId(principal), uuid.parse(activityId), confirmationKey.parse(key), settings.authorizeConfirmationRecovery, settings.choiceEvaluators);
        },
        close() {
            database.close();
        },
    };
}
