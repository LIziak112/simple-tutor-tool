import { z } from "zod";
export declare const activityOpeningKey: z.ZodObject<{
    studentId: z.ZodString;
    operationId: z.ZodString;
}, z.core.$strict>;
export declare const activityBinding: z.ZodObject<{
    studentId: z.ZodString;
    operationId: z.ZodString;
    activityId: z.ZodUUID;
}, z.core.$strict>;
export declare const activityBindingClaims: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    bindings: z.ZodArray<z.ZodObject<{
        studentId: z.ZodString;
        operationId: z.ZodString;
        activityId: z.ZodUUID;
    }, z.core.$strict>>;
    openingIntents: z.ZodArray<z.ZodObject<{
        studentId: z.ZodString;
        operationId: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ActivityBindingClaims = z.infer<typeof activityBindingClaims>;
export type ActivityOpeningKey = z.infer<typeof activityOpeningKey>;
