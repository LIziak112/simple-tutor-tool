var __addDisposableResource = (this && this.__addDisposableResource) || function (env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose, inner;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
            if (async) inner = dispose;
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        if (inner) dispose = function() { try { inner.call(this); } catch (e) { return Promise.reject(e); } };
        env.stack.push({ value: value, dispose: dispose, async: async });
    }
    else if (async) {
        env.stack.push({ async: true });
    }
    return value;
};
var __disposeResources = (this && this.__disposeResources) || (function (SuppressedError) {
    return function (env) {
        function fail(e) {
            env.error = env.hasError ? new SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
            env.hasError = true;
        }
        var r, s = 0;
        function next() {
            while (r = env.stack.pop()) {
                try {
                    if (!r.async && s === 1) return s = 0, env.stack.push(r), Promise.resolve().then(next);
                    if (r.dispose) {
                        var result = r.dispose.call(r.value);
                        if (r.async) return s |= 2, Promise.resolve(result).then(next, function(e) { fail(e); return next(); });
                    }
                    else s |= 1;
                }
                catch (e) {
                    fail(e);
                }
            }
            if (s === 1) return env.hasError ? Promise.reject(env.error) : Promise.resolve();
            if (env.hasError) throw env.error;
        }
        return next();
    };
})(typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
});
import { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import { activityBinding, activityBindingClaims } from "../contracts/activity-bindings.js";
import { LearningError } from "./learning-error.js";
const snapshotPath = z.string().min(1);
export function verifyActivityBindings(databasePath, input) {
    const env_1 = { stack: [], error: void 0, hasError: false };
    try {
        const expected = claimOpenings(activityBindingClaims.parse(input));
        const database = __addDisposableResource(env_1, new DatabaseSync(snapshotPath.parse(databasePath), { readOnly: true }), false);
        const identities = database.prepare("SELECT id AS activityId, student_id AS studentId, start_operation_id AS operationId FROM activities");
        for (const identity of identities.iterate()) {
            const parsed = activityBinding.safeParse(identity);
            if (!parsed.success)
                throw bindingMismatch();
            const key = openingKey(parsed.data);
            const activityId = expected.get(key);
            if (!expected.delete(key) || (activityId !== undefined && activityId !== parsed.data.activityId))
                throw bindingMismatch();
        }
        for (const activityId of expected.values()) {
            if (activityId !== undefined)
                throw bindingMismatch();
        }
    }
    catch (e_1) {
        env_1.error = e_1;
        env_1.hasError = true;
    }
    finally {
        __disposeResources(env_1);
    }
}
function claimOpenings({ bindings, openingIntents }) {
    const expected = new Map();
    for (const binding of bindings)
        addOpening(expected, binding, binding.activityId);
    for (const intent of openingIntents)
        addOpening(expected, intent);
    return expected;
}
function addOpening(expected, opening, activityId) {
    const key = openingKey(opening);
    if (expected.has(key))
        throw bindingMismatch();
    expected.set(key, activityId);
}
function openingKey({ studentId, operationId }) {
    return JSON.stringify([studentId, operationId]);
}
function bindingMismatch() {
    return new LearningError(409, "ACTIVITY_BINDINGS_MISMATCH");
}
