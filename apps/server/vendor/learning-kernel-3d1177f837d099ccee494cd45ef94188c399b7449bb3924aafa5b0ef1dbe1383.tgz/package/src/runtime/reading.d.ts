import type { DatabaseSync } from "node:sqlite";
import type { Registry } from "../kernel/registry.ts";
import type { RuntimeCheckpoint } from "../kernel/runtime-checkpoint.ts";
type Context = {
    database: DatabaseSync;
    registry: Registry;
    clock: () => Date;
    checkpoint: RuntimeCheckpoint | undefined;
};
type Principal = {
    role: string;
    id: string;
};
export declare function readingEntries({ database, registry, clock, checkpoint }: Context): {
    startLatest(principal: Principal, input: unknown, options?: {
        assignedReviewer?: string;
    }): {
        activityId: string;
        stepAttemptId: string;
        startedAt: string;
    };
    redo(principal: Principal, activityId: string, input: unknown): {
        activityId: string;
        stepAttemptId: string;
        startedAt: string;
    };
    saveDraft(principal: Principal, activityId: string, input: unknown): {
        draft: {
            id: string;
            version: number;
        };
        selection: {
            material: {
                id: string;
                version: number;
            };
            positionId: string;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
            text: string;
        };
    } | {
        draft: {
            id: string;
            version: number;
        };
        selection: {
            material: {
                id: string;
                version: number;
            };
            positionId: string;
            ranges: {
                role: string;
                range: {
                    paragraphId: string;
                    start: number;
                    end: number;
                };
                text: string;
            }[];
        };
    } | {
        draft: {
            id: string;
            version: number;
        };
        answer: {
            choices: Record<string, string>;
            references: Record<string, string>;
            reason?: {
                text: string;
                independent: boolean;
            } | undefined;
        };
    };
    submitDraft(principal: Principal, activityId: string, input: unknown): {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    readSubmission(principal: Principal, activityId: string, submissionId: string): {
        receipt?: import("../kernel/submission-store.ts").StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | {
        receipt: {
            id: string;
            stepAttemptId: string;
            slotId: string;
            confirmedAt: string;
        };
        selection: {
            material: {
                id: string;
                version: number;
            };
            positionId: string;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
            text: string;
        };
    };
    readFragment(principal: Principal, activityId: string, submissionId: string): {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        ranges: {
            role: string;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
            text: string;
        }[];
    } | {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        range: {
            paragraphId: string;
            start: number;
            end: number;
        };
        text: string;
    };
    readResults(principal: Principal, activityId: string, resource: "assessment" | "review" | "export"): {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | {
        assessment: {
            status: "pending";
        } | {
            status: "complete";
        } | {
            status: "pending";
        } | undefined;
    } | {
        assessment?: ReturnType<(score: NonNullable<{
            whenAll: ["finalConfirmed", "allQuestionsJudged"];
            group: "wholePassage";
            fields: ("correctCount" | "questionCount")[];
            allowSubsets: false;
            drilldown: false;
        } | undefined>, graded: readonly {
            questionId: string;
            correct: boolean;
        }[]) => {
            status: "complete";
        }> | {
            status: "pending";
        };
        review?: undefined;
        activityId: string;
        status: "abandoned" | "active" | "completed";
        redoOf: string | undefined;
        submissions: {
            receipt?: import("../kernel/submission-store.ts").StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        }[];
    } | {
        assessment: {
            status: "pending";
        } | undefined;
        review?: never;
        activityId: string;
        status: "abandoned" | "active" | "completed";
        redoOf: string | undefined;
        submissions: {
            receipt?: import("../kernel/submission-store.ts").StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        }[];
    } | {
        assessment: {
            status: "complete";
        };
        review: {
            byQuestion: {
                questionId: string;
                correct: boolean;
            }[] | undefined;
            selectionFeedback: string | undefined;
        } | undefined;
        activityId: string;
        status: "abandoned" | "active" | "completed";
        redoOf: string | undefined;
        submissions: {
            receipt?: import("../kernel/submission-store.ts").StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        }[];
    };
    readPersonalDraft(principal: Principal, workId: string): {
        draft: {
            id: string;
            version: number;
        };
        content: {
            ranges: {
                paragraphId: string;
                start: number;
                end: number;
                role: string;
            }[];
            choices?: never;
            reason?: never;
            range?: never;
        } | {
            ranges?: never;
            choices: Record<string, string>;
            reason: {
                text: string;
                independent: boolean;
            } | undefined;
            range?: never;
        } | {
            ranges?: never;
            choices?: never;
            reason?: never;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
        };
    };
    readReadingReview(principal: Principal, activityId: string): {
        activityId: string;
        submissions: ({
            receipt: {
                id: string;
                stepAttemptId: string;
                slotId: string;
                confirmedAt: string;
            };
            selection: {
                material: {
                    id: string;
                    version: number;
                };
                positionId: string;
                ranges: {
                    role: string;
                    range: {
                        paragraphId: string;
                        start: number;
                        end: number;
                    };
                    text: string;
                }[];
            };
            answer?: never;
        } | {
            selection?: never;
            receipt: {
                id: string;
                stepAttemptId: string;
                slotId: string;
                confirmedAt: string;
            };
            answer: {
                choices: Record<string, string>;
                references: Record<string, string>;
                reason?: {
                    text: string;
                    independent: boolean;
                } | undefined;
            };
        })[];
        selectionFeedback: string | null | undefined;
        verdicts?: never;
        automaticVerdicts?: never;
    } | {
        activityId: string;
        submissions: ({
            receipt: {
                id: string;
                stepAttemptId: string;
                slotId: string;
                confirmedAt: string;
            };
            selection: {
                material: {
                    id: string;
                    version: number;
                };
                positionId: string;
                ranges: {
                    role: string;
                    range: {
                        paragraphId: string;
                        start: number;
                        end: number;
                    };
                    text: string;
                }[];
            };
            answer?: never;
        } | {
            selection?: never;
            receipt: {
                id: string;
                stepAttemptId: string;
                slotId: string;
                confirmedAt: string;
            };
            answer: {
                choices: Record<string, string>;
                references: Record<string, string>;
                reason?: {
                    text: string;
                    independent: boolean;
                } | undefined;
            };
        })[];
        selectionFeedback: string | null | undefined;
        verdicts: {
            questionId: string;
            submissionId: string;
            targetId: string;
            revision: number;
            choice: string | undefined;
            prompt: string | undefined;
            effective: {
                source: "teacherReview";
                id: string;
                correct: boolean;
            } | {
                source: "automatic";
                correct: boolean;
            } | undefined;
            automatic: {
                correct: boolean;
                valid: boolean;
            } | undefined;
            history: {
                submissionId: string;
                targetId: string;
                questionId: string;
                id: string;
                revision: number;
                reviewerId: string;
                reason: string;
                reviewedAt: string;
                action: "override" | "withdraw";
                correct: boolean | undefined;
                withdrawId: string | undefined;
            }[] | undefined;
        }[];
        automaticVerdicts: {
            submissionId: string;
            targetId: string;
            questionId: string;
            correct: boolean;
        }[] | undefined;
    };
    writeReadingVerdict(principal: Principal, activityId: string, command: unknown): {
        submissionId: string;
        targetId: string;
        questionId: string;
        id: string;
        revision: number;
    };
    writeSelectionFeedback(principal: Principal, activityId: string, input: unknown): {
        selectionFeedback: string;
    };
    readManagement(principal: Principal, activityId: string): {
        reviewOpen: boolean;
        canToggleReview: boolean;
        reviewerActions: ("commentOnQuotes" | "reviseQuestionVerdict")[];
    };
    manage(principal: Principal, activityId: string, input: unknown): {
        reviewerActive: boolean;
        studentActive?: never;
        redoAuthorized?: never;
        reviewOpen?: never;
    } | {
        reviewerActive?: never;
        studentActive: boolean;
        redoAuthorized?: never;
        reviewOpen?: never;
    } | {
        reviewerActive?: never;
        studentActive?: never;
        redoAuthorized: boolean;
        reviewOpen?: never;
    } | {
        reviewerActive?: never;
        studentActive?: never;
        redoAuthorized?: never;
        reviewOpen: boolean;
    };
};
export {};
