import type { DatabaseSync } from "node:sqlite";
import type { RestartInput } from "../contracts/reading.ts";
export declare function restartActivity(database: DatabaseSync, student: string, sourceId: string, input: RestartInput, clock: () => Date): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
};
