import type { DatabaseSync } from "node:sqlite";
import type { AuthorizeChoiceSnapshotRevision, HasChoiceSnapshotEvidence } from "../contracts/choice-snapshot.ts";
import type { ParsedQuestionDeliverySnapshotRevision } from "../contracts/question-delivery-amendment.ts";
import type { Registry } from "./registry.ts";
type SnapshotPolicy = {
    authorize: AuthorizeChoiceSnapshotRevision | undefined;
    hasEvidence: HasChoiceSnapshotEvidence | undefined;
};
export declare function reviseQuestionDeliverySnapshot(database: DatabaseSync, registry: Registry, reviewer: string, activityId: string, input: ParsedQuestionDeliverySnapshotRevision, clock: () => Date, policy: SnapshotPolicy): {
    questionId: string;
    questionVersion: number;
    revision: number;
    previousQuestionVersion: number;
    slotId: string;
};
export {};
