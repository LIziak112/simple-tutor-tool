import { questionDeliveryReviewBasis } from "../contracts/question-delivery.js";
import { LearningError } from "../contracts/learning-error.js";
import { loadEvaluationKey, queueEvaluation } from "./evaluation.js";
import { readEvaluatedResponses, readResponseReviewRequirements, recordResponseReviewRequirements } from "./response-evaluation.js";
import { submissionAssessmentTarget } from "./verdict-state.js";
export function confirmedDeliveryAssessment({ practice: { grading: { assessment, manualReview, teacherReview } } }, { questions }) {
    const teacherIds = new Set(teacherReview?.questionIds);
    const review = manualReview ? questions : questions.filter(({ questionId }) => teacherIds.has(questionId));
    const automatic = assessment ? questions.filter(({ questionId }) => !teacherIds.has(questionId)) : [];
    return { automatic, review };
}
export function registerDeliveryAssessment(database, activity, receipt, content, targetId) {
    const { automatic, review } = confirmedDeliveryAssessment(activity, content);
    if (automatic.length || activity.practice.grading.manualReview) {
        queueEvaluation(database, activity, receipt, targetId, content.slotId);
    }
    if (review.length)
        recordResponseReviewRequirements(database, receipt.id, review.map(({ questionId }) => questionId));
}
export function recoverQuestionDeliveryAssessment(database, activity, receipt, content, mode) {
    const { automatic, review } = confirmedDeliveryAssessment(activity, content);
    if (automatic.length) {
        const evaluation = studentEvaluation(activity, readEvaluatedResponses(database, activity, receipt, automatic, submissionAssessmentTarget(database, receipt.id)));
        const questions = mode === "declared" && review.length > 0
            ? readManualReviewQuestions(database, receipt, review, true)
            : undefined;
        return { assessment: "automatic", evaluation, ...questions && { review: { questions } } };
    }
    if (mode === "automatic")
        throw new LearningError(409, "ASSESSMENT_MODE_MISMATCH");
    if (review.length) {
        const questions = readManualReviewQuestions(database, receipt, review);
        if (activity.practice.grading.manualReview)
            return { assessment: "manual", review: { questions } };
        return { assessment: "teacherReview", review: { questions } };
    }
    return { assessment: "none" };
}
function studentEvaluation(activity, evaluation) {
    if (evaluation.status !== "evaluated" || !activity.practice.policy.student.passageScore)
        return evaluation;
    return { status: "withheld", evaluator: evaluation.evaluator };
}
export function readManualReviewQuestions(database, receipt, questions, mixed = false) {
    const required = new Set(readResponseReviewRequirements(database, receipt.id));
    if ((!mixed && required.size !== questions.length) || questions.some(({ questionId }) => !required.has(questionId))) {
        throw new Error("人工待评位置与冻结提交不一致");
    }
    return questions.map(({ questionId, questionVersion }) => ({ questionId, questionVersion, status: "needsReview" }));
}
export function readManualReviewBasis(database, receipt, reference) {
    const basis = questionDeliveryReviewBasis.parse(loadEvaluationKey(database, receipt.id));
    if (basis.id !== reference.id || basis.version !== reference.version)
        throw new Error("人工待评引用与冻结依据不一致");
    return basis;
}
