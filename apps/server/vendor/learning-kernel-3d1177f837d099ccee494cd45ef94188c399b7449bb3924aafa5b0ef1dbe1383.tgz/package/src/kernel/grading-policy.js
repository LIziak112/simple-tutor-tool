import { defaultGradingPolicy, gradingPolicy } from "../contracts/grading-policy.js";
const fields = gradingPolicy.keyof().options;
const fieldNames = new Set(fields);
function declaredObject(declared) {
    return typeof declared === "object" && declared !== null && !Array.isArray(declared) ? declared : undefined;
}
function declaredField(declared, field) {
    return Object.hasOwn(declared, field) ? gradingPolicy.shape[field].safeParse(Reflect.get(declared, field)).data : undefined;
}
function unknownVersion(declared) {
    return Object.hasOwn(declared, "version") && declaredField(declared, "version") === undefined;
}
export function resolveGradingPolicy(input) {
    const declared = declaredObject(input);
    const ignored = declared ? Object.keys(declared).filter(field => !fieldNames.has(field)) : [];
    if (!declared || unknownVersion(declared))
        return { policy: { ...defaultGradingPolicy }, fallbacks: fields, ignored };
    const fallbacks = fields.filter(field => declaredField(declared, field) === undefined);
    const policy = gradingPolicy.parse(Object.fromEntries(fields.map(field => [field, declaredField(declared, field) ?? defaultGradingPolicy[field]])));
    return { policy, fallbacks, ignored };
}
export function questionGrading(policy, { automatic, reference }) {
    if (automatic)
        return "automatic";
    return reference ? policy.withReference : "teacherReview";
}
export function routeQuestions(policy, questions) {
    const routed = { automatic: [], selfReview: [], teacherReview: [] };
    for (const { id, facts } of questions)
        routed[questionGrading(policy, facts)].push(id);
    return routed;
}
