import { questionDeliveryDraftValue } from "../contracts/question-delivery.js";
import { responseValue } from "../contracts/response.js";
import { loadStudentReadingActivity } from "./activity.js";
import { writeTransaction } from "./database.js";
import { LearningError } from "../contracts/learning-error.js";
import { QuestionDraftConflict, readQuestionDraftHead, readQuestionDrafts } from "./question-draft-store.js";
import { boundOutput, requireAvailableTool } from "./reading-progress.js";
import { frozenResponseType } from "./question-types.js";
import { saveCurrentResponse } from "./response-drafts.js";
import { submittedSlots } from "./submission-store.js";
export class QuestionDeliveryConflict extends QuestionDraftConflict {
    questionId;
    constructor(current, code, questionId) {
        super(current, code);
        this.questionId = questionId;
    }
}
export function saveQuestionDeliveryDraft(database, registry, studentId, activityId, input, mode, clock) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, input.stepAttemptId);
        requireOpenRound(activity);
        const slot = requireQuestionDeliverySlot(activity, input.slotId);
        requireAvailableTool(registry, activity.step, slot.type);
        const question = requireFrozenQuestion(activity, input);
        const value = responseValue.parse(frozenResponseType(registry, activity.practice, question).parseValue(input.value, question));
        const slotId = questionDeliveryPosition(slot, input.slotId, input.questionId);
        if (submittedSlots(database, activity.stepAttemptId).has(slotId))
            throw new LearningError(409, "ALREADY_SUBMITTED");
        const draft = saveCurrentResponse(database, activityId, { ...input, value, slotId }, mode, clock, QuestionDeliveryConflict);
        return { ...draft, slotId: input.slotId };
    });
}
export function requireOpenRound(activity) {
    if (activity.abandoned)
        throw new LearningError(409, "ACTIVITY_ABANDONED");
    if (activity.completed)
        throw new LearningError(409, "ALREADY_SUBMITTED");
}
export function readOpenDeliveryDrafts(database, activity, logicalSlotId, submitted) {
    return readQuestionDrafts(database, activity.activityId, activity.stepAttemptId, questionDeliveryDraftValue)
        .filter(draft => !submitted.has(draft.slotId)).map(draft => ({ ...draft, slotId: logicalSlotId }));
}
export function deliveryDraftHead(database, activity, slotId, questionId) {
    return readQuestionDraftHead(database, activity.activityId, { stepAttemptId: activity.stepAttemptId, slotId, questionId }, questionDeliveryDraftValue);
}
export function requireQuestionDeliverySlot(activity, slotId) {
    const slot = boundOutput(activity.step, slotId);
    if (slot.type !== "questionDelivery")
        throw new LearningError(422, "INVALID_SLOT");
    return slot;
}
export function questionDeliveryPosition(slot, logicalSlotId, questionId) {
    if (slot.delivery.mode === "whole")
        return logicalSlotId;
    const slotId = slot.delivery.questionSlots[questionId];
    if (slotId === undefined || !Object.hasOwn(slot.delivery.questionSlots, questionId)) {
        throw new Error("冻结的题缺少交付位置");
    }
    return slotId;
}
export function requireFrozenQuestion(activity, { questionId, questionVersion }) {
    const question = activity.practice.questions.find(question => question.id === questionId);
    if (!question)
        throw new LearningError(422, "INVALID_QUESTION");
    if (question.version !== questionVersion)
        throw new LearningError(409, "QUESTION_REVISION_STALE");
    return question;
}
