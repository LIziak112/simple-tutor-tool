import { isDeepStrictEqual } from "node:util";
import { LearningError } from "../contracts/learning-error.js";
import { responseDraftValue, responseValue } from "../contracts/response.js";
import { loadStudentReadingActivity } from "./activity.js";
import { recordChoiceDraftChange } from "./choice-draft-activity.js";
import { choiceRevisionBeforeAnswers } from "./choice-snapshot-store.js";
import { writeTransaction } from "./database.js";
import { isLatestQuestionDraftOperation, publicDraft, QuestionDraftConflict, readQuestionDraftHead, readQuestionDraftOperation, readQuestionDrafts, rememberQuestionDraftOperation, } from "./question-draft-store.js";
import { writableOutput } from "./reading-progress.js";
import { saveWorkVersion } from "./work-versions.js";
export class ResponseDraftConflict extends QuestionDraftConflict {
    questionId;
    constructor(current, code, questionId) {
        super(current, code);
        this.questionId = questionId;
    }
}
export function responseSlot(registry, activity, slotId) {
    const slot = writableOutput(registry, activity.step, slotId);
    if (slot.type !== "oneResponsePerQuestion")
        throw new LearningError(422, "INVALID_SLOT");
    return slot;
}
export function readResponseDrafts(database, activityId, stepAttemptId) {
    return readQuestionDrafts(database, activityId, stepAttemptId, responseDraftValue);
}
export function saveResponseDraft(database, registry, studentId, activityId, input, mode, clock) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, input.stepAttemptId);
        if (activity.completed)
            throw new LearningError(409, "ALREADY_SUBMITTED");
        const slot = responseSlot(registry, activity, input.slotId);
        const question = requireQuestionVersion(activity, input);
        const value = responseValue.parse(registry.requireResponseType(slot.input).parseValue(input.value, question));
        return saveCurrentResponse(database, activityId, { ...input, value }, mode, clock, ResponseDraftConflict);
    });
}
function requireQuestionVersion(activity, input) {
    const question = activity.practice.questions.find(question => question.id === input.questionId);
    if (!question)
        throw new LearningError(422, "INVALID_QUESTION");
    if (question.version !== input.questionVersion)
        throw new LearningError(409, "QUESTION_REVISION_STALE");
    return question;
}
export function saveCurrentResponse(database, activityId, input, mode, clock, Conflict) {
    const current = readQuestionDraftHead(database, activityId, input, responseDraftValue);
    const previous = readQuestionDraftOperation(database, activityId, input, responseDraftValue);
    if (previous && current) {
        if (isLatestQuestionDraftOperation(database, current.workId, input.operationId)
            && previous.baseRevision === input.baseRevision && isDeepStrictEqual(previous.draft.value, input.value))
            return publicDraft(current);
        throw new Conflict({ revision: current.revision, value: current.value }, "OPERATION_CONFLICT");
    }
    const state = current ?? { revision: choiceRevisionBeforeAnswers(database, input), value: null };
    if (mode === "replayLatestOnly")
        throw new LearningError(409, "DRAFT_REPLAY_REQUIRED");
    if (state.revision !== input.baseRevision)
        throw new Conflict({ revision: state.revision, value: state.value });
    const written = current && isDeepStrictEqual(current.value, input.value) ? current
        : appendResponse(database, activityId, input, current ?? { revision: state.revision }, clock);
    rememberQuestionDraftOperation(database, input, written);
    return publicDraft(written);
}
function appendResponse(database, activityId, input, current, clock) {
    const { stepAttemptId, slotId, questionId, questionVersion, value } = input;
    recordChoiceDraftChange(database, activityId, clock());
    const draft = saveWorkVersion(database, { activityId, step: { id: stepAttemptId, slotId, questionId } }, { questionVersion, value }, current.workId);
    return {
        workId: draft.id, workVersion: draft.version, slotId, questionId, questionVersion, value,
        revision: current.revision + 1, changeCount: (current.changeCount ?? 0) + 1,
    };
}
