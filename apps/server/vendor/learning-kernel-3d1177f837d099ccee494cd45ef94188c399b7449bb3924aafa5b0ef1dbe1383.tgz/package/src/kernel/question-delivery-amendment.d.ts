import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { AuthorizeChoiceDraftAmendment } from "../contracts/choice-amendment.ts";
import type { QuestionDeliveryAmendmentScope, ParsedQuestionDeliveryDraftAmendment } from "../contracts/question-delivery-amendment.ts";
import type { ReadingActivity } from "./activity.ts";
import type { Registry } from "./registry.ts";
type Scope = QuestionDeliveryAmendmentScope;
type Position = {
    stepAttemptId: string;
    slotId: string;
    questionId: string;
};
export declare function deliveryPosition(registry: Registry, activity: ReadingActivity, scope: Scope): Position;
export declare function openDraftState(database: DatabaseSync, activity: ReadingActivity, position: Position): {
    head: ({
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        value: z.JSONType;
    }) | undefined;
    revision: number;
};
export declare function readQuestionDeliveryDraftForAmendment(database: DatabaseSync, registry: Registry, reviewer: string, activityId: string, scope: Scope, authorize?: AuthorizeChoiceDraftAmendment): {
    questionVersion: number;
    value: z.JSONType;
    questionId: string;
    revision: number;
    changeCount: number;
    slotId: string;
    history: {
        amendments: {
            revision: number;
            reviewerId: string;
            reason: string;
            amendedAt: string;
        }[];
        snapshots: {
            revision: number;
            previousQuestionVersion: number;
            questionVersion: number;
            reviewerId: string;
            reason: string;
            revisedAt: string;
        }[];
    };
};
export declare function amendQuestionDeliveryDraft(database: DatabaseSync, registry: Registry, reviewer: string, activityId: string, input: ParsedQuestionDeliveryDraftAmendment, clock: () => Date, authorize?: AuthorizeChoiceDraftAmendment): {
    questionVersion: number;
    value: z.JSONType;
    questionId: string;
    revision: number;
    changeCount: number;
    slotId: string;
};
export {};
