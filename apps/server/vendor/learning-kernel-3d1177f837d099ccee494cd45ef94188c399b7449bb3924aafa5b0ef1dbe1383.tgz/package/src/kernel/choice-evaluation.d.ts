import type { DatabaseSync } from "node:sqlite";
import type { ChoiceConfirmation } from "../contracts/choice-confirmation.ts";
import type { SubmissionReceipt } from "../contracts/reading.ts";
import type { ReadingActivity } from "./activity.ts";
export declare function readChoiceEvaluation(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, confirmation: ChoiceConfirmation): {
    questionCount?: never;
    correctCount?: never;
    questions?: never;
    status: "failed" | "pending";
    evaluator: {
        id: string;
        version: number;
    };
} | {
    status: "evaluated";
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        correct: boolean;
    }[];
} | undefined;
