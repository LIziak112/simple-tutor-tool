import type { DatabaseSync } from "node:sqlite";
import type { QuestionDelivery } from "../contracts/question-delivery.ts";
import type { SubmissionReceipt, VersionRef } from "../contracts/reading.ts";
import type { ReadingActivity } from "./activity.ts";
import { readEvaluatedResponses } from "./response-evaluation.ts";
export declare function confirmedDeliveryAssessment({ practice: { grading: { assessment, manualReview, teacherReview } } }: Pick<ReadingActivity, "practice">, { questions }: QuestionDelivery): {
    automatic: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
        value: import("zod").JSONType;
    }[];
    review: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
        value: import("zod").JSONType;
    }[];
};
export declare function registerDeliveryAssessment(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, content: QuestionDelivery, targetId: string): void;
export declare function recoverQuestionDeliveryAssessment(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, content: QuestionDelivery, mode: "automatic" | "declared"): {
    assessment: "automatic";
    evaluation: {
        status: "failed" | "pending";
        evaluator: {
            id: string;
            version: number;
        };
        questionCount?: never;
        correctCount?: never;
        needsReviewCount?: never;
        questions?: never;
    } | {
        status: "evaluated";
        evaluator: {
            id: string;
            version: number;
        };
        questionCount: number;
        correctCount: number;
        needsReviewCount: number;
        questions: {
            questionId: string;
            questionVersion: number;
            result: {
                status: "judged";
                correct: boolean;
            } | {
                status: "needsReview";
            };
        }[];
    } | WithheldEvaluation;
    review?: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
} | {
    assessment: "manual";
    review: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
} | {
    assessment: "teacherReview";
    review: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
} | {
    review?: never;
    assessment: "none";
};
type Evaluation = ReturnType<typeof readEvaluatedResponses>;
type WithheldEvaluation = {
    [field in Exclude<keyof Extract<Evaluation, {
        status: "evaluated";
    }>, "status" | "evaluator">]?: never;
} & {
    status: "withheld";
    evaluator: Evaluation["evaluator"];
};
export declare function readManualReviewQuestions(database: DatabaseSync, receipt: SubmissionReceipt, questions: QuestionDelivery["questions"], mixed?: boolean): {
    questionId: string;
    questionVersion: number;
    status: "needsReview";
}[];
export declare function readManualReviewBasis(database: DatabaseSync, receipt: SubmissionReceipt, reference: VersionRef): {
    id: string;
    version: number;
    reviewCriteria: string;
};
export {};
