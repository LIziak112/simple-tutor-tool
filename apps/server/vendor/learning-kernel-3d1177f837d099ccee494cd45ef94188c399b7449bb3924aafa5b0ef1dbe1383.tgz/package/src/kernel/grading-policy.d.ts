import type { GradingPolicy, GradingPolicyField, QuestionGrading, QuestionGradingFacts } from "../contracts/grading-policy.ts";
export type ResolvedGradingPolicy = Readonly<{
    policy: GradingPolicy;
    fallbacks: readonly GradingPolicyField[];
    ignored: readonly string[];
}>;
export declare function resolveGradingPolicy(input: unknown): ResolvedGradingPolicy;
export declare function questionGrading(policy: GradingPolicy, { automatic, reference }: QuestionGradingFacts): QuestionGrading;
export declare function routeQuestions<Question extends Readonly<{
    id: string;
    facts: QuestionGradingFacts;
}>>(policy: GradingPolicy, questions: readonly Question[]): Readonly<Record<QuestionGrading, readonly string[]>>;
