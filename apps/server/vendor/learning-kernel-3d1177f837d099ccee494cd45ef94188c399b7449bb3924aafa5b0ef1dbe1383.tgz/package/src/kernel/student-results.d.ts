import type { DatabaseSync } from "node:sqlite";
import type { ReadingActivity } from "./activity.ts";
type StudentPolicy = ReadingActivity["practice"]["policy"]["student"];
type Graded = {
    questionId: string;
    correct: boolean;
};
export declare function studentResults(database: DatabaseSync, activity: ReadingActivity): DeliveryResults | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: Graded[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
};
declare function passageAssessment(score: NonNullable<StudentPolicy["passageScore"]>, graded: readonly Graded[]): {
    status: "complete";
};
type DeliveryResults = {
    assessment?: ReturnType<typeof passageAssessment> | {
        status: "pending";
    };
    review?: undefined;
};
export {};
