import type { ReadingPublication } from "../contracts/reading-publication.ts";
import type { Registry } from "./registry.ts";
type Issue = (path: (string | number)[], message: string) => void;
export declare function validateBindings(publication: ReadingPublication, issue: Issue, registry: Registry): void;
export declare function validateQuestionShape(question: ReadingPublication["practice"]["questions"][number], typeId: string | undefined, registry: Registry, issue: Issue): void;
export {};
