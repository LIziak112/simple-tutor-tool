import { readQuestionDelivery } from "../contracts/question-delivery.js";
import { confirmedDeliveryAssessment } from "./question-delivery-evaluation.js";
import { questionDeliverySlot } from "./question-delivery-publication.js";
import { reviewDisclosure } from "./review-access.js";
import { activitySubmissions } from "./submission-store.js";
import { assessmentTarget, questionVerdicts, questionVerdictStates, submissionReviewTarget } from "./verdict-state.js";
export function studentResults(database, activity) {
    const policy = activity.practice.policy.student;
    const delivery = questionDeliverySlot(activity.step);
    if (delivery)
        return deliveryResults(database, activity, policy, delivery[1].targetId);
    const target = assessmentTarget(database, activity.activityId);
    if (!target || !policy.passageScore)
        return {};
    const pending = policy.ownSubmission.onFinal.includes("passageGradingStatus") ? { status: "pending" } : undefined;
    if (target.status !== "done")
        return { assessment: pending };
    const graded = questionVerdicts(database, activity, target).flatMap(({ questionId, effective }) => effective ? [{ questionId, correct: effective.correct }] : []);
    if (graded.length !== activity.practice.questions.length)
        return { assessment: pending };
    return {
        assessment: passageAssessment(policy.passageScore, graded),
        review: policy.review && studentReview(database, activity.activityId, policy.review, graded),
    };
}
function passageAssessment(score, graded) {
    const result = { questionCount: graded.length, correctCount: graded.filter(item => item.correct).length };
    return { status: "complete", ...Object.fromEntries(score.fields.map(field => [field, result[field]])) };
}
function deliveryResults(database, activity, policy, targetId) {
    if (!activity.completed || !policy.passageScore)
        return {};
    const graded = activitySubmissions(database, activity.activityId).flatMap(({ receipt, content }) => {
        const delivered = readQuestionDelivery(content);
        const target = delivered && submissionReviewTarget(database, receipt.id, targetId);
        if (!delivered || !target)
            return [];
        const { automatic, review } = confirmedDeliveryAssessment(activity, delivered);
        return questionVerdictStates(database, target, [...automatic, ...review])
            .flatMap(({ questionId, effective }) => effective ? [{ questionId, correct: effective.correct }] : []);
    });
    if (graded.length !== activity.practice.questions.length) {
        return policy.ownSubmission.onFinal.includes("passageGradingStatus") ? { assessment: { status: "pending" } } : {};
    }
    return { assessment: passageAssessment(policy.passageScore, graded) };
}
function studentReview(database, activityId, policy, graded) {
    const disclosure = reviewDisclosure(database, activityId);
    if (!disclosure?.reviewOpen)
        return undefined;
    const byQuestion = policy.byQuestion.includes("effectiveVerdict") ? graded : undefined;
    const selectionFeedback = policy.byQuoteSet.includes("learnerFeedback") ? disclosure.feedback ?? undefined : undefined;
    if (!byQuestion && !selectionFeedback)
        return undefined;
    return { byQuestion, selectionFeedback };
}
