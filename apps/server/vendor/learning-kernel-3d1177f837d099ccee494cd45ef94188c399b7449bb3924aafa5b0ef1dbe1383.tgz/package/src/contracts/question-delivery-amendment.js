import { z } from "zod";
import { choiceDraftScope } from "./choice-draft.js";
import { choiceDraftAmendmentInput } from "./choice-amendment.js";
import { questionDeliveryDraftInput } from "./question-delivery.js";
import { readingQuestion } from "./reading-publication.js";
const reason = choiceDraftAmendmentInput.shape.reason;
const frozenIdentity = ["id", "version", "response"];
export const questionDeliveryAmendmentScope = choiceDraftScope;
export const questionDeliveryDraftAmendmentInput = questionDeliveryDraftInput.extend({ reason });
export const questionSnapshotContent = z.strictObject({
    question: readingQuestion.omit({ id: true, version: true, response: true })
        .refine(question => frozenIdentity.every(field => !Object.hasOwn(question, field)), "题号、版本与作答形态不可修改"),
    key: z.record(z.string(), z.json()).optional(),
});
export const questionDeliverySnapshotRevisionInput = choiceDraftAmendmentInput.omit({ choice: true })
    .extend(questionSnapshotContent.shape);
