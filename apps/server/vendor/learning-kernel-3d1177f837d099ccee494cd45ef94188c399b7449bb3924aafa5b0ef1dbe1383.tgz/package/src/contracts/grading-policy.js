import { z } from "zod";
export const gradingPolicy = z.strictObject({
    version: z.literal(1),
    withReference: z.enum(["selfReview", "teacherReview"]),
});
export const defaultGradingPolicy = Object.freeze({ version: 1, withReference: "selfReview" });
