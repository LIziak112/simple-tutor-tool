import { z } from "zod";
export declare const gradingPolicy: z.ZodObject<{
    version: z.ZodLiteral<1>;
    withReference: z.ZodEnum<{
        selfReview: "selfReview";
        teacherReview: "teacherReview";
    }>;
}, z.core.$strict>;
export type GradingPolicy = z.infer<typeof gradingPolicy>;
export type GradingPolicyField = keyof GradingPolicy;
export declare const defaultGradingPolicy: GradingPolicy;
export type QuestionGradingFacts = Readonly<{
    automatic: boolean;
    reference: boolean;
}>;
export type QuestionGrading = "automatic" | "selfReview" | "teacherReview";
