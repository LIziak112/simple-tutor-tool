import { z } from "zod";
export declare const questionDeliveryAmendmentScope: z.ZodObject<{
    questionVersion: z.ZodInt;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
}, z.core.$strict>;
export declare const questionDeliveryDraftAmendmentInput: z.ZodObject<{
    questionVersion: z.ZodInt;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    operationId: z.ZodString;
    baseRevision: z.ZodInt;
    value: z.ZodUnknown;
    reason: z.ZodString;
}, z.core.$strict>;
export declare const questionSnapshotContent: z.ZodObject<{
    question: z.ZodObject<{
        prompt: z.ZodString;
        options: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$loose>;
    key: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodJSONSchema>>;
}, z.core.$strict>;
export declare const questionDeliverySnapshotRevisionInput: z.ZodObject<{
    questionVersion: z.ZodInt;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    operationId: z.ZodString;
    baseRevision: z.ZodInt;
    reason: z.ZodString;
    question: z.ZodObject<{
        prompt: z.ZodString;
        options: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$loose>;
    key: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodJSONSchema>>;
}, z.core.$strict>;
export type QuestionDeliveryAmendmentScope = z.infer<typeof questionDeliveryAmendmentScope>;
export type QuestionDeliveryDraftAmendmentInput = z.input<typeof questionDeliveryDraftAmendmentInput>;
export type QuestionDeliverySnapshotRevisionInput = z.input<typeof questionDeliverySnapshotRevisionInput>;
export type ParsedQuestionDeliverySnapshotRevision = z.infer<typeof questionDeliverySnapshotRevisionInput>;
export type ParsedQuestionDeliveryDraftAmendment = z.infer<typeof questionDeliveryDraftAmendmentInput>;
