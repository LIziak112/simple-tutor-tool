import type { DatabaseSync } from "node:sqlite";
import type { BoundQuestionAnswerRules } from "../contracts/question-answer-rule.ts";
import type { PublicationEvaluators } from "./publication-bindings.ts";
export declare function registerPublication(database: DatabaseSync, input: unknown, registered?: PublicationEvaluators, answerRules?: BoundQuestionAnswerRules): void;
