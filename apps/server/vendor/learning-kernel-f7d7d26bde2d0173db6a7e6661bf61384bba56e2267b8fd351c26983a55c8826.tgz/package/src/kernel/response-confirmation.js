import { hasStoredResponse, readIndexResponseConfirmation, readResponseConfirmation } from "../contracts/response.js";
import { loadStudentReadingActivity } from "./activity.js";
import { writeTransaction } from "./database.js";
import { LearningError } from "./learning-error.js";
import { confirmedDraftChangeCount, confirmedWorkForOperation, mapConfirmationQuestions, replayQuestionConfirmation, requireConfirmationRecovery, writeQuestionConfirmation, } from "./question-confirmation.js";
import { requireBeforeDeadline } from "./reading-progress.js";
import { indexResponseDrafts, IndexResponseDraftConflict, readResponseDrafts, ResponseDraftConflict, responseSlot, scalarResponseDrafts } from "./response-drafts.js";
export class ResponseConfirmationConflict extends ResponseDraftConflict {
    questionId;
    constructor(questionId, current) {
        super(current);
        this.questionId = questionId;
    }
}
export const scalarResponses = {
    drafts: scalarResponseDrafts, read: readResponseConfirmation,
    conflict: (questionId, current) => new ResponseConfirmationConflict(questionId, current),
    content: questions => ({ kind: "responseConfirmation", questions }),
};
export const indexResponses = {
    drafts: indexResponseDrafts, read: readIndexResponseConfirmation,
    conflict: (questionId, current) => new IndexResponseDraftConflict(current, "ANSWER_REVISION_CONFLICT", questionId),
    content: questions => ({ kind: "indexResponseConfirmation", questions }),
};
export function confirmResponses(database, studentId, activityId, input, clock, mode, verifyOriginal) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, input.stepAttemptId);
        const previous = confirmedWorkForOperation(database, activityId, input);
        if (previous) {
            const intent = mode.read(previous.content)?.questions.map(({ value, ...revision }) => revision);
            return replayQuestionConfirmation(previous.receipt, intent, input);
        }
        if (activity.completed)
            throw new LearningError(409, "ALREADY_SUBMITTED");
        const slot = responseSlot(activity, input.slotId, mode.drafts.format);
        const now = clock();
        requireBeforeDeadline(activity, now);
        const questions = freezeResponses(database, activity, input, slot.confirmFromDrafts.allowUnanswered, mode);
        return writeQuestionConfirmation(database, activity, studentId, input, slot.targetId, mode.content(questions), now, verifyOriginal);
    });
}
export function recoverResponseConfirmation(database, studentId, activityId, key, authorize, mode, evaluate) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, key.stepAttemptId);
        requireConfirmationRecovery({ studentId, activityId, stepAttemptId: key.stepAttemptId, operationId: key.operationId }, authorize);
        const previous = confirmedWorkForOperation(database, activityId, key);
        const confirmation = previous && mode.read(previous.content);
        if (!previous || !confirmation)
            throw new LearningError(404, "CONFIRMATION_NOT_FOUND");
        const { receipt } = previous;
        const { id, version } = activity.practice;
        const evaluation = evaluate(activity, receipt, confirmation);
        const drafts = draftsOfResponses(database, activityId, receipt, mode.drafts);
        const responseDraftChangeCounts = confirmation.questions.map(question => ({
            questionId: question.questionId, changeCount: confirmedDraftChangeCount(question, drafts.get(question.questionId), "value"),
        }));
        return { receipt, practice: { id, version }, confirmation, responseDraftChangeCounts, evaluation };
    });
}
function freezeResponses(database, activity, input, allowUnanswered, { drafts: draftMode, conflict }) {
    const drafts = draftsOfResponses(database, activity.activityId, input, draftMode);
    return mapConfirmationQuestions(activity, input.questions, requested => {
        const current = drafts.get(requested.questionId) ?? { revision: 0, value: null };
        if (current.revision !== requested.revision) {
            throw conflict(requested.questionId, { revision: current.revision, value: current.value });
        }
        if (!hasStoredResponse(current.value) && !allowUnanswered)
            throw new LearningError(422, "UNANSWERED_QUESTION");
        return { ...requested, value: current.value };
    });
}
function draftsOfResponses(database, activityId, { stepAttemptId, slotId }, mode) {
    return new Map(readResponseDrafts(database, activityId, stepAttemptId, mode).filter(draft => draft.slotId === slotId)
        .map(draft => [draft.questionId, draft]));
}
