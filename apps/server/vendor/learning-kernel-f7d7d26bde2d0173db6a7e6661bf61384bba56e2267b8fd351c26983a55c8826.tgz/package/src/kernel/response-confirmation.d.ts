import type { DatabaseSync } from "node:sqlite";
import type { AuthorizeConfirmationRecovery, ConfirmationKey, VerifyOriginal } from "../contracts/choice-confirmation.ts";
import type { SubmissionReceipt } from "../contracts/reading.ts";
import type { IndexResponseConfirmation, ResponseConfirmation, ResponseConfirmationInput, ResponseValue, StoredResponseValue } from "../contracts/response.ts";
import type { ReadingActivity } from "./activity.ts";
import { LearningError } from "./learning-error.ts";
import { ResponseDraftConflict } from "./response-drafts.ts";
import type { ResponseDraftMode } from "./response-drafts.ts";
export declare class ResponseConfirmationConflict extends ResponseDraftConflict {
    readonly questionId: string;
    constructor(questionId: string, current: ResponseDraftConflict["current"]);
}
type ConfirmedQuestion<Value> = ResponseConfirmationInput["questions"][number] & {
    value: Value | null;
};
type ResponseWork = ResponseConfirmation | IndexResponseConfirmation;
type ResponseMode<Value, Confirmation extends ResponseWork> = {
    drafts: ResponseDraftMode<Value>;
    read: (content: unknown) => Confirmation | undefined;
    content: (questions: ConfirmedQuestion<Value>[]) => Confirmation;
    conflict: (questionId: string, current: {
        revision: number;
        value: Value | null;
    }) => LearningError;
};
export declare const scalarResponses: ResponseMode<ResponseValue, ResponseConfirmation>;
export declare const indexResponses: ResponseMode<number[], IndexResponseConfirmation>;
export declare function confirmResponses<Value extends StoredResponseValue, Confirmation extends ResponseWork>(database: DatabaseSync, studentId: string, activityId: string, input: ResponseConfirmationInput, clock: () => Date, mode: ResponseMode<Value, Confirmation>, verifyOriginal?: VerifyOriginal): {
    id: string;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export declare function recoverResponseConfirmation<Value extends StoredResponseValue, Confirmation extends ResponseWork, Result>(database: DatabaseSync, studentId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeConfirmationRecovery | undefined, mode: ResponseMode<Value, Confirmation>, evaluate: (activity: ReadingActivity, receipt: SubmissionReceipt, confirmation: Confirmation) => Result): {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: Confirmation;
    responseDraftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
    evaluation: Result;
};
export {};
