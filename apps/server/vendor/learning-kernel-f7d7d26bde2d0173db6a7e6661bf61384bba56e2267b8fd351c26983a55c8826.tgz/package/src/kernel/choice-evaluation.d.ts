import type { DatabaseSync } from "node:sqlite";
import type { ChoiceConfirmation } from "../contracts/choice-confirmation.ts";
import type { ChoiceEvaluatorRegistration } from "../contracts/choice-evaluation.ts";
import type { SubmissionReceipt } from "../contracts/reading.ts";
import type { ReadingActivity } from "./activity.ts";
export declare function recoverChoiceEvaluation(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, confirmation: ChoiceConfirmation, registered: readonly ChoiceEvaluatorRegistration[]): {
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        correct: boolean;
    }[];
} | undefined;
