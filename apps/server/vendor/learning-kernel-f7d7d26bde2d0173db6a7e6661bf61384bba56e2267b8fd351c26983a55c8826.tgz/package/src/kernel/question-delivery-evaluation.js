import { z } from "zod";
import { findChoiceEvaluator } from "../contracts/choice-evaluation.js";
import { questionDeliveryReviewBasis, questionDeliveryScoringKey } from "../contracts/question-delivery.js";
import { findResponseEvaluator } from "../contracts/response-evaluation.js";
import { indexResponseValue, orderedTextResponseValue, responseValue, titledTextResponseValue } from "../contracts/response.js";
import { loadEvaluationKey, queueEvaluation, registerTeacherReviewTarget } from "./evaluation.js";
import { LearningError } from "./learning-error.js";
import { readResponseReviewRequirements, recordResponseReviewRequirements, recoverEvaluatedResponses } from "./response-evaluation.js";
import { submissionAssessmentTarget } from "./verdict-state.js";
export function confirmedDeliveryAssessment({ practice: { grading: { assessment, manualReview, teacherReview } } }, { questions }) {
    const teacherIds = new Set(teacherReview?.questionIds);
    const review = manualReview ? questions : questions.filter(({ questionId }) => teacherIds.has(questionId));
    const automatic = assessment ? questions.filter(({ questionId }) => !teacherIds.has(questionId)) : [];
    return { automatic, review };
}
export function registerDeliveryAssessment(database, activity, receipt, content, targetId) {
    const { automatic, review } = confirmedDeliveryAssessment(activity, content);
    if (automatic.length || activity.practice.grading.manualReview) {
        queueEvaluation(database, activity, receipt, targetId, content.slotId);
    }
    else if (review.length) {
        registerTeacherReviewTarget(database, receipt.id, targetId);
    }
    if (review.length)
        recordResponseReviewRequirements(database, receipt.id, review.map(({ questionId }) => questionId));
}
export function recoverQuestionDeliveryAssessment(database, activity, receipt, content, registered, mode) {
    const { automatic, review } = confirmedDeliveryAssessment(activity, content);
    if (automatic.length) {
        const evaluation = recoverQuestionDeliveryEvaluation(database, activity, receipt, automatic, registered);
        const questions = mode === "declared" && review.length > 0
            ? readManualReviewQuestions(database, receipt, review, true)
            : undefined;
        return { assessment: "automatic", evaluation, ...questions && { review: { questions } } };
    }
    if (mode === "automatic")
        throw new LearningError(409, "ASSESSMENT_MODE_MISMATCH");
    if (review.length) {
        const questions = readManualReviewQuestions(database, receipt, review);
        if (activity.practice.grading.manualReview)
            return { assessment: "manual", review: { questions } };
        return { assessment: "teacherReview", review: { questions } };
    }
    return { assessment: "none" };
}
function recoverQuestionDeliveryEvaluation(database, activity, receipt, questions, registered) {
    const target = submissionAssessmentTarget(database, receipt.id);
    return recoverEvaluatedResponses(database, activity, receipt, questions, (reference, key, context) => {
        const { acceptedByQuestion } = questionDeliveryScoringKey.parse(key);
        return question => {
            const basis = Object.hasOwn(acceptedByQuestion, question.questionId) ? acceptedByQuestion[question.questionId] : undefined;
            if (!basis)
                throw new Error("冻结的逐题评分键缺少题目");
            const evaluate = evaluateOf(reference, basis, registered);
            return evaluate({ ...context, practice: { ...context.practice }, ...question });
        };
    }, target);
}
export function readManualReviewQuestions(database, receipt, questions, mixed = false) {
    const required = new Set(readResponseReviewRequirements(database, receipt.id));
    if ((!mixed && required.size !== questions.length) || questions.some(({ questionId }) => !required.has(questionId))) {
        throw new Error("人工待评位置与冻结提交不一致");
    }
    return questions.map(({ questionId, questionVersion }) => ({ questionId, questionVersion, status: "needsReview" }));
}
export function readManualReviewBasis(database, receipt, reference) {
    const basis = questionDeliveryReviewBasis.parse(loadEvaluationKey(database, receipt.id));
    if (basis.id !== reference.id || basis.version !== reference.version)
        throw new Error("人工待评引用与冻结依据不一致");
    return basis;
}
const confirmedChoice = z.string().nullable();
const confirmedScalar = responseValue.nullable();
const confirmedIndexes = indexResponseValue.nullable();
const confirmedOrderedText = orderedTextResponseValue.nullable();
const confirmedTitledText = titledTextResponseValue.nullable();
function evaluateOf(reference, basis, { choice = [], scalar = [], indexes = [], orderedText = [], titledText = [] }) {
    switch (basis.response) {
        case "choice": {
            const evaluate = requireEvaluator(findChoiceEvaluator(choice, reference));
            return ({ value, ...context }) => {
                const correct = evaluate({ ...context, choice: confirmedChoice.parse(value), acceptedChoice: basis.acceptedChoice });
                return { status: "judged", correct };
            };
        }
        case "booleanOrString": {
            const evaluate = requireEvaluator(findResponseEvaluator(scalar, reference));
            return ({ value, ...context }) => evaluate({ ...context, value: confirmedScalar.parse(value), acceptedResponse: basis.acceptedResponse });
        }
        case "optionIndexArray": {
            const evaluate = requireEvaluator(findResponseEvaluator(indexes, reference));
            return ({ value, ...context }) => evaluate({ ...context, value: confirmedIndexes.parse(value), acceptedIndexes: [...basis.acceptedIndexes] });
        }
        case "orderedTextBlanks": {
            const evaluate = requireEvaluator(findResponseEvaluator(orderedText, reference));
            return ({ value, ...context }) => evaluate({
                ...context, value: confirmedOrderedText.parse(value),
                acceptedBlanks: basis.acceptedBlanks.map(values => [...values]),
            });
        }
        case "textWithOptionalTitle": {
            const evaluate = requireEvaluator(findResponseEvaluator(titledText, reference));
            return ({ value, ...context }) => evaluate({ ...context, value: confirmedTitledText.parse(value) });
        }
    }
}
function requireEvaluator(evaluate) {
    if (!evaluate)
        throw new LearningError(503, "EVALUATOR_UNAVAILABLE");
    return evaluate;
}
