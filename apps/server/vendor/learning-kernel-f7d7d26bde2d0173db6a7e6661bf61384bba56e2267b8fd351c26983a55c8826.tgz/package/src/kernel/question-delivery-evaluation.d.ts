import type { DatabaseSync } from "node:sqlite";
import type { QuestionDelivery } from "../contracts/question-delivery.ts";
import type { SubmissionReceipt, VersionRef } from "../contracts/reading.ts";
import type { ReadingActivity } from "./activity.ts";
import type { PublicationEvaluators } from "./publication-bindings.ts";
export declare function confirmedDeliveryAssessment({ practice: { grading: { assessment, manualReview, teacherReview } } }: ReadingActivity, { questions }: QuestionDelivery): {
    automatic: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
        value: string | boolean | string[] | number[] | {
            body: string;
            title?: string;
        } | null;
    }[];
    review: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
        value: string | boolean | string[] | number[] | {
            body: string;
            title?: string;
        } | null;
    }[];
};
export declare function registerDeliveryAssessment(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, content: QuestionDelivery, targetId: string): void;
export declare function recoverQuestionDeliveryAssessment(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, content: QuestionDelivery, registered: PublicationEvaluators, mode: "automatic" | "declared"): {
    assessment: "automatic";
    evaluation: {
        evaluator: {
            id: string;
            version: number;
        };
        questionCount: number;
        correctCount: number;
        needsReviewCount: number;
        questions: {
            questionId: string;
            questionVersion: number;
            result: {
                status: "judged";
                correct: boolean;
            } | {
                status: "needsReview";
            };
        }[];
    };
    review?: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
} | {
    assessment: "manual";
    review: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
} | {
    assessment: "teacherReview";
    review: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
} | {
    review?: never;
    assessment: "none";
};
export declare function readManualReviewQuestions(database: DatabaseSync, receipt: SubmissionReceipt, questions: QuestionDelivery["questions"], mixed?: boolean): {
    questionId: string;
    questionVersion: number;
    status: "needsReview";
}[];
export declare function readManualReviewBasis(database: DatabaseSync, receipt: SubmissionReceipt, reference: VersionRef): {
    id: string;
    version: number;
    reviewCriteria: string;
};
