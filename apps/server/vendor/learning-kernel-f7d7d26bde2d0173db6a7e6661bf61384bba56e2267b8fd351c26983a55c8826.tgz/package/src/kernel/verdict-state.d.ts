import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { ReadingActivity } from "./activity.ts";
import type { TeacherVerdictMode } from "./verdict-history.ts";
declare const assessment: z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    status: z.ZodEnum<{
        done: "done";
        pending: "pending";
    }>;
}, z.core.$strict>;
export declare function assessmentTarget(database: DatabaseSync, activityId: string): {
    submissionId: string;
    targetId: string;
    status: "done" | "pending";
} | undefined;
export declare function submissionAssessmentTarget(database: DatabaseSync, submissionId: string): {
    submissionId: string;
    targetId: string;
    status: "done" | "pending";
} | undefined;
export declare function readAutomaticVerdicts(database: DatabaseSync, { submissionId, targetId }: {
    submissionId: string;
    targetId: string;
}): {
    questionId: string;
    correct: boolean;
    valid: boolean;
}[];
export declare function questionVerdicts(database: DatabaseSync, activity: ReadingActivity, target: z.infer<typeof assessment>): ({
    questionId: string;
    prompt: string;
} & {
    submissionId: string;
    targetId: string;
    revision: number;
    effective: {
        source: "teacherReview";
        id: string;
        correct: boolean;
    } | {
        source: "automatic";
        correct: boolean;
    } | undefined;
    automatic: {
        correct: boolean;
        valid: boolean;
    } | undefined;
    history: {
        submissionId: string;
        targetId: string;
        questionId: string;
        id: string;
        revision: number;
        reviewerId: string;
        reason: string;
        reviewedAt: string;
        action: "override" | "withdraw";
        correct: 0 | 1 | null;
        withdrawId: string | null;
    }[];
})[];
export declare function questionVerdictStates<Question extends {
    questionId: string;
}>(database: DatabaseSync, target: z.infer<typeof assessment>, questions: readonly Question[], mode: TeacherVerdictMode): (Question & {
    submissionId: string;
    targetId: string;
    revision: number;
    effective: {
        source: "teacherReview";
        id: string;
        correct: boolean;
    } | {
        source: "automatic";
        correct: boolean;
    } | undefined;
    automatic: {
        correct: boolean;
        valid: boolean;
    } | undefined;
    history: {
        submissionId: string;
        targetId: string;
        questionId: string;
        id: string;
        revision: number;
        reviewerId: string;
        reason: string;
        reviewedAt: string;
        action: "override" | "withdraw";
        correct: 0 | 1 | null;
        withdrawId: string | null;
    }[];
})[];
export {};
