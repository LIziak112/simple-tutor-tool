import type { ChoiceEvaluatorRegistration } from "../contracts/choice-evaluation.ts";
import type { BoundQuestionAnswerRules } from "../contracts/question-answer-rule.ts";
import type { IndexResponseEvaluatorRegistration, OrderedTextEvaluatorRegistration, ResponseEvaluatorRegistration, TitledTextEvaluatorRegistration } from "../contracts/response-evaluation.ts";
import type { ReadingPublication } from "../contracts/reading-publication.ts";
type Issue = (path: (string | number)[], message: string) => void;
export type PublicationEvaluators = {
    choice?: readonly ChoiceEvaluatorRegistration[];
    scalar?: readonly ResponseEvaluatorRegistration[];
    indexes?: readonly IndexResponseEvaluatorRegistration[];
    orderedText?: readonly OrderedTextEvaluatorRegistration[];
    titledText?: readonly TitledTextEvaluatorRegistration[];
};
export declare function validateBindings(publication: ReadingPublication, issue: Issue, registered: PublicationEvaluators, answerRules: BoundQuestionAnswerRules): void;
export {};
