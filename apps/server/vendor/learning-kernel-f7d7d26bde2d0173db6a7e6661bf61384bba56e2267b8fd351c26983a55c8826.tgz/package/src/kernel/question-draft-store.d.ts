import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { ChoiceDraftInput, ChoiceDraftScope } from "../contracts/choice-draft.ts";
import type { StoredResponseValue } from "../contracts/response.ts";
import { LearningError } from "./learning-error.ts";
type DraftValue = Pick<ChoiceDraftInput, "questionVersion" | "choice"> | {
    questionVersion: number;
    value: StoredResponseValue;
};
export declare class QuestionDraftConflict<Current extends {
    revision: number;
}> extends LearningError {
    readonly current: Readonly<Current>;
    constructor(current: Readonly<Current>, code?: "ANSWER_REVISION_CONFLICT" | "OPERATION_CONFLICT");
}
export declare function publicDraft<T extends {
    workId: string;
    workVersion: number;
}>({ workId, workVersion, ...draft }: T): Omit<T, "workId" | "workVersion">;
export declare function readQuestionDrafts<T extends DraftValue>(database: DatabaseSync, activityId: string, stepAttemptId: string, schema: z.ZodType<T>): Omit<{
    workId: string;
    slotId: string;
    questionId: string;
    workVersion: number;
    revision: number;
    changeCount: number;
} & T, "workId" | "workVersion">[];
export declare function readQuestionDraftHead<T extends DraftValue>(database: DatabaseSync, activityId: string, { stepAttemptId, slotId, questionId }: Pick<ChoiceDraftScope, "stepAttemptId" | "slotId" | "questionId">, schema: z.ZodType<T>): ({
    workId: string;
    slotId: string;
    questionId: string;
    workVersion: number;
    revision: number;
    changeCount: number;
} & T) | undefined;
export declare function readQuestionDraftRevision<T extends DraftValue>(database: DatabaseSync, workId: string, revision: number, schema: z.ZodType<T>): {
    workId: string;
    slotId: string;
    questionId: string;
    workVersion: number;
    revision: number;
    changeCount: number;
} & T;
type VersionedDraftScope = ChoiceDraftScope & Pick<ChoiceDraftInput, "operationId" | "baseRevision">;
export declare function readQuestionDraftOperation<T extends DraftValue>(database: DatabaseSync, activityId: string, scope: VersionedDraftScope, schema: z.ZodType<T>): {
    baseRevision: number;
    draft: {
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & T;
} | undefined;
export declare function isLatestQuestionDraftOperation(database: DatabaseSync, workId: string, operationId: string): boolean;
export declare function rememberQuestionDraftOperation(database: DatabaseSync, input: VersionedDraftScope, { workId, workVersion }: {
    workId: string;
    workVersion: number;
}): void;
export {};
