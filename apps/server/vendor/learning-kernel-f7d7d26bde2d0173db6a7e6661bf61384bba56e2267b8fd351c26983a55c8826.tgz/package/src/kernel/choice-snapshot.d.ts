import type { DatabaseSync } from "node:sqlite";
import type { AuthorizeChoiceSnapshotRevision, ChoiceSnapshotRevisionInput, HasChoiceSnapshotEvidence } from "../contracts/choice-snapshot.ts";
import { LearningError } from "./learning-error.ts";
export declare class ChoiceSnapshotRevisionConflict extends LearningError {
    readonly current: Readonly<{
        revision: number;
    }>;
    constructor(revision: number);
}
type SnapshotPolicy = {
    authorize: AuthorizeChoiceSnapshotRevision | undefined;
    hasEvidence: HasChoiceSnapshotEvidence | undefined;
};
export declare function reviseChoiceSnapshot(database: DatabaseSync, reviewer: string, activityId: string, input: ChoiceSnapshotRevisionInput, clock: () => Date, policy: SnapshotPolicy): {
    slotId: string;
    questionId: string;
    questionVersion: number;
    revision: number;
    previousQuestionVersion: number;
};
export {};
