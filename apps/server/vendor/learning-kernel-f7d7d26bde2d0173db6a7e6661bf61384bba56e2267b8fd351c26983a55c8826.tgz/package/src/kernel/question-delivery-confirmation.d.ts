import type { DatabaseSync } from "node:sqlite";
import type { AuthorizeConfirmationRecovery, ConfirmationKey, VerifyOriginal } from "../contracts/choice-confirmation.ts";
import type { BoundQuestionAnswerRules } from "../contracts/question-answer-rule.ts";
import type { QuestionDeliveryInput } from "../contracts/question-delivery.ts";
import type { PublicationEvaluators } from "./publication-bindings.ts";
export declare function confirmQuestionDelivery(database: DatabaseSync, studentId: string, activityId: string, input: QuestionDeliveryInput, clock: () => Date, verifyOriginal: VerifyOriginal | undefined, authorize: AuthorizeConfirmationRecovery | undefined, answerRules: BoundQuestionAnswerRules): {
    id: string;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export declare function recoverQuestionDelivery(database: DatabaseSync, studentId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeConfirmationRecovery | undefined, registered: PublicationEvaluators, mode: "automatic" | "declared"): {
    assessment: "automatic";
    evaluation: {
        evaluator: {
            id: string;
            version: number;
        };
        questionCount: number;
        correctCount: number;
        needsReviewCount: number;
        questions: {
            questionId: string;
            questionVersion: number;
            result: {
                status: "judged";
                correct: boolean;
            } | {
                status: "needsReview";
            };
        }[];
    };
    review?: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: string | boolean | string[] | number[] | {
                body: string;
                title?: string;
            } | null;
        }[];
    };
    requestQuestions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
    }[];
    draftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
} | {
    assessment: "manual";
    review: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: string | boolean | string[] | number[] | {
                body: string;
                title?: string;
            } | null;
        }[];
    };
    requestQuestions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
    }[];
    draftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
} | {
    assessment: "teacherReview";
    review: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: string | boolean | string[] | number[] | {
                body: string;
                title?: string;
            } | null;
        }[];
    };
    requestQuestions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
    }[];
    draftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
} | {
    review?: never;
    assessment: "none";
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: string | boolean | string[] | number[] | {
                body: string;
                title?: string;
            } | null;
        }[];
    };
    requestQuestions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
    }[];
    draftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
};
