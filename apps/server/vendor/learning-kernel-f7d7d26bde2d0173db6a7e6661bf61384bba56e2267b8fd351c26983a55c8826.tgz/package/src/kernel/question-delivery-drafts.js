import { questionDeliveryDraftValue } from "../contracts/question-delivery.js";
import { loadStudentReadingActivity } from "./activity.js";
import { writeTransaction } from "./database.js";
import { LearningError } from "./learning-error.js";
import { QuestionDraftConflict, readQuestionDraftHead, readQuestionDrafts } from "./question-draft-store.js";
import { boundOutput } from "./reading-progress.js";
import { saveCurrentResponse } from "./response-drafts.js";
import { submittedSlots } from "./submission-store.js";
export class QuestionDeliveryConflict extends QuestionDraftConflict {
    questionId;
    constructor(current, code, questionId) {
        super(current, code);
        this.questionId = questionId;
    }
}
export function saveQuestionDeliveryDraft(database, studentId, activityId, input, mode, clock) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, input.stepAttemptId);
        if (activity.completed)
            throw new LearningError(409, "ALREADY_SUBMITTED");
        const slot = requireQuestionDeliverySlot(activity, input.slotId);
        const value = input.value;
        const question = requireFrozenQuestion(activity, input);
        requireDeliveryDraftValue(question, value);
        const slotId = questionDeliveryPosition(slot, input.slotId, input.questionId);
        if (submittedSlots(database, activity.stepAttemptId).has(slotId))
            throw new LearningError(409, "ALREADY_SUBMITTED");
        const draft = saveCurrentResponse(database, activityId, { ...input, slotId }, mode, clock, { schema: questionDeliveryDraftValue, Conflict: QuestionDeliveryConflict });
        return { ...draft, slotId: input.slotId };
    });
}
export function readOpenDeliveryDrafts(database, activity, logicalSlotId, submitted) {
    return readQuestionDrafts(database, activity.activityId, activity.stepAttemptId, questionDeliveryDraftValue)
        .filter(draft => !submitted.has(draft.slotId)).map(draft => ({ ...draft, slotId: logicalSlotId }));
}
export function deliveryDraftHead(database, activity, slotId, questionId) {
    return readQuestionDraftHead(database, activity.activityId, { stepAttemptId: activity.stepAttemptId, slotId, questionId }, questionDeliveryDraftValue);
}
export function requireQuestionDeliverySlot(activity, slotId) {
    const slot = boundOutput(activity.step, slotId);
    if (slot.type !== "questionDelivery")
        throw new LearningError(422, "INVALID_SLOT");
    return slot;
}
export function questionDeliveryPosition(slot, logicalSlotId, questionId) {
    if (slot.delivery.mode === "whole")
        return logicalSlotId;
    const slotId = slot.delivery.questionSlots[questionId];
    if (slotId === undefined || !Object.hasOwn(slot.delivery.questionSlots, questionId)) {
        throw new Error("冻结的题缺少交付位置");
    }
    return slotId;
}
export function requireFrozenQuestion(activity, { questionId, questionVersion }) {
    const question = activity.practice.questions.find(question => question.id === questionId);
    if (!question)
        throw new LearningError(422, "INVALID_QUESTION");
    if (question.version !== questionVersion)
        throw new LearningError(409, "QUESTION_REVISION_STALE");
    return question;
}
function requireDeliveryDraftValue(question, value) {
    const { response, options } = question;
    if (response === "booleanOrString") {
        if (typeof value === "object")
            throw new LearningError(422, "INVALID_RESPONSE");
        return;
    }
    if (response === "textWithOptionalTitle") {
        if (typeof value !== "object" || Array.isArray(value))
            throw new LearningError(422, "INVALID_RESPONSE");
        return;
    }
    if (response === "orderedTextBlanks") {
        if (!Array.isArray(value) || value.some(item => typeof item !== "string")) {
            throw new LearningError(422, "INVALID_RESPONSE");
        }
        return;
    }
    requireFrozenOptions(response, options, value);
}
function requireFrozenOptions(format, options, value) {
    if (format === "choice") {
        if (typeof value !== "string" || !Object.hasOwn(options, value))
            throw new LearningError(422, "INVALID_CHOICE");
        return;
    }
    if (format !== "optionIndexArray")
        throw new Error("冻结的题缺少作答形态");
    if (!Array.isArray(value) || value.some(index => typeof index !== "number" || !Object.hasOwn(options, String(index)))) {
        throw new LearningError(422, "INVALID_OPTION_INDEX");
    }
}
