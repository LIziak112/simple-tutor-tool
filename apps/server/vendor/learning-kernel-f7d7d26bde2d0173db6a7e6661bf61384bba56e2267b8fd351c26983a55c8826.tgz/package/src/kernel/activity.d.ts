import type { DatabaseSync } from "node:sqlite";
import type { StartInput } from "../contracts/reading.ts";
export type ReadingActivity = Extract<ReturnType<typeof loadActivity>, {
    kind: "reading";
}>;
type OpeningInput = StartInput & {
    practiceVersion?: number;
};
type OpeningMode = "start" | "prepare";
export declare function startActivity(database: DatabaseSync, student: string, input: OpeningInput, clock: () => Date, assignedReviewer?: string, openingMode?: OpeningMode): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
};
export declare function redoActivity(database: DatabaseSync, student: string, sourceId: string, operationId: string, clock: () => Date): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
};
export declare function loadStudentActivity(database: DatabaseSync, student: string, activityId: string): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    completed: boolean;
    kind: "reading";
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    practice: {
        id: string;
        version: number;
        formatVersion: 1;
        title: string;
        material?: {
            id: string;
            version: number;
        } | undefined;
        goals: Record<string, string>;
        questionAnswerRules?: {
            [k: string]: {
                id: string;
                version: number;
            };
        } | undefined;
        steps: [{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: "booleanOrString" | "optionIndexArray";
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }, ...{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: "booleanOrString" | "optionIndexArray";
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }[]];
        grading: {
            selectionFeedback?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                criterion: string;
            } | undefined;
            assessment?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                evaluator: {
                    id: string;
                    version: number;
                };
                keyRef: {
                    id: string;
                    version: number;
                };
                unit: "question";
                effectiveVerdictOrder: ["teacherReview", "automatic"];
            } | undefined;
            manualReview?: {
                keyRef: {
                    id: string;
                    version: number;
                };
            } | undefined;
            teacherReview?: {
                questionIds: string[];
            } | undefined;
        };
        policy: {
            timeLimit?: {
                minutes: number;
                startsAt: "instanceStarted";
                onDeadline: "keepDraftAndClose";
            } | undefined;
            offline: "onlineOnly";
            redo: "newInstanceOnAuthorization";
            student: {
                ownSubmission: {
                    scope: "ownConfirmedSubmissions";
                    fields: ("ownChoices" | "ownResponses" | "receipt" | "submittedQuotes")[];
                    onFinal: "passageGradingStatus"[];
                };
                passageScore?: {
                    whenAll: ["finalConfirmed", "allQuestionsJudged"];
                    group: "wholePassage";
                    fields: ("correctCount" | "questionCount")[];
                    allowSubsets: false;
                    drilldown: false;
                } | undefined;
                review?: {
                    requires: "passageScore";
                    while: "reviewOpen";
                    byQuestion: "effectiveVerdict"[];
                    byQuoteSet: "learnerFeedback"[];
                } | undefined;
            };
            reviewer: {
                scope: "assignedReviewer";
                fields: ("gradingBasis" | "learnerFeedback" | "studentChoices" | "submittedQuotes" | "verdictHistory")[];
                actions: ("commentOnQuotes" | "reviseQuestionVerdict")[];
            };
            manager: {
                scope: "assigningTeacher";
                actions: ("authorizeRedo" | "closeReview" | "openReview")[];
            };
            externalAi: "disabled";
        };
        questions: ({
            id: string;
            version?: number | undefined;
            prompt: string;
            options: Record<string, string>;
            response?: "booleanOrString" | "choice" | "optionIndexArray" | undefined;
        } | {
            id: string;
            version?: number | undefined;
            prompt: string;
            response: "orderedTextBlanks";
            blankCount: number;
            options: Record<string, never>;
        } | {
            id: string;
            version?: number | undefined;
            prompt: string;
            response: "textWithOptionalTitle";
            options: Record<string, never>;
        })[];
    };
    step: {
        id: string;
        requires?: string | undefined;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        inputs: Record<string, {
            from: "material";
            positionId: string;
            material?: {
                id: string;
                version: number;
            } | undefined;
        } | {
            from: "questions";
        } | {
            stepId: string;
            slotId: string;
            from: "submission";
            readOnly: true;
        }>;
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
        afterConfirmation: "advance" | "finish";
    };
    choiceSnapshotRevisions: {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
    }[];
    redoOf: string | undefined;
    practiceVersion: number | undefined;
} | {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    completed: boolean;
    kind: "single";
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    };
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: "text-selection";
            version: 1;
        };
        positionId: string;
        slotId: string;
        targetId: string;
    };
};
export declare function loadStudentReadingActivity(database: DatabaseSync, student: string, activityId: string, stepAttemptId: string): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    completed: boolean;
    kind: "reading";
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    practice: {
        id: string;
        version: number;
        formatVersion: 1;
        title: string;
        material?: {
            id: string;
            version: number;
        } | undefined;
        goals: Record<string, string>;
        questionAnswerRules?: {
            [k: string]: {
                id: string;
                version: number;
            };
        } | undefined;
        steps: [{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: "booleanOrString" | "optionIndexArray";
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }, ...{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: "booleanOrString" | "optionIndexArray";
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }[]];
        grading: {
            selectionFeedback?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                criterion: string;
            } | undefined;
            assessment?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                evaluator: {
                    id: string;
                    version: number;
                };
                keyRef: {
                    id: string;
                    version: number;
                };
                unit: "question";
                effectiveVerdictOrder: ["teacherReview", "automatic"];
            } | undefined;
            manualReview?: {
                keyRef: {
                    id: string;
                    version: number;
                };
            } | undefined;
            teacherReview?: {
                questionIds: string[];
            } | undefined;
        };
        policy: {
            timeLimit?: {
                minutes: number;
                startsAt: "instanceStarted";
                onDeadline: "keepDraftAndClose";
            } | undefined;
            offline: "onlineOnly";
            redo: "newInstanceOnAuthorization";
            student: {
                ownSubmission: {
                    scope: "ownConfirmedSubmissions";
                    fields: ("ownChoices" | "ownResponses" | "receipt" | "submittedQuotes")[];
                    onFinal: "passageGradingStatus"[];
                };
                passageScore?: {
                    whenAll: ["finalConfirmed", "allQuestionsJudged"];
                    group: "wholePassage";
                    fields: ("correctCount" | "questionCount")[];
                    allowSubsets: false;
                    drilldown: false;
                } | undefined;
                review?: {
                    requires: "passageScore";
                    while: "reviewOpen";
                    byQuestion: "effectiveVerdict"[];
                    byQuoteSet: "learnerFeedback"[];
                } | undefined;
            };
            reviewer: {
                scope: "assignedReviewer";
                fields: ("gradingBasis" | "learnerFeedback" | "studentChoices" | "submittedQuotes" | "verdictHistory")[];
                actions: ("commentOnQuotes" | "reviseQuestionVerdict")[];
            };
            manager: {
                scope: "assigningTeacher";
                actions: ("authorizeRedo" | "closeReview" | "openReview")[];
            };
            externalAi: "disabled";
        };
        questions: ({
            id: string;
            version?: number | undefined;
            prompt: string;
            options: Record<string, string>;
            response?: "booleanOrString" | "choice" | "optionIndexArray" | undefined;
        } | {
            id: string;
            version?: number | undefined;
            prompt: string;
            response: "orderedTextBlanks";
            blankCount: number;
            options: Record<string, never>;
        } | {
            id: string;
            version?: number | undefined;
            prompt: string;
            response: "textWithOptionalTitle";
            options: Record<string, never>;
        })[];
    };
    step: {
        id: string;
        requires?: string | undefined;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        inputs: Record<string, {
            from: "material";
            positionId: string;
            material?: {
                id: string;
                version: number;
            } | undefined;
        } | {
            from: "questions";
        } | {
            stepId: string;
            slotId: string;
            from: "submission";
            readOnly: true;
        }>;
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
        afterConfirmation: "advance" | "finish";
    };
    choiceSnapshotRevisions: {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
    }[];
    redoOf: string | undefined;
    practiceVersion: number | undefined;
};
export declare function loadActivity(database: DatabaseSync, student: string, activityId: string): {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    completed: boolean;
    kind: "reading";
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    practice: {
        id: string;
        version: number;
        formatVersion: 1;
        title: string;
        material?: {
            id: string;
            version: number;
        } | undefined;
        goals: Record<string, string>;
        questionAnswerRules?: {
            [k: string]: {
                id: string;
                version: number;
            };
        } | undefined;
        steps: [{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: "booleanOrString" | "optionIndexArray";
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }, ...{
            id: string;
            requires?: string | undefined;
            instructions: string;
            tool: {
                id: string;
                version: number;
            };
            inputs: Record<string, {
                from: "material";
                positionId: string;
                material?: {
                    id: string;
                    version: number;
                } | undefined;
            } | {
                from: "questions";
            } | {
                stepId: string;
                slotId: string;
                from: "submission";
                readOnly: true;
            }>;
            submit: {
                purpose: "finalAnswer" | "stepEvidence";
                slots: Record<string, {
                    type: "reuse";
                    source: string;
                } | {
                    source: string;
                    targetId: string;
                    type: "passageSelection";
                    oneRangePerRole: Record<string, string>;
                    distinctParagraphs: boolean;
                    evidenceUnit: "wholeSelection";
                } | {
                    source: string;
                    targetId: string;
                    type: "oneChoicePerQuestion";
                    reasonTargetId?: string | undefined;
                    confirmFromDrafts?: {
                        allowUnanswered: boolean;
                    } | undefined;
                } | {
                    source: string;
                    targetId: string;
                    type: "oneResponsePerQuestion";
                    input: "booleanOrString" | "optionIndexArray";
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                } | {
                    source: string;
                    targetId: string;
                    type: "questionDelivery";
                    delivery: {
                        mode: "whole";
                    } | {
                        mode: "perQuestion";
                        questionSlots: {
                            [k: string]: string;
                        };
                    };
                    confirmFromDrafts: {
                        allowUnanswered: boolean;
                    };
                }>;
            };
            afterConfirmation: "advance" | "finish";
        }[]];
        grading: {
            selectionFeedback?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                criterion: string;
            } | undefined;
            assessment?: {
                from: {
                    stepId: string;
                    slotId: string;
                };
                evaluator: {
                    id: string;
                    version: number;
                };
                keyRef: {
                    id: string;
                    version: number;
                };
                unit: "question";
                effectiveVerdictOrder: ["teacherReview", "automatic"];
            } | undefined;
            manualReview?: {
                keyRef: {
                    id: string;
                    version: number;
                };
            } | undefined;
            teacherReview?: {
                questionIds: string[];
            } | undefined;
        };
        policy: {
            timeLimit?: {
                minutes: number;
                startsAt: "instanceStarted";
                onDeadline: "keepDraftAndClose";
            } | undefined;
            offline: "onlineOnly";
            redo: "newInstanceOnAuthorization";
            student: {
                ownSubmission: {
                    scope: "ownConfirmedSubmissions";
                    fields: ("ownChoices" | "ownResponses" | "receipt" | "submittedQuotes")[];
                    onFinal: "passageGradingStatus"[];
                };
                passageScore?: {
                    whenAll: ["finalConfirmed", "allQuestionsJudged"];
                    group: "wholePassage";
                    fields: ("correctCount" | "questionCount")[];
                    allowSubsets: false;
                    drilldown: false;
                } | undefined;
                review?: {
                    requires: "passageScore";
                    while: "reviewOpen";
                    byQuestion: "effectiveVerdict"[];
                    byQuoteSet: "learnerFeedback"[];
                } | undefined;
            };
            reviewer: {
                scope: "assignedReviewer";
                fields: ("gradingBasis" | "learnerFeedback" | "studentChoices" | "submittedQuotes" | "verdictHistory")[];
                actions: ("commentOnQuotes" | "reviseQuestionVerdict")[];
            };
            manager: {
                scope: "assigningTeacher";
                actions: ("authorizeRedo" | "closeReview" | "openReview")[];
            };
            externalAi: "disabled";
        };
        questions: ({
            id: string;
            version?: number | undefined;
            prompt: string;
            options: Record<string, string>;
            response?: "booleanOrString" | "choice" | "optionIndexArray" | undefined;
        } | {
            id: string;
            version?: number | undefined;
            prompt: string;
            response: "orderedTextBlanks";
            blankCount: number;
            options: Record<string, never>;
        } | {
            id: string;
            version?: number | undefined;
            prompt: string;
            response: "textWithOptionalTitle";
            options: Record<string, never>;
        })[];
    };
    step: {
        id: string;
        requires?: string | undefined;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        inputs: Record<string, {
            from: "material";
            positionId: string;
            material?: {
                id: string;
                version: number;
            } | undefined;
        } | {
            from: "questions";
        } | {
            stepId: string;
            slotId: string;
            from: "submission";
            readOnly: true;
        }>;
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
        afterConfirmation: "advance" | "finish";
    };
    choiceSnapshotRevisions: {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
    }[];
    redoOf: string | undefined;
    practiceVersion: number | undefined;
} | {
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    completed: boolean;
    kind: "single";
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    };
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: "text-selection";
            version: 1;
        };
        positionId: string;
        slotId: string;
        targetId: string;
    };
};
export {};
