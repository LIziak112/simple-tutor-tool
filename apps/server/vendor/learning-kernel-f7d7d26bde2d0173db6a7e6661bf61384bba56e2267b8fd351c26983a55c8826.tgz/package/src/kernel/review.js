import { z } from "zod";
import { writeTransaction } from "./database.js";
import { LearningError } from "./learning-error.js";
import { findSource } from "./reading-answers.js";
import { readingSubmissionView } from "./reading-progress.js";
import { assignedReading } from "./review-access.js";
import { activitySubmissions } from "./submission-store.js";
import { appendReview, eventView, repeatedReview } from "./verdict-history.js";
import { assessmentTarget, questionVerdicts } from "./verdict-state.js";
export const selectionFeedbackInput = z.strictObject({
    protocolVersion: z.literal(1),
    text: z.string().trim().min(1).max(5000),
});
export function readReview(database, reviewer, activityId) {
    const { activity, feedback } = assignedReading(database, reviewer, activityId, "reviewer");
    const fields = new Set(activity.practice.policy.reviewer.fields);
    const submissions = activitySubmissions(database, activityId).map(readingSubmissionView).filter(submission => submission.selection ? fields.has("submittedQuotes") : fields.has("studentChoices"));
    return {
        activityId, submissions,
        ...reviewGrading(database, activity, fields, submissions),
        selectionFeedback: fields.has("learnerFeedback") ? feedback : undefined,
    };
}
function reviewGrading(database, activity, fields, submissions) {
    const showBasis = fields.has("gradingBasis");
    const showHistory = fields.has("verdictHistory");
    if (!showBasis && !showHistory)
        return {};
    const target = assessmentTarget(database, activity.activityId);
    if (!target)
        return {};
    const states = questionVerdicts(database, activity, target);
    if (!states.some(state => state.automatic || state.history.length))
        return {};
    const choices = submissions.find(item => item.receipt.id === target.submissionId)?.answer?.choices;
    const verdicts = projectVerdicts(states, { showBasis, showHistory, choices });
    return { verdicts, automaticVerdicts: automaticVerdictList(verdicts) };
}
function automaticVerdictList(verdicts) {
    const automaticVerdicts = verdicts.flatMap(({ submissionId, targetId, questionId, automatic }) => automatic ? [{ submissionId, targetId, questionId, correct: automatic.correct }] : []);
    return automaticVerdicts.length ? automaticVerdicts : undefined;
}
function projectVerdicts(states, { showBasis, showHistory, choices }) {
    return states.map(({ history, revision, effective, automatic, prompt, ...location }) => ({
        ...location, revision, choice: choices?.[location.questionId],
        prompt: choices ? prompt : undefined,
        effective: showBasis ? effective : undefined,
        automatic: showBasis ? automatic : undefined,
        history: showHistory ? history.map(eventView) : undefined,
    }));
}
export function writeVerdict(database, reviewer, activityId, command, clock) {
    return writeTransaction(database, () => {
        const { activity } = assignedReading(database, reviewer, activityId, "reviewer");
        if (!activity.practice.policy.reviewer.actions.includes("reviseQuestionVerdict")) {
            throw new LearningError(403, "FORBIDDEN");
        }
        const past = repeatedReview(database, activityId, reviewer, command);
        if (past)
            return past;
        requireVerdictTarget(database, activity, command);
        return appendReview(database, activityId, reviewer, command, clock);
    });
}
function requireVerdictTarget(database, activity, command) {
    const target = assessmentTarget(database, activity.activityId);
    if (target?.submissionId !== command.submissionId || target.targetId !== command.targetId
        || !activity.practice.questions.some(question => question.id === command.questionId)) {
        throw new LearningError(403, "FORBIDDEN");
    }
}
export function writeSelectionFeedback(database, reviewer, activityId, text) {
    return writeTransaction(database, () => {
        const { activity } = assignedReading(database, reviewer, activityId, "reviewer");
        if (!activity.practice.policy.reviewer.actions.includes("commentOnQuotes"))
            throw new LearningError(403, "FORBIDDEN");
        const binding = activity.practice.grading.selectionFeedback;
        if (!binding || !findSource(activitySubmissions(database, activityId), binding.from)) {
            throw new LearningError(409, "FEEDBACK_NOT_AVAILABLE");
        }
        database.prepare("UPDATE reading_reviews SET selection_feedback = ? WHERE activity_id = ? AND reviewer_id = ?")
            .run(text, activityId, reviewer);
        return { selectionFeedback: text };
    });
}
