import { z } from "zod";
import type { ChoiceEvaluationInput } from "./choice-evaluation.ts";
import type { VersionRef } from "./reading.ts";
import type { ResponseValue, TitledTextResponseValue } from "./response.ts";
export declare const responseVerdict: z.ZodDiscriminatedUnion<[z.ZodObject<{
    status: z.ZodLiteral<"judged">;
    correct: z.ZodBoolean;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodLiteral<"needsReview">;
}, z.core.$strict>], "status">;
export type ResponseVerdict = z.infer<typeof responseVerdict>;
export type ResponseEvaluationInput = Readonly<Omit<ChoiceEvaluationInput, "choice" | "acceptedChoice"> & {
    value: ResponseValue | null;
    acceptedResponse: boolean;
}>;
export type ResponseEvaluator = (input: ResponseEvaluationInput) => ResponseVerdict;
export type IndexResponseEvaluationInput = Readonly<Omit<ResponseEvaluationInput, "value" | "acceptedResponse"> & {
    value: readonly number[] | null;
    acceptedIndexes: readonly number[];
}>;
export type IndexResponseEvaluator = (input: IndexResponseEvaluationInput) => ResponseVerdict;
export type OrderedTextEvaluationInput = Readonly<Omit<ResponseEvaluationInput, "value" | "acceptedResponse"> & {
    value: readonly string[] | null;
    acceptedBlanks: readonly (readonly string[])[];
}>;
export type OrderedTextEvaluator = (input: OrderedTextEvaluationInput) => ResponseVerdict;
export type TitledTextEvaluationInput = Readonly<Omit<ResponseEvaluationInput, "value" | "acceptedResponse"> & {
    value: Readonly<TitledTextResponseValue> | null;
}>;
export type TitledTextEvaluator = (input: TitledTextEvaluationInput) => ResponseVerdict;
declare const registration: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<ResponseEvaluator, ResponseEvaluator>;
}, z.core.$strict>;
export declare const responseEvaluators: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<ResponseEvaluator, ResponseEvaluator>;
}, z.core.$strict>>;
export declare const indexResponseEvaluators: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<IndexResponseEvaluator, IndexResponseEvaluator>;
}, z.core.$strict>>;
export declare const orderedTextEvaluators: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<OrderedTextEvaluator, OrderedTextEvaluator>;
}, z.core.$strict>>;
export declare const titledTextEvaluators: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<TitledTextEvaluator, TitledTextEvaluator>;
}, z.core.$strict>>;
export type TitledTextEvaluatorRegistration = z.infer<typeof titledTextEvaluators>[number];
export type ResponseEvaluatorRegistration = z.infer<typeof registration>;
export type IndexResponseEvaluatorRegistration = z.infer<typeof indexResponseEvaluators>[number];
export type OrderedTextEvaluatorRegistration = z.infer<typeof orderedTextEvaluators>[number];
export declare function findResponseEvaluator<T extends VersionRef & {
    evaluate: unknown;
}>(registered: readonly T[], { id, version }: VersionRef): T["evaluate"] | undefined;
export {};
