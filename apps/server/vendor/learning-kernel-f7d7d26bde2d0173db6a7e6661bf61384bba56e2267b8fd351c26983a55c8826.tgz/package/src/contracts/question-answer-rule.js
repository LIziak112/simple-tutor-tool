import { z } from "zod";
import { versionRef } from "./reading.js";
import { indexResponseValue, orderedTextResponseValue, responseValue, titledTextResponseValue } from "./response.js";
const answeredSchema = z.boolean();
function registration(response, value) {
    return versionRef.extend({
        response: z.literal(response),
        isAnswered: z.custom(candidate => typeof candidate === "function"),
    }).transform(({ isAnswered, ...binding }) => ({
        ...binding,
        isAnswered: (raw) => answeredSchema.parse(isAnswered(value.parse(raw))),
    }));
}
export const questionAnswerRules = z.array(z.union([
    registration("choice", z.string()),
    registration("booleanOrString", responseValue),
    registration("optionIndexArray", indexResponseValue),
    registration("orderedTextBlanks", orderedTextResponseValue),
    registration("textWithOptionalTitle", titledTextResponseValue),
])).refine(rules => new Set(rules.map(({ id, version }) => JSON.stringify([id, version]))).size === rules.length, "须注册唯一的题目已答规则版本");
export function findQuestionAnswerRule(rules, reference, response) {
    return rules.find(rule => rule.id === reference.id && rule.version === reference.version && rule.response === response);
}
