import { z } from "zod";
import { isReservedReadingCapability } from "../builtins/reading-capabilities.js";
import { versionRef } from "./reading.js";
const choiceEvaluatorRegistration = versionRef.extend({
    evaluate: z.custom(value => typeof value === "function"),
});
export const choiceEvaluators = z.array(choiceEvaluatorRegistration).refine(registered => new Set(registered.map(({ id, version }) => JSON.stringify([id, version]))).size === registered.length
    && registered.every(({ id }) => !isReservedReadingCapability(id)), "宿主评估器必须使用不同的非内置标识和版本");
export function findChoiceEvaluator(registered, { id, version }) {
    return registered.find(evaluator => evaluator.id === id && evaluator.version === version)?.evaluate;
}
