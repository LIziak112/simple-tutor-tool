import { z } from "zod";
export declare const id: z.ZodString;
export declare const versionRef: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
}, z.core.$strict>;
export type VersionRef = z.infer<typeof versionRef>;
export declare const materialSchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    source: z.ZodString;
    title: z.ZodString;
    paragraphs: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        text: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const stepSchema: z.ZodObject<{
    id: z.ZodString;
    instructions: z.ZodString;
    tool: z.ZodObject<{
        id: z.ZodLiteral<"text-selection">;
        version: z.ZodLiteral<1>;
    }, z.core.$strict>;
    positionId: z.ZodString;
    slotId: z.ZodString;
    targetId: z.ZodString;
}, z.core.$strict>;
export declare const practiceSchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    title: z.ZodString;
    material: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
    }, z.core.$strict>;
    steps: z.ZodTuple<[z.ZodObject<{
        id: z.ZodString;
        instructions: z.ZodString;
        tool: z.ZodObject<{
            id: z.ZodLiteral<"text-selection">;
            version: z.ZodLiteral<1>;
        }, z.core.$strict>;
        positionId: z.ZodString;
        slotId: z.ZodString;
        targetId: z.ZodString;
    }, z.core.$strict>], null>;
}, z.core.$strict>;
export declare const publicationSchema: z.ZodObject<{
    material: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        source: z.ZodString;
        title: z.ZodString;
        paragraphs: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            text: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    practice: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        title: z.ZodString;
        material: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>;
        steps: z.ZodTuple<[z.ZodObject<{
            id: z.ZodString;
            instructions: z.ZodString;
            tool: z.ZodObject<{
                id: z.ZodLiteral<"text-selection">;
                version: z.ZodLiteral<1>;
            }, z.core.$strict>;
            positionId: z.ZodString;
            slotId: z.ZodString;
            targetId: z.ZodString;
        }, z.core.$strict>], null>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const startInput: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
    practiceId: z.ZodString;
}, z.core.$strict>;
export declare const redoInput: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
}, z.core.$strict>;
export declare const startReceipt: z.ZodObject<{
    activityId: z.ZodUUID;
    stepAttemptId: z.ZodUUID;
    startedAt: z.ZodISODateTime;
}, z.core.$strict>;
export declare const range: z.ZodObject<{
    paragraphId: z.ZodString;
    start: z.ZodInt;
    end: z.ZodInt;
}, z.core.$strict>;
export declare const selectionSchema: z.ZodObject<{
    material: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
    }, z.core.$strict>;
    positionId: z.ZodString;
    range: z.ZodObject<{
        paragraphId: z.ZodString;
        start: z.ZodInt;
        end: z.ZodInt;
    }, z.core.$strict>;
    text: z.ZodString;
}, z.core.$strict>;
export declare const saveInput: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    workId: z.ZodOptional<z.ZodUUID>;
    range: z.ZodObject<{
        paragraphId: z.ZodString;
        start: z.ZodInt;
        end: z.ZodInt;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const draftReceipt: z.ZodObject<{
    draft: z.ZodObject<{
        id: z.ZodUUID;
        version: z.ZodInt;
    }, z.core.$strict>;
    selection: z.ZodObject<{
        material: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>;
        positionId: z.ZodString;
        range: z.ZodObject<{
            paragraphId: z.ZodString;
            start: z.ZodInt;
            end: z.ZodInt;
        }, z.core.$strict>;
        text: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const submitInput: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    draft: z.ZodObject<{
        id: z.ZodUUID;
        version: z.ZodInt;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const submissionReceipt: z.ZodObject<{
    id: z.ZodUUID;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    confirmedAt: z.ZodISODateTime;
}, z.core.$strict>;
export declare const submissionDetail: z.ZodObject<{
    receipt: z.ZodObject<{
        id: z.ZodUUID;
        stepAttemptId: z.ZodUUID;
        slotId: z.ZodString;
        confirmedAt: z.ZodISODateTime;
    }, z.core.$strict>;
    selection: z.ZodObject<{
        material: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>;
        positionId: z.ZodString;
        range: z.ZodObject<{
            paragraphId: z.ZodString;
            start: z.ZodInt;
            end: z.ZodInt;
        }, z.core.$strict>;
        text: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const activityDetail: z.ZodObject<{
    activityId: z.ZodUUID;
    stepAttemptId: z.ZodUUID;
    startedAt: z.ZodISODateTime;
    title: z.ZodString;
    material: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
        source: z.ZodString;
        title: z.ZodString;
        paragraphs: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            text: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    step: z.ZodObject<{
        id: z.ZodString;
        instructions: z.ZodString;
        tool: z.ZodObject<{
            id: z.ZodLiteral<"text-selection">;
            version: z.ZodLiteral<1>;
        }, z.core.$strict>;
        positionId: z.ZodString;
        slotId: z.ZodString;
        targetId: z.ZodString;
    }, z.core.$strict>;
    status: z.ZodEnum<{
        active: "active";
        completed: "completed";
    }>;
    submission: z.ZodNullable<z.ZodObject<{
        receipt: z.ZodObject<{
            id: z.ZodUUID;
            stepAttemptId: z.ZodUUID;
            slotId: z.ZodString;
            confirmedAt: z.ZodISODateTime;
        }, z.core.$strict>;
        selection: z.ZodObject<{
            material: z.ZodObject<{
                id: z.ZodString;
                version: z.ZodInt;
            }, z.core.$strict>;
            positionId: z.ZodString;
            range: z.ZodObject<{
                paragraphId: z.ZodString;
                start: z.ZodInt;
                end: z.ZodInt;
            }, z.core.$strict>;
            text: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type Material = z.infer<typeof materialSchema>;
export type Step = z.infer<typeof stepSchema>;
export type StartInput = z.infer<typeof startInput>;
export type SaveInput = z.infer<typeof saveInput>;
export type SubmitInput = z.infer<typeof submitInput>;
export type SubmissionReceipt = z.infer<typeof submissionReceipt>;
export type SubmissionDetail = z.infer<typeof submissionDetail>;
export type ActivityDetail = z.infer<typeof activityDetail>;
