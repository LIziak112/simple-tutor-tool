import { z } from "zod";
import type { VersionRef } from "./reading.ts";
export type ChoiceEvaluationInput = Readonly<{
    activityId: string;
    stepAttemptId: string;
    slotId: string;
    practice: Readonly<VersionRef>;
    questionId: string;
    questionVersion: number;
    choice: string | null;
    acceptedChoice: string;
}>;
export type ChoiceEvaluator = (input: ChoiceEvaluationInput) => boolean;
declare const choiceEvaluatorRegistration: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<ChoiceEvaluator, ChoiceEvaluator>;
}, z.core.$strict>;
export type ChoiceEvaluatorRegistration = z.infer<typeof choiceEvaluatorRegistration>;
export declare const choiceEvaluators: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<ChoiceEvaluator, ChoiceEvaluator>;
}, z.core.$strict>>;
export declare function findChoiceEvaluator(registered: readonly ChoiceEvaluatorRegistration[], { id, version }: VersionRef): ChoiceEvaluator | undefined;
export {};
