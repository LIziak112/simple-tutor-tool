import { isDeepStrictEqual } from "node:util";
import { z } from "zod";
import { choiceConfirmationInput, confirmedQuestionRevision } from "./choice-confirmation.js";
import { versionedChoiceDraftInput } from "./choice-draft.js";
export const responseValue = z.union([z.boolean(), z.string()]);
export const optionIndex = z.int().nonnegative();
export const indexResponseValue = z.array(optionIndex);
export const orderedTextResponseValue = z.array(z.string());
export const titledTextResponseValue = z.strictObject({ body: z.string(), title: z.string().optional() })
    .transform(({ body, title }) => title === undefined ? { body } : { body, title });
export const responseFormat = z.enum(["booleanOrString", "optionIndexArray"]);
export const responseDraftValue = versionedChoiceDraftInput.pick({ questionVersion: true }).extend({ value: responseValue });
export const responseDraftInput = versionedChoiceDraftInput.omit({ choice: true }).extend({ value: responseValue });
export const indexResponseDraftValue = responseDraftValue.extend({ value: indexResponseValue });
export const indexResponseDraftInput = responseDraftInput.extend({ value: indexResponseValue });
export const responseConfirmation = z.strictObject({
    kind: z.literal("responseConfirmation"),
    questions: z.array(confirmedQuestionRevision.extend({ value: responseValue.nullable() })).min(1),
});
export const indexResponseConfirmation = z.strictObject({
    kind: z.literal("indexResponseConfirmation"),
    questions: z.array(confirmedQuestionRevision.extend({ value: indexResponseValue.nullable() })).min(1),
});
const responseConfirmationKind = responseConfirmation.pick({ kind: true }).loose();
export function readResponseConfirmation(content) {
    return responseConfirmationKind.safeParse(content).success ? responseConfirmation.parse(content) : undefined;
}
const indexResponseConfirmationKind = indexResponseConfirmation.pick({ kind: true }).loose();
export function readIndexResponseConfirmation(content) {
    return indexResponseConfirmationKind.safeParse(content).success ? indexResponseConfirmation.parse(content) : undefined;
}
export function hasStoredResponse(value) {
    if (value === null)
        return false;
    if (typeof value !== "object")
        return true;
    if ("body" in value)
        return value.body.trim() !== "";
    return value.some(item => typeof item === "number" || item.trim() !== "");
}
export function sameStoredResponse(left, right) {
    if (left === null || right === null || typeof left !== "object" || typeof right !== "object")
        return left === right;
    if ("body" in left || "body" in right)
        return isDeepStrictEqual(left, right);
    return left.length === right.length && left.every((item, offset) => item === right[offset]);
}
