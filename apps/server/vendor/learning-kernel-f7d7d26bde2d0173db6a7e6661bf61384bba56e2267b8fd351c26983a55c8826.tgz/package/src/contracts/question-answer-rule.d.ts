import { z } from "zod";
import type { QuestionDeliveryFormat } from "./question-delivery.ts";
import type { VersionRef } from "./reading.ts";
import type { StoredResponseValue } from "./response.ts";
export declare const questionAnswerRules: z.ZodArray<z.ZodUnion<readonly [z.ZodPipe<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    response: z.ZodLiteral<"choice">;
    isAnswered: z.ZodCustom<(input: string) => boolean, (input: string) => boolean>;
}, z.core.$strict>, z.ZodTransform<{
    id: string;
    version: number;
    response: "choice";
    isAnswered: (raw: StoredResponseValue) => boolean;
}, {
    id: string;
    version: number;
    response: "choice";
    isAnswered: (input: string) => boolean;
}>>, z.ZodPipe<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    response: z.ZodLiteral<"booleanOrString">;
    isAnswered: z.ZodCustom<(input: Readonly<string | boolean>) => boolean, (input: Readonly<string | boolean>) => boolean>;
}, z.core.$strict>, z.ZodTransform<{
    id: string;
    version: number;
    response: "booleanOrString";
    isAnswered: (raw: StoredResponseValue) => boolean;
}, {
    id: string;
    version: number;
    response: "booleanOrString";
    isAnswered: (input: Readonly<string | boolean>) => boolean;
}>>, z.ZodPipe<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    response: z.ZodLiteral<"optionIndexArray">;
    isAnswered: z.ZodCustom<(input: readonly number[]) => boolean, (input: readonly number[]) => boolean>;
}, z.core.$strict>, z.ZodTransform<{
    id: string;
    version: number;
    response: "optionIndexArray";
    isAnswered: (raw: StoredResponseValue) => boolean;
}, {
    id: string;
    version: number;
    response: "optionIndexArray";
    isAnswered: (input: readonly number[]) => boolean;
}>>, z.ZodPipe<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    response: z.ZodLiteral<"orderedTextBlanks">;
    isAnswered: z.ZodCustom<(input: readonly string[]) => boolean, (input: readonly string[]) => boolean>;
}, z.core.$strict>, z.ZodTransform<{
    id: string;
    version: number;
    response: "orderedTextBlanks";
    isAnswered: (raw: StoredResponseValue) => boolean;
}, {
    id: string;
    version: number;
    response: "orderedTextBlanks";
    isAnswered: (input: readonly string[]) => boolean;
}>>, z.ZodPipe<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    response: z.ZodLiteral<"textWithOptionalTitle">;
    isAnswered: z.ZodCustom<(input: Readonly<{
        body: string;
        title?: string;
    }>) => boolean, (input: Readonly<{
        body: string;
        title?: string;
    }>) => boolean>;
}, z.core.$strict>, z.ZodTransform<{
    id: string;
    version: number;
    response: "textWithOptionalTitle";
    isAnswered: (raw: StoredResponseValue) => boolean;
}, {
    id: string;
    version: number;
    response: "textWithOptionalTitle";
    isAnswered: (input: Readonly<{
        body: string;
        title?: string;
    }>) => boolean;
}>>]>>;
export type QuestionAnswerRuleRegistration = z.input<typeof questionAnswerRules>[number];
export type BoundQuestionAnswerRules = readonly z.output<typeof questionAnswerRules>[number][];
export declare function findQuestionAnswerRule(rules: BoundQuestionAnswerRules, reference: VersionRef, response: QuestionDeliveryFormat | undefined): {
    id: string;
    version: number;
    response: "booleanOrString";
    isAnswered: (raw: StoredResponseValue) => boolean;
} | {
    id: string;
    version: number;
    response: "choice";
    isAnswered: (raw: StoredResponseValue) => boolean;
} | {
    id: string;
    version: number;
    response: "optionIndexArray";
    isAnswered: (raw: StoredResponseValue) => boolean;
} | {
    id: string;
    version: number;
    response: "orderedTextBlanks";
    isAnswered: (raw: StoredResponseValue) => boolean;
} | {
    id: string;
    version: number;
    response: "textWithOptionalTitle";
    isAnswered: (raw: StoredResponseValue) => boolean;
} | undefined;
