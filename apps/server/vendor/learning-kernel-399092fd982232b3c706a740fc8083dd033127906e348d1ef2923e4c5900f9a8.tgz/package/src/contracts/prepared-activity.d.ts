import { z } from "zod";
export declare const preparedVersionIntent: z.ZodLiteral<"questionDeliveryMode">;
export declare const preparedVersionInput: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
    stepAttemptId: z.ZodUUID;
    expectedPracticeVersion: z.ZodInt;
    practiceVersion: z.ZodInt;
    intent: z.ZodOptional<z.ZodLiteral<"questionDeliveryMode">>;
}, z.core.$strict>;
export declare const preparedVersionReceipt: z.ZodObject<{
    activityId: z.ZodUUID;
    stepAttemptId: z.ZodUUID;
    startedAt: z.ZodISODateTime;
    practiceVersion: z.ZodInt;
}, z.core.$strict>;
export type PreparedActivityVersionInput = z.infer<typeof preparedVersionInput>;
export type PreparedActivityVersionReceipt = z.infer<typeof preparedVersionReceipt>;
