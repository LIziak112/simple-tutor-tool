import { z } from "zod";
import { choiceDraftAmendmentInput } from "./choice-amendment.js";
import { id, versionRef } from "./reading.js";
import { readingQuestion } from "./reading-publication.js";
export const choiceSnapshotContent = readingQuestion.pick({ prompt: true, options: true }).extend({ acceptedChoice: id });
export const choiceSnapshotRevisionInput = choiceDraftAmendmentInput.omit({ choice: true }).extend(choiceSnapshotContent.shape);
export const choiceSnapshotRevision = z.strictObject({
    slotId: id, questionId: id, questionVersion: versionRef.shape.version, revision: z.int().positive(),
});
