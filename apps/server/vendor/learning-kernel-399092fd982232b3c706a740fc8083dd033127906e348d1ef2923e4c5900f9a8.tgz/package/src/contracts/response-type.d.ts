import type { VersionRef } from "./reading.ts";
export type QuestionDefinition = Readonly<Record<string, unknown>> & Readonly<{
    id: string;
    version?: number | undefined;
    prompt: string;
    options: Readonly<Record<string, string>>;
    response?: string | undefined;
}>;
export type QuestionIssue = (path: readonly (string | number)[], message: string) => void;
export type ResponseType<Value, Key> = Readonly<VersionRef> & {
    readonly config?: readonly string[];
    validateQuestion(question: QuestionDefinition, issue: QuestionIssue): void;
    parseValue(value: unknown, question: QuestionDefinition): Value;
    isAnswered(value: Value, question: QuestionDefinition): boolean;
    parseKey?(key: unknown, question: QuestionDefinition): Key | undefined;
    wholePaperKey?: Readonly<{
        field: string;
        toKey(value: unknown): unknown;
    }>;
};
export type RegisteredResponseType = Readonly<VersionRef> & {
    readonly config: readonly string[];
    validateQuestion(question: QuestionDefinition, issue: QuestionIssue): void;
    parseValue(value: unknown, question: QuestionDefinition): unknown;
    isAnswered(value: unknown, question: QuestionDefinition): boolean;
    parseKey: ((key: unknown, question: QuestionDefinition) => unknown) | undefined;
    wholePaperKey: Readonly<{
        field: string;
        toKey(value: unknown): unknown;
    }> | undefined;
};
export declare function defineResponseType<Value, Key>(type: ResponseType<Value, Key>): RegisteredResponseType;
