import { z } from "zod";
import { choiceConfirmationInput } from "./choice-confirmation.ts";
export declare const responseValue: z.ZodJSONSchema;
export declare const responseDraftValue: z.ZodObject<{
    questionVersion: z.ZodInt;
    value: z.ZodJSONSchema;
}, z.core.$strict>;
export declare const responseDraftInput: z.ZodObject<{
    questionVersion: z.ZodInt;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    operationId: z.ZodString;
    baseRevision: z.ZodInt;
    value: z.ZodUnknown;
}, z.core.$strict>;
export declare const responseConfirmation: z.ZodObject<{
    kind: z.ZodLiteral<"responseConfirmation">;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        questionVersion: z.ZodInt;
        revision: z.ZodInt;
        original: z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"frozen">;
            documentId: z.ZodString;
            versionId: z.ZodString;
            sha256: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"none">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"missing">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"uncollected">;
        }, z.core.$strict>], "state">;
        value: z.ZodNullable<z.ZodJSONSchema>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare function readResponseConfirmation(content: unknown): ResponseConfirmation | undefined;
export type ResponseValue = z.infer<typeof responseValue>;
export type ResponseDraftRequest = z.infer<typeof responseDraftInput>;
export type ResponseDraftInput = Omit<ResponseDraftRequest, "value"> & {
    value: ResponseValue;
};
export type ResponseConfirmationInput = z.infer<typeof choiceConfirmationInput>;
export type ResponseConfirmation = z.infer<typeof responseConfirmation>;
