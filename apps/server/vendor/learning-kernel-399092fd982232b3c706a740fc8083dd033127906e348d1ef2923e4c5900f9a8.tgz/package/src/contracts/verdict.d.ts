import { z } from "zod";
import type { ConfirmationScope } from "./choice-confirmation.ts";
export declare const frozenConfirmationVerdictMode: z.ZodEnum<{
    choiceConfirmation: "choiceConfirmation";
    responseConfirmation: "responseConfirmation";
}>;
export type FrozenConfirmationVerdictMode = z.infer<typeof frozenConfirmationVerdictMode>;
export declare const verdictLocation: z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    questionId: z.ZodString;
}, z.core.$strict>;
export declare const verdictCommand: z.ZodDiscriminatedUnion<[z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    questionId: z.ZodString;
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
    expectedRevision: z.ZodInt;
    reason: z.ZodString;
    action: z.ZodLiteral<"override">;
    correct: z.ZodBoolean;
}, z.core.$strict>, z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    questionId: z.ZodString;
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
    expectedRevision: z.ZodInt;
    reason: z.ZodString;
    action: z.ZodLiteral<"withdraw">;
    withdrawId: z.ZodUUID;
}, z.core.$strict>], "action">;
export declare const verdictReceipt: z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    questionId: z.ZodString;
    id: z.ZodUUID;
    revision: z.ZodInt;
}, z.core.$strict>;
export type VerdictCommand = z.infer<typeof verdictCommand>;
export type VerdictReceipt = z.infer<typeof verdictReceipt>;
export type VerdictLocation = z.infer<typeof verdictLocation>;
export type ReviewedDelivery = "questionDelivery" | FrozenConfirmationVerdictMode;
export type ReviewScope = Readonly<ConfirmationScope & {
    reviewerId: string;
    submissionId: string;
    slotId: string;
    delivery: ReviewedDelivery;
}>;
export type ReviewAccess = ReviewScope & (Readonly<{
    purpose: "readReview";
}> | Readonly<{
    purpose: "reviseVerdict";
    targetId: string;
    questionId: string;
    questionVersion: number;
    action: VerdictCommand["action"];
}>);
export type AuthorizeReview = (access: ReviewAccess) => boolean;
