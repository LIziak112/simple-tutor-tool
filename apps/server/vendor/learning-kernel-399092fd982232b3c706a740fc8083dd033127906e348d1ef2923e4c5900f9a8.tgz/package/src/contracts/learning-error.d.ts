export declare class LearningError extends Error {
    readonly status: number;
    readonly code: string;
    constructor(status: number, code: string);
}
