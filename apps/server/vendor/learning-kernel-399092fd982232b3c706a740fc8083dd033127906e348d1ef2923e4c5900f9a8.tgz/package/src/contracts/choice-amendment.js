import { z } from "zod";
import { versionedChoiceDraftInput } from "./choice-draft.js";
export const choiceDraftAmendmentInput = versionedChoiceDraftInput.extend({ reason: z.string().trim().min(1).max(2000) });
