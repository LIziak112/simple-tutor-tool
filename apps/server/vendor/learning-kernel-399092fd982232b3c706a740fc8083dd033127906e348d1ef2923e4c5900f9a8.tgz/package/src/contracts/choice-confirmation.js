import { z } from "zod";
import { id, versionRef } from "./reading.js";
const originalEvidence = z.discriminatedUnion("state", [
    z.strictObject({
        state: z.literal("frozen"), documentId: id, versionId: id,
        sha256: z.string().regex(/^[0-9a-f]{64}$/).optional(),
    }),
    z.strictObject({ state: z.literal("none") }),
    z.strictObject({ state: z.literal("missing") }),
    z.strictObject({ state: z.literal("uncollected") }),
]);
export const confirmationKey = z.strictObject({
    protocolVersion: z.literal(1), stepAttemptId: z.uuid(), operationId: id,
});
export const confirmedQuestionRevision = z.strictObject({
    questionId: id, questionVersion: versionRef.shape.version, revision: z.int().nonnegative(), original: originalEvidence,
});
export const choiceConfirmationInput = confirmationKey.extend({
    slotId: id, questions: z.array(confirmedQuestionRevision).min(1),
});
const confirmedQuestion = confirmedQuestionRevision.extend({ choice: id.nullable() });
export const choiceConfirmation = z.strictObject({
    kind: z.literal("choiceConfirmation"), questions: z.array(confirmedQuestion).min(1),
});
const confirmationKind = choiceConfirmation.pick({ kind: true }).loose();
export function readChoiceConfirmation(content) {
    return confirmationKind.safeParse(content).success ? choiceConfirmation.parse(content) : undefined;
}
