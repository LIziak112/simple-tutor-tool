import { z } from "zod";
export const verdictResult = z.discriminatedUnion("status", [
    z.strictObject({ status: z.literal("judged"), correct: z.boolean() }),
    z.strictObject({ status: z.literal("needsReview") }),
]);
