export function defineResponseType(type) {
    const { id, version, config = [], wholePaperKey } = type;
    const parseKey = type.parseKey;
    return {
        id, version, config, wholePaperKey,
        validateQuestion: (question, issue) => type.validateQuestion(question, issue),
        parseValue: (value, question) => type.parseValue(value, question),
        isAnswered: (value, question) => type.isAnswered(type.parseValue(value, question), question),
        parseKey: parseKey && ((key, question) => parseKey(key, question)),
    };
}
