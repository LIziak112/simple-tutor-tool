import { z } from "zod";
export declare const activityOpeningKey: z.ZodObject<{
    studentId: z.ZodString;
    operationId: z.ZodString;
}, z.core.$strict>;
export declare const activityBinding: z.ZodObject<{
    studentId: z.ZodString;
    operationId: z.ZodString;
    activityId: z.ZodUUID;
}, z.core.$strict>;
export declare const teacherAmendmentBinding: z.ZodObject<{
    kind: z.ZodEnum<{
        answer: "answer";
        snapshot: "snapshot";
    }>;
    activityId: z.ZodUUID;
    studentId: z.ZodString;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    reviewerId: z.ZodString;
    operationId: z.ZodString;
    revision: z.ZodInt;
}, z.core.$strict>;
export declare const teacherAmendmentBindingClaims: z.ZodObject<{
    completed: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            answer: "answer";
            snapshot: "snapshot";
        }>;
        activityId: z.ZodUUID;
        studentId: z.ZodString;
        stepAttemptId: z.ZodUUID;
        slotId: z.ZodString;
        questionId: z.ZodString;
        reviewerId: z.ZodString;
        operationId: z.ZodString;
        revision: z.ZodInt;
    }, z.core.$strict>>;
    pending: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            answer: "answer";
            snapshot: "snapshot";
        }>;
        activityId: z.ZodUUID;
        studentId: z.ZodString;
        stepAttemptId: z.ZodUUID;
        slotId: z.ZodString;
        questionId: z.ZodString;
        reviewerId: z.ZodString;
        operationId: z.ZodString;
        revision: z.ZodInt;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const activityBindingClaims: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    bindings: z.ZodArray<z.ZodObject<{
        studentId: z.ZodString;
        operationId: z.ZodString;
        activityId: z.ZodUUID;
    }, z.core.$strict>>;
    openingIntents: z.ZodArray<z.ZodObject<{
        studentId: z.ZodString;
        operationId: z.ZodString;
    }, z.core.$strict>>;
    teacherAmendments: z.ZodOptional<z.ZodObject<{
        completed: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                answer: "answer";
                snapshot: "snapshot";
            }>;
            activityId: z.ZodUUID;
            studentId: z.ZodString;
            stepAttemptId: z.ZodUUID;
            slotId: z.ZodString;
            questionId: z.ZodString;
            reviewerId: z.ZodString;
            operationId: z.ZodString;
            revision: z.ZodInt;
        }, z.core.$strict>>;
        pending: z.ZodArray<z.ZodObject<{
            kind: z.ZodEnum<{
                answer: "answer";
                snapshot: "snapshot";
            }>;
            activityId: z.ZodUUID;
            studentId: z.ZodString;
            stepAttemptId: z.ZodUUID;
            slotId: z.ZodString;
            questionId: z.ZodString;
            reviewerId: z.ZodString;
            operationId: z.ZodString;
            revision: z.ZodInt;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ActivityBindingClaims = z.infer<typeof activityBindingClaims>;
export type ActivityOpeningKey = z.infer<typeof activityOpeningKey>;
export type TeacherAmendmentBinding = z.infer<typeof teacherAmendmentBinding>;
export type TeacherAmendmentBindingClaims = z.infer<typeof teacherAmendmentBindingClaims>;
