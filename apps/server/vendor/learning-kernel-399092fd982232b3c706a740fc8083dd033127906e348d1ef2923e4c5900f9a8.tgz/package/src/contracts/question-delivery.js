import { z } from "zod";
import { choiceConfirmationInput, confirmedQuestionRevision } from "./choice-confirmation.js";
import { id, versionRef } from "./reading.js";
import { responseDraftInput, responseDraftValue, responseValue } from "./response.js";
import { frozenConfirmationVerdictMode } from "./verdict.js";
export function orderedQuestionValues(values) {
    return Object.fromEntries(Object.entries(values).sort(([a], [b]) => a === b ? 0 : a < b ? -1 : 1));
}
export const questionDeliveryMode = z.discriminatedUnion("mode", [
    z.strictObject({ mode: z.literal("whole") }),
    z.strictObject({ mode: z.literal("perQuestion"), questionSlots: z.record(id, id).transform(orderedQuestionValues) }),
]);
const questionDeliveryKey = z.looseObject({ response: id });
export const questionDeliveryScoringKey = versionRef.extend({
    acceptedByQuestion: z.record(id, questionDeliveryKey).transform(orderedQuestionValues),
});
export const questionDeliveryReviewBasis = versionRef.extend({
    reviewCriteria: z.string().refine(criteria => criteria.trim().length > 0),
});
export const questionDeliveryReviewMode = z.union([z.literal("verdicts"), frozenConfirmationVerdictMode]).optional();
export const questionDeliveryDraftInput = responseDraftInput;
export const questionDeliveryDraftValue = responseDraftValue;
export const questionDeliveryInput = z.discriminatedUnion("source", [
    choiceConfirmationInput.extend({ source: z.literal("whole") }),
    choiceConfirmationInput.extend({ source: z.literal("question"), questions: z.tuple([confirmedQuestionRevision]) }),
    choiceConfirmationInput.extend({ source: z.literal("finish") }),
]);
const deliveryWork = z.strictObject({
    kind: z.literal("questionDelivery"),
    slotId: id,
    questions: z.array(confirmedQuestionRevision.extend({ value: responseValue.nullable() })).min(1),
});
export const questionDelivery = z.discriminatedUnion("source", [
    deliveryWork.extend({ source: z.enum(["whole", "question"]) }),
    deliveryWork.extend({ source: z.literal("finish"), requestQuestions: choiceConfirmationInput.shape.questions }),
]);
const questionDeliveryKind = deliveryWork.pick({ kind: true }).loose();
export function readQuestionDelivery(content) {
    return questionDeliveryKind.safeParse(content).success ? questionDelivery.parse(content) : undefined;
}
export function questionDeliveryIntent(delivery) {
    if (delivery.source === "finish")
        return delivery.requestQuestions;
    return delivery.questions.map(({ value, ...revision }) => revision);
}
export function questionDeliveryView({ source, slotId, questions }) {
    return { source, slotId, questions };
}
