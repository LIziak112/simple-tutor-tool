import { z } from "zod";
import type { ChoiceDraftScope } from "./choice-draft.ts";
export declare const choiceDraftAmendmentInput: z.ZodObject<{
    questionVersion: z.ZodInt;
    choice: z.ZodString;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    operationId: z.ZodString;
    baseRevision: z.ZodInt;
    reason: z.ZodString;
}, z.core.$strict>;
export type ChoiceDraftAmendmentInput = z.infer<typeof choiceDraftAmendmentInput>;
export type ChoiceDraftAmendmentScope = ChoiceDraftScope;
export type ChoiceReviewerScope = Readonly<Omit<ChoiceDraftAmendmentScope, "protocolVersion"> & {
    reviewerId: string;
    studentId: string;
    activityId: string;
}>;
export type AuthorizeChoiceDraftAmendment = (scope: ChoiceReviewerScope & Readonly<{
    action: "read" | "amend";
}>) => boolean;
