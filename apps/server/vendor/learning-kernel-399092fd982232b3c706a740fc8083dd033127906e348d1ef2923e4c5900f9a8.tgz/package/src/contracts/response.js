import { z } from "zod";
import { choiceConfirmationInput, confirmedQuestionRevision } from "./choice-confirmation.js";
import { versionedChoiceDraftInput } from "./choice-draft.js";
export const responseValue = z.json();
export const responseDraftValue = versionedChoiceDraftInput.pick({ questionVersion: true }).extend({ value: responseValue });
export const responseDraftInput = versionedChoiceDraftInput.omit({ choice: true }).extend({ value: z.unknown() });
export const responseConfirmation = z.strictObject({
    kind: z.literal("responseConfirmation"),
    questions: z.array(confirmedQuestionRevision.extend({ value: responseValue.nullable() })).min(1),
});
const storedConfirmation = responseConfirmation.extend({ kind: z.enum(["responseConfirmation", "indexResponseConfirmation"]) });
const storedConfirmationKind = storedConfirmation.pick({ kind: true }).loose();
export function readResponseConfirmation(content) {
    if (!storedConfirmationKind.safeParse(content).success)
        return undefined;
    const { questions } = storedConfirmation.parse(content);
    return { kind: "responseConfirmation", questions };
}
