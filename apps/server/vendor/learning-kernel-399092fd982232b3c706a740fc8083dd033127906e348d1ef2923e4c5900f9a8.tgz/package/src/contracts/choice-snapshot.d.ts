import { z } from "zod";
import type { ChoiceReviewerScope } from "./choice-amendment.ts";
export declare const choiceSnapshotContent: z.ZodObject<{
    prompt: z.ZodString;
    options: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    acceptedChoice: z.ZodString;
}, z.core.$loose>;
export declare const choiceSnapshotRevisionInput: z.ZodObject<{
    questionVersion: z.ZodInt;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    operationId: z.ZodString;
    baseRevision: z.ZodInt;
    reason: z.ZodString;
    prompt: z.ZodString;
    options: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    acceptedChoice: z.ZodString;
}, z.core.$strict>;
export type ChoiceSnapshotRevisionInput = z.infer<typeof choiceSnapshotRevisionInput>;
export type ChoiceSnapshotReviewerScope = ChoiceReviewerScope & Readonly<{
    baseRevision: number;
    operationId: string;
}>;
export type AuthorizeChoiceSnapshotRevision = (scope: ChoiceSnapshotReviewerScope) => boolean;
export type HasChoiceSnapshotEvidence = (scope: ChoiceSnapshotReviewerScope) => boolean;
export declare const choiceSnapshotRevision: z.ZodObject<{
    slotId: z.ZodString;
    questionId: z.ZodString;
    questionVersion: z.ZodInt;
    revision: z.ZodInt;
}, z.core.$strict>;
