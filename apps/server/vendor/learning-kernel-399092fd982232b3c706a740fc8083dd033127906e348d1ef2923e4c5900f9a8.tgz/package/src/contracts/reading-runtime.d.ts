import { z } from "zod";
export declare const readingSaveInput: z.ZodObject<{
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    protocolVersion: z.ZodLiteral<1>;
    workId: z.ZodOptional<z.ZodUUID>;
    ranges: z.ZodArray<z.ZodObject<{
        paragraphId: z.ZodString;
        start: z.ZodInt;
        end: z.ZodInt;
        role: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const readingSelection: z.ZodObject<{
    material: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodInt;
    }, z.core.$strict>;
    positionId: z.ZodString;
    ranges: z.ZodArray<z.ZodObject<{
        role: z.ZodString;
        range: z.ZodObject<{
            paragraphId: z.ZodString;
            start: z.ZodInt;
            end: z.ZodInt;
        }, z.core.$strict>;
        text: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const readingDraftReceipt: z.ZodObject<{
    draft: z.ZodObject<{
        id: z.ZodUUID;
        version: z.ZodInt;
    }, z.core.$strict>;
    selection: z.ZodObject<{
        material: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodInt;
        }, z.core.$strict>;
        positionId: z.ZodString;
        ranges: z.ZodArray<z.ZodObject<{
            role: z.ZodString;
            range: z.ZodObject<{
                paragraphId: z.ZodString;
                start: z.ZodInt;
                end: z.ZodInt;
            }, z.core.$strict>;
            text: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const readingAnswer: z.ZodObject<{
    choices: z.ZodRecord<z.ZodString, z.ZodString>;
    references: z.ZodRecord<z.ZodString, z.ZodUUID>;
    reason: z.ZodOptional<z.ZodObject<{
        text: z.ZodString;
        independent: z.ZodBoolean;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const readingAnswerInput: z.ZodObject<{
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    choices: z.ZodRecord<z.ZodString, z.ZodString>;
    references: z.ZodRecord<z.ZodString, z.ZodUUID>;
    reason: z.ZodOptional<z.ZodObject<{
        text: z.ZodString;
        independent: z.ZodBoolean;
    }, z.core.$strict>>;
    protocolVersion: z.ZodLiteral<1>;
    workId: z.ZodOptional<z.ZodUUID>;
}, z.core.$strict>;
export declare const readingAnswerDraft: z.ZodObject<{
    draft: z.ZodObject<{
        id: z.ZodUUID;
        version: z.ZodInt;
    }, z.core.$strict>;
    answer: z.ZodObject<{
        choices: z.ZodRecord<z.ZodString, z.ZodString>;
        references: z.ZodRecord<z.ZodString, z.ZodUUID>;
        reason: z.ZodOptional<z.ZodObject<{
            text: z.ZodString;
            independent: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type ReadingSaveInput = z.infer<typeof readingSaveInput>;
export type ReadingSelection = z.infer<typeof readingSelection>;
export type ReadingAnswer = z.infer<typeof readingAnswer>;
export type ReadingAnswerInput = z.infer<typeof readingAnswerInput>;
