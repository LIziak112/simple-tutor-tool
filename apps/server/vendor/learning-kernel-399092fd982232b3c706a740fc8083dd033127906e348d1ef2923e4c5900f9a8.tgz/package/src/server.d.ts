import { z } from "zod";
import type { AuthorizeConfirmationRecovery, ChoiceConfirmationInput, ConfirmationKey, VerifyOriginal } from "./contracts/choice-confirmation.ts";
import type { AuthorizeChoiceDraftAmendment, ChoiceDraftAmendmentInput, ChoiceDraftAmendmentScope } from "./contracts/choice-amendment.ts";
import type { ChoiceDraftInput, CurrentChoiceDraftMode, UnversionedChoiceDraftInput } from "./contracts/choice-draft.ts";
import type { AuthorizeChoiceSnapshotRevision, ChoiceSnapshotRevisionInput, ChoiceSnapshotReviewerScope, HasChoiceSnapshotEvidence } from "./contracts/choice-snapshot.ts";
import type { QuestionDeliveryDraftInput, QuestionDeliveryInput } from "./contracts/question-delivery.ts";
import type { AuthorizeReview, FrozenConfirmationVerdictMode, VerdictCommand } from "./contracts/verdict.ts";
import type { PreparedActivityVersionInput, PreparedActivityVersionReceipt } from "./contracts/prepared-activity.ts";
import { publicationSchema } from "./contracts/reading.ts";
import { readingPublicationSchema } from "./contracts/reading-publication.ts";
import type { ToolCapability } from "./contracts/capabilities.ts";
import type { EvaluatorRegistration, QuestionAnswerRule } from "./contracts/evaluator.ts";
import type { ResponseConfirmationInput, ResponseDraftInput } from "./contracts/response.ts";
import type { RegisteredResponseType } from "./contracts/response-type.ts";
import { LearningError } from "./contracts/learning-error.ts";
import { recoverQuestionDelivery } from "./kernel/question-delivery-confirmation.ts";
import { readChoiceConfirmationVerdicts, readQuestionDeliveryReview, readQuestionDeliveryVerdicts, readResponseConfirmationVerdicts } from "./kernel/question-delivery-review.ts";
import type { EvaluationSummary } from "./kernel/pending-evaluation.ts";
import type { RuntimeCheckpoint } from "./kernel/runtime-checkpoint.ts";
import { readActivity } from "./kernel/submission.ts";
declare const runtimeOptions: z.ZodObject<{
    databasePath: z.ZodString;
    tools: z.ZodDefault<z.ZodArray<z.ZodCustom<ToolCapability, ToolCapability>>>;
    responseTypes: z.ZodDefault<z.ZodArray<z.ZodCustom<RegisteredResponseType, RegisteredResponseType>>>;
    evaluators: z.ZodDefault<z.ZodArray<z.ZodCustom<EvaluatorRegistration, EvaluatorRegistration>>>;
    questionAnswerRules: z.ZodDefault<z.ZodArray<z.ZodCustom<QuestionAnswerRule, QuestionAnswerRule>>>;
    authorizeChoiceDraftAmendment: z.ZodOptional<z.ZodCustom<AuthorizeChoiceDraftAmendment, AuthorizeChoiceDraftAmendment>>;
    authorizeChoiceSnapshotRevision: z.ZodOptional<z.ZodCustom<AuthorizeChoiceSnapshotRevision, AuthorizeChoiceSnapshotRevision>>;
    hasChoiceSnapshotEvidence: z.ZodOptional<z.ZodCustom<HasChoiceSnapshotEvidence, HasChoiceSnapshotEvidence>>;
    verifyOriginal: z.ZodOptional<z.ZodCustom<VerifyOriginal, VerifyOriginal>>;
    authorizeConfirmationRecovery: z.ZodOptional<z.ZodCustom<AuthorizeConfirmationRecovery, AuthorizeConfirmationRecovery>>;
    authorizeReview: z.ZodOptional<z.ZodCustom<AuthorizeReview, AuthorizeReview>>;
    clock: z.ZodOptional<z.ZodCustom<() => Date, () => Date>>;
    checkpoint: z.ZodOptional<z.ZodCustom<RuntimeCheckpoint, RuntimeCheckpoint>>;
}, z.core.$strict>;
declare const studentPrincipal: z.ZodObject<{
    role: z.ZodLiteral<"student">;
    id: z.ZodString;
}, z.core.$strict>;
declare const reviewerPrincipal: z.ZodObject<{
    role: z.ZodLiteral<"reviewer">;
    id: z.ZodString;
}, z.core.$strict>;
declare const publishedStartInput: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    operationId: z.ZodString;
    practiceId: z.ZodString;
    practiceVersion: z.ZodInt;
}, z.core.$strict>;
export { LearningError };
export { verifyActivityBindings } from "./kernel/activity-bindings.ts";
export type { AuthorizeChoiceSnapshotRevision, ChoiceSnapshotRevisionInput, ChoiceSnapshotReviewerScope, HasChoiceSnapshotEvidence };
export type { AuthorizeChoiceDraftAmendment, ChoiceDraftAmendmentInput, ChoiceDraftAmendmentScope };
export type ReviewerPrincipal = z.input<typeof reviewerPrincipal>;
export type { ActivityBindingClaims, TeacherAmendmentBinding, TeacherAmendmentBindingClaims } from "./contracts/activity-bindings.ts";
export type { PreparedActivityVersionInput, PreparedActivityVersionReceipt };
export type { StudentValue, ToolCapability } from "./contracts/capabilities.ts";
export type { EvaluationContext, EvaluationInput, Evaluator, EvaluatorRegistration, QuestionAnswerRule, VerdictResult } from "./contracts/evaluator.ts";
export type { QuestionDefinition, QuestionIssue, RegisteredResponseType, ResponseType } from "./contracts/response-type.ts";
export { defineResponseType } from "./contracts/response-type.ts";
export { defaultEvaluators, defaultResponseTypes, defaultTools } from "./extensions/index.ts";
export type { QuestionDeliveryDraftInput, QuestionDeliveryInput };
export type { AuthorizeReview, ReviewAccess, ReviewedDelivery, ReviewScope, VerdictCommand, VerdictReceipt } from "./contracts/verdict.ts";
export { QuestionDeliveryConflict } from "./kernel/question-delivery-drafts.ts";
export { ChoiceConfirmationConflict } from "./kernel/choice-confirmation.ts";
export type { ChoiceDraftActivity } from "./kernel/choice-draft-activity.ts";
export { ChoiceSnapshotRevisionConflict } from "./kernel/choice-snapshot.ts";
export { ChoiceDraftConflict } from "./kernel/choice-drafts.ts";
export { ResponseConfirmationConflict } from "./kernel/response-confirmation.ts";
export { ResponseDraftConflict } from "./kernel/response-drafts.ts";
export type { EvaluationSummary } from "./kernel/pending-evaluation.ts";
export type { RuntimeCheckpoint } from "./kernel/runtime-checkpoint.ts";
export type { ResponseConfirmation, ResponseConfirmationInput, ResponseDraftInput, ResponseValue } from "./contracts/response.ts";
export type { ChoiceDraftInput, AuthorizeConfirmationRecovery, ChoiceConfirmationInput, ConfirmationKey, CurrentChoiceDraftMode, UnversionedChoiceDraftInput, VerifyOriginal };
export type PublicationInput = z.input<typeof publicationSchema> | z.input<typeof readingPublicationSchema>;
export type StudentPrincipal = z.input<typeof studentPrincipal>;
export type PublishedStartInput = z.input<typeof publishedStartInput>;
export type StudentActivity = ReturnType<typeof readActivity>;
type DeclaredQuestionDeliveryRecovery = ReturnType<typeof recoverQuestionDelivery>;
type AutomaticQuestionDeliveryRecovery = Omit<Extract<DeclaredQuestionDeliveryRecovery, {
    assessment: "automatic";
}>, "assessment">;
export declare function openLearningRuntime(options: z.input<typeof runtimeOptions>): {
    startLatest(principal: {
        role: string;
        id: string;
    }, input: unknown, options?: {
        assignedReviewer?: string;
    }): {
        activityId: string;
        stepAttemptId: string;
        startedAt: string;
    };
    redo(principal: {
        role: string;
        id: string;
    }, activityId: string, input: unknown): {
        activityId: string;
        stepAttemptId: string;
        startedAt: string;
    };
    saveDraft(principal: {
        role: string;
        id: string;
    }, activityId: string, input: unknown): {
        draft: {
            id: string;
            version: number;
        };
        selection: {
            material: {
                id: string;
                version: number;
            };
            positionId: string;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
            text: string;
        };
    } | {
        draft: {
            id: string;
            version: number;
        };
        selection: {
            material: {
                id: string;
                version: number;
            };
            positionId: string;
            ranges: {
                role: string;
                range: {
                    paragraphId: string;
                    start: number;
                    end: number;
                };
                text: string;
            }[];
        };
    } | {
        draft: {
            id: string;
            version: number;
        };
        answer: {
            choices: Record<string, string>;
            references: Record<string, string>;
            reason?: {
                text: string;
                independent: boolean;
            } | undefined;
        };
    };
    submitDraft(principal: {
        role: string;
        id: string;
    }, activityId: string, input: unknown): {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    readSubmission(principal: {
        role: string;
        id: string;
    }, activityId: string, submissionId: string): {
        receipt?: import("./kernel/submission-store.ts").StoredSubmission["receipt"];
        confirmation?: import("./contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("./contracts/response.ts").ResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("./contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("./contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("./contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("./contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | {
        receipt: {
            id: string;
            stepAttemptId: string;
            slotId: string;
            confirmedAt: string;
        };
        selection: {
            material: {
                id: string;
                version: number;
            };
            positionId: string;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
            text: string;
        };
    };
    readFragment(principal: {
        role: string;
        id: string;
    }, activityId: string, submissionId: string): {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        ranges: {
            role: string;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
            text: string;
        }[];
    } | {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        range: {
            paragraphId: string;
            start: number;
            end: number;
        };
        text: string;
    };
    readResults(principal: {
        role: string;
        id: string;
    }, activityId: string, resource: "assessment" | "review" | "export"): {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | {
        assessment: {
            status: "pending";
        } | {
            status: "complete";
        } | undefined;
    } | {
        assessment?: never;
        review?: never;
        activityId: string;
        status: string;
        redoOf: string | undefined;
        submissions: {
            receipt?: import("./kernel/submission-store.ts").StoredSubmission["receipt"];
            confirmation?: import("./contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("./contracts/response.ts").ResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("./contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("./contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("./contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("./contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        }[];
    } | {
        assessment: {
            status: "pending";
        } | undefined;
        review?: never;
        activityId: string;
        status: string;
        redoOf: string | undefined;
        submissions: {
            receipt?: import("./kernel/submission-store.ts").StoredSubmission["receipt"];
            confirmation?: import("./contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("./contracts/response.ts").ResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("./contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("./contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("./contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("./contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        }[];
    } | {
        assessment: {
            status: "complete";
        };
        review: {
            byQuestion: {
                questionId: string;
                correct: boolean;
            }[] | undefined;
            selectionFeedback: string | undefined;
        } | undefined;
        activityId: string;
        status: string;
        redoOf: string | undefined;
        submissions: {
            receipt?: import("./kernel/submission-store.ts").StoredSubmission["receipt"];
            confirmation?: import("./contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("./contracts/response.ts").ResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("./contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("./contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("./contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("./contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        }[];
    };
    readPersonalDraft(principal: {
        role: string;
        id: string;
    }, workId: string): {
        draft: {
            id: string;
            version: number;
        };
        content: {
            ranges: {
                paragraphId: string;
                start: number;
                end: number;
                role: string;
            }[];
            choices?: never;
            reason?: never;
            range?: never;
        } | {
            ranges?: never;
            choices: Record<string, string>;
            reason: {
                text: string;
                independent: boolean;
            } | undefined;
            range?: never;
        } | {
            ranges?: never;
            choices?: never;
            reason?: never;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
        };
    };
    readReadingReview(principal: {
        role: string;
        id: string;
    }, activityId: string): {
        activityId: string;
        submissions: ({
            receipt: {
                id: string;
                stepAttemptId: string;
                slotId: string;
                confirmedAt: string;
            };
            selection: {
                material: {
                    id: string;
                    version: number;
                };
                positionId: string;
                ranges: {
                    role: string;
                    range: {
                        paragraphId: string;
                        start: number;
                        end: number;
                    };
                    text: string;
                }[];
            };
            answer?: never;
        } | {
            selection?: never;
            receipt: {
                id: string;
                stepAttemptId: string;
                slotId: string;
                confirmedAt: string;
            };
            answer: {
                choices: Record<string, string>;
                references: Record<string, string>;
                reason?: {
                    text: string;
                    independent: boolean;
                } | undefined;
            };
        })[];
        selectionFeedback: string | null | undefined;
        verdicts?: never;
        automaticVerdicts?: never;
    } | {
        activityId: string;
        submissions: ({
            receipt: {
                id: string;
                stepAttemptId: string;
                slotId: string;
                confirmedAt: string;
            };
            selection: {
                material: {
                    id: string;
                    version: number;
                };
                positionId: string;
                ranges: {
                    role: string;
                    range: {
                        paragraphId: string;
                        start: number;
                        end: number;
                    };
                    text: string;
                }[];
            };
            answer?: never;
        } | {
            selection?: never;
            receipt: {
                id: string;
                stepAttemptId: string;
                slotId: string;
                confirmedAt: string;
            };
            answer: {
                choices: Record<string, string>;
                references: Record<string, string>;
                reason?: {
                    text: string;
                    independent: boolean;
                } | undefined;
            };
        })[];
        selectionFeedback: string | null | undefined;
        verdicts: {
            questionId: string;
            submissionId: string;
            targetId: string;
            revision: number;
            choice: string | undefined;
            prompt: string | undefined;
            effective: {
                source: "teacherReview";
                id: string;
                correct: boolean;
            } | {
                source: "automatic";
                correct: boolean;
            } | undefined;
            automatic: {
                correct: boolean;
                valid: boolean;
            } | undefined;
            history: {
                submissionId: string;
                targetId: string;
                questionId: string;
                id: string;
                revision: number;
                reviewerId: string;
                reason: string;
                reviewedAt: string;
                action: "override" | "withdraw";
                correct: boolean | undefined;
                withdrawId: string | undefined;
            }[] | undefined;
        }[];
        automaticVerdicts: {
            submissionId: string;
            targetId: string;
            questionId: string;
            correct: boolean;
        }[] | undefined;
    };
    writeReadingVerdict(principal: {
        role: string;
        id: string;
    }, activityId: string, command: unknown): {
        submissionId: string;
        targetId: string;
        questionId: string;
        id: string;
        revision: number;
    };
    writeSelectionFeedback(principal: {
        role: string;
        id: string;
    }, activityId: string, input: unknown): {
        selectionFeedback: string;
    };
    readManagement(principal: {
        role: string;
        id: string;
    }, activityId: string): {
        reviewOpen: boolean;
        canToggleReview: boolean;
        reviewerActions: ("commentOnQuotes" | "reviseQuestionVerdict")[];
    };
    manage(principal: {
        role: string;
        id: string;
    }, activityId: string, input: unknown): {
        reviewerActive: boolean;
        studentActive?: never;
        redoAuthorized?: never;
        reviewOpen?: never;
    } | {
        reviewerActive?: never;
        studentActive: boolean;
        redoAuthorized?: never;
        reviewOpen?: never;
    } | {
        reviewerActive?: never;
        studentActive?: never;
        redoAuthorized: boolean;
        reviewOpen?: never;
    } | {
        reviewerActive?: never;
        studentActive?: never;
        redoAuthorized?: never;
        reviewOpen: boolean;
    };
    publish(input: PublicationInput): void;
    start(principal: StudentPrincipal, input: PublishedStartInput): {
        activityId: string;
        stepAttemptId: string;
        startedAt: string;
    };
    prepare(principal: StudentPrincipal, input: PublishedStartInput): {
        activityId: string;
        stepAttemptId: string;
        startedAt: string;
    };
    replacePreparedActivityVersion(principal: StudentPrincipal, activityId: string, input: PreparedActivityVersionInput): PreparedActivityVersionReceipt;
    read(principal: StudentPrincipal, activityId: string): StudentActivity;
    readChoiceDraftActivity(principal: StudentPrincipal, activityId: string): {
        firstChangedAt: string | null;
        lastChangedAt: string | null;
    } | undefined;
    saveChoiceDraft(principal: StudentPrincipal, activityId: string, input: ChoiceDraftInput | UnversionedChoiceDraftInput): Omit<{
        workId: string;
        workVersion: number;
        slotId: string;
        questionId: string;
        revision: number;
        questionVersion: number;
        choice: string;
        changeCount: number;
    }, "workId" | "workVersion">;
    saveCurrentChoiceDraft(principal: StudentPrincipal, activityId: string, input: ChoiceDraftInput | UnversionedChoiceDraftInput, mode?: CurrentChoiceDraftMode): Omit<{
        workId: string;
        workVersion: number;
        slotId: string;
        questionId: string;
        revision: number;
        questionVersion: number;
        choice: string;
        changeCount: number;
    }, "workId" | "workVersion">;
    readChoiceDraftForAmendment(principal: ReviewerPrincipal, activityId: string, scope: ChoiceDraftAmendmentScope): {
        slotId: string;
        questionId: string;
        questionVersion: number;
        choice: string | null;
        revision: number;
        changeCount: number;
    };
    amendChoiceDraft(principal: ReviewerPrincipal, activityId: string, input: ChoiceDraftAmendmentInput): Omit<{
        workId: string;
        workVersion: number;
        slotId: string;
        questionId: string;
        revision: number;
        questionVersion: number;
        choice: string;
        changeCount: number;
    }, "workId" | "workVersion">;
    reviseChoiceSnapshot(principal: ReviewerPrincipal, activityId: string, input: ChoiceSnapshotRevisionInput): {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
        previousQuestionVersion: number;
    };
    confirmChoices(principal: StudentPrincipal, activityId: string, input: ChoiceConfirmationInput): {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    recoverChoiceConfirmation(principal: StudentPrincipal, activityId: string, key: ConfirmationKey): {
        receipt: {
            id: string;
            stepAttemptId: string;
            slotId: string;
            confirmedAt: string;
        };
        practice: {
            id: string;
            version: number;
        };
        confirmation: {
            kind: "choiceConfirmation";
            questions: {
                questionId: string;
                questionVersion: number;
                revision: number;
                original: {
                    state: "frozen";
                    documentId: string;
                    versionId: string;
                    sha256?: string | undefined;
                } | {
                    state: "none";
                } | {
                    state: "missing";
                } | {
                    state: "uncollected";
                };
                choice: string | null;
            }[];
        };
        choiceDraftChangeCounts: {
            questionId: string;
            changeCount: number;
        }[];
        evaluation?: {
            status: "failed" | "pending";
            evaluator: {
                id: string;
                version: number;
            };
            questionCount?: never;
            correctCount?: never;
            questions?: never;
        } | {
            status: "evaluated";
            evaluator: {
                id: string;
                version: number;
            };
            questionCount: number;
            correctCount: number;
            questions: {
                questionId: string;
                questionVersion: number;
                correct: boolean;
            }[];
        };
    };
    saveResponseDraft(principal: StudentPrincipal, activityId: string, input: ResponseDraftInput, mode?: CurrentChoiceDraftMode): Omit<{
        workId: string;
        workVersion: number;
        slotId: string;
        questionId: string;
        questionVersion: number;
        value: z.JSONType;
        revision: number;
        changeCount: number;
    }, "workId" | "workVersion">;
    confirmResponses(principal: StudentPrincipal, activityId: string, input: ResponseConfirmationInput): {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    recoverResponseConfirmation(principal: StudentPrincipal, activityId: string, key: ConfirmationKey): {
        receipt: {
            id: string;
            stepAttemptId: string;
            slotId: string;
            confirmedAt: string;
        };
        practice: {
            id: string;
            version: number;
        };
        confirmation: {
            kind: "responseConfirmation";
            questions: {
                questionId: string;
                questionVersion: number;
                revision: number;
                original: {
                    state: "frozen";
                    documentId: string;
                    versionId: string;
                    sha256?: string | undefined;
                } | {
                    state: "none";
                } | {
                    state: "missing";
                } | {
                    state: "uncollected";
                };
                value: z.JSONType;
            }[];
        };
        responseDraftChangeCounts: {
            questionId: string;
            changeCount: number;
        }[];
        evaluation: {
            questionCount?: never;
            correctCount?: never;
            questions?: never;
            status: "failed" | "pending";
            evaluator: {
                id: string;
                version: number;
            };
            needsReviewCount?: never;
        } | {
            status: "evaluated";
            evaluator: {
                id: string;
                version: number;
            };
            questionCount: number;
            correctCount: number;
            needsReviewCount: number;
            questions: {
                questionId: string;
                questionVersion: number;
                result: {
                    status: "judged";
                    correct: boolean;
                } | {
                    status: "needsReview";
                };
            }[];
        };
    };
    saveQuestionDeliveryDraft(principal: StudentPrincipal, activityId: string, input: QuestionDeliveryDraftInput, mode?: CurrentChoiceDraftMode): {
        questionId: string;
        questionVersion: number;
        value: z.JSONType;
        revision: number;
        changeCount: number;
        slotId: string;
    };
    confirmQuestionDelivery(principal: StudentPrincipal, activityId: string, input: QuestionDeliveryInput): {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    recoverQuestionDelivery: {
        (principal: StudentPrincipal, activityId: string, key: ConfirmationKey, mode: "declared"): DeclaredQuestionDeliveryRecovery;
        (principal: StudentPrincipal, activityId: string, key: ConfirmationKey): AutomaticQuestionDeliveryRecovery;
    };
    readQuestionDeliveryReview: {
        (principal: ReviewerPrincipal, activityId: string, key: ConfirmationKey, mode: "verdicts"): ReturnType<typeof readQuestionDeliveryVerdicts>;
        (principal: ReviewerPrincipal, activityId: string, key: ConfirmationKey, mode: "choiceConfirmation"): ReturnType<typeof readChoiceConfirmationVerdicts>;
        (principal: ReviewerPrincipal, activityId: string, key: ConfirmationKey, mode: "responseConfirmation"): ReturnType<typeof readResponseConfirmationVerdicts>;
        (principal: ReviewerPrincipal, activityId: string, key: ConfirmationKey): ReturnType<typeof readQuestionDeliveryReview>;
    };
    writeQuestionDeliveryVerdict(principal: ReviewerPrincipal, activityId: string, key: ConfirmationKey, command: VerdictCommand, input?: FrozenConfirmationVerdictMode): {
        submissionId: string;
        targetId: string;
        questionId: string;
        id: string;
        revision: number;
    };
    evaluatePending(scope?: {
        submissionId: string;
    }): EvaluationSummary;
    close(): void;
};
