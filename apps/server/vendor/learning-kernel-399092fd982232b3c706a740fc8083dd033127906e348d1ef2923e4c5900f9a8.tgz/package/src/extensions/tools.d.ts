import type { ToolCapability } from "../contracts/capabilities.ts";
export declare const defaultTools: readonly ToolCapability[];
