import type { EvaluatorRegistration } from "../contracts/evaluator.ts";
export declare const choiceKeyEvaluator: EvaluatorRegistration;
