import { z } from "zod";
const choiceKey = z.strictObject({ acceptedChoice: z.string() });
export const choiceKeyEvaluator = {
    id: "choice-key",
    version: 1,
    responseTypes: ["choice"],
    evaluate: ({ value, key }) => ({ status: "judged", correct: value === choiceKey.parse(key).acceptedChoice }),
};
