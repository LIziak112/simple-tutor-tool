export declare const choiceResponse: import("../../contracts/response-type.ts").RegisteredResponseType;
