export declare const optionIndexArrayResponse: import("../../contracts/response-type.ts").RegisteredResponseType;
