export declare const booleanOrStringResponse: import("../../contracts/response-type.ts").RegisteredResponseType;
