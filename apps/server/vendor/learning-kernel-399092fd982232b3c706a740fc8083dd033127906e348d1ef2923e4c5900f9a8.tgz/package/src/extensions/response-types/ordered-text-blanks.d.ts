export declare const orderedTextBlanksResponse: import("../../contracts/response-type.ts").RegisteredResponseType;
