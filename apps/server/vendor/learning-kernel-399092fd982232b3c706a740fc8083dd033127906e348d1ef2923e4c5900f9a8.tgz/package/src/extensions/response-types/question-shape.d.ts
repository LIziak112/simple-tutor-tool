import type { QuestionDefinition, QuestionIssue } from "../../contracts/response-type.ts";
export declare function requireOptions(question: QuestionDefinition, issue: QuestionIssue): void;
export declare function rejectOptions(question: QuestionDefinition, issue: QuestionIssue): void;
