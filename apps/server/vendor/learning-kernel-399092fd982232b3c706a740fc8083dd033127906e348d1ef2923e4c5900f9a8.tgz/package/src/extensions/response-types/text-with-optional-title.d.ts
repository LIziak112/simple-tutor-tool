export declare const textWithOptionalTitleResponse: import("../../contracts/response-type.ts").RegisteredResponseType;
