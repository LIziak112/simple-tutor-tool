import type { DatabaseSync } from "node:sqlite";
import type { Registry } from "./registry.ts";
export declare function registerPublication(database: DatabaseSync, input: unknown, registry: Registry): void;
