import { z } from "zod";
import { loadStudentReadingActivity } from "./activity.js";
import { LearningError } from "../contracts/learning-error.js";
const amendmentActor = z.strictObject({ studentId: z.string(), assignedReviewer: z.string().nullable(), reviewerActive: z.literal([0, 1]).nullable() });
export function requireChoiceReviewerActivity(database, reviewerId, activityId, question, authorize) {
    const row = database.prepare(`
    SELECT a.student_id AS studentId, r.reviewer_id AS assignedReviewer, r.reviewer_active AS reviewerActive
    FROM activities a LEFT JOIN reading_reviews r ON r.activity_id = a.id WHERE a.id = ?
  `).get(activityId);
    if (!row)
        throw new LearningError(403, "FORBIDDEN");
    const { studentId, assignedReviewer, reviewerActive } = amendmentActor.parse(row);
    if (assignedReviewer !== null && (assignedReviewer !== reviewerId || reviewerActive !== 1))
        throw new LearningError(403, "FORBIDDEN");
    const { stepAttemptId, slotId, questionId, questionVersion } = question;
    const activity = loadStudentReadingActivity(database, studentId, activityId, stepAttemptId);
    const scope = { reviewerId, studentId, activityId, stepAttemptId, slotId, questionId, questionVersion };
    if (authorize(scope) !== true)
        throw new LearningError(403, "FORBIDDEN");
    return { activity, scope };
}
