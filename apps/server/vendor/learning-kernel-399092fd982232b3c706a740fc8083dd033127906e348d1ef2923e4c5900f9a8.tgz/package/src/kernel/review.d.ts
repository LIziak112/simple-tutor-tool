import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { VerdictCommand } from "../contracts/verdict.ts";
export declare const selectionFeedbackInput: z.ZodObject<{
    protocolVersion: z.ZodLiteral<1>;
    text: z.ZodString;
}, z.core.$strict>;
export declare function readReview(database: DatabaseSync, reviewer: string, activityId: string): {
    activityId: string;
    submissions: ({
        receipt: {
            id: string;
            stepAttemptId: string;
            slotId: string;
            confirmedAt: string;
        };
        selection: {
            material: {
                id: string;
                version: number;
            };
            positionId: string;
            ranges: {
                role: string;
                range: {
                    paragraphId: string;
                    start: number;
                    end: number;
                };
                text: string;
            }[];
        };
        answer?: never;
    } | {
        selection?: never;
        receipt: {
            id: string;
            stepAttemptId: string;
            slotId: string;
            confirmedAt: string;
        };
        answer: {
            choices: Record<string, string>;
            references: Record<string, string>;
            reason?: {
                text: string;
                independent: boolean;
            } | undefined;
        };
    })[];
    selectionFeedback: string | null | undefined;
    verdicts?: never;
    automaticVerdicts?: never;
} | {
    activityId: string;
    submissions: ({
        receipt: {
            id: string;
            stepAttemptId: string;
            slotId: string;
            confirmedAt: string;
        };
        selection: {
            material: {
                id: string;
                version: number;
            };
            positionId: string;
            ranges: {
                role: string;
                range: {
                    paragraphId: string;
                    start: number;
                    end: number;
                };
                text: string;
            }[];
        };
        answer?: never;
    } | {
        selection?: never;
        receipt: {
            id: string;
            stepAttemptId: string;
            slotId: string;
            confirmedAt: string;
        };
        answer: {
            choices: Record<string, string>;
            references: Record<string, string>;
            reason?: {
                text: string;
                independent: boolean;
            } | undefined;
        };
    })[];
    selectionFeedback: string | null | undefined;
    verdicts: {
        questionId: string;
        submissionId: string;
        targetId: string;
        revision: number;
        choice: string | undefined;
        prompt: string | undefined;
        effective: {
            source: "teacherReview";
            id: string;
            correct: boolean;
        } | {
            source: "automatic";
            correct: boolean;
        } | undefined;
        automatic: {
            correct: boolean;
            valid: boolean;
        } | undefined;
        history: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[] | undefined;
    }[];
    automaticVerdicts: {
        submissionId: string;
        targetId: string;
        questionId: string;
        correct: boolean;
    }[] | undefined;
};
export declare function writeVerdict(database: DatabaseSync, reviewer: string, activityId: string, command: VerdictCommand, clock: () => Date): {
    submissionId: string;
    targetId: string;
    questionId: string;
    id: string;
    revision: number;
};
export declare function writeSelectionFeedback(database: DatabaseSync, reviewer: string, activityId: string, text: string): {
    selectionFeedback: string;
};
