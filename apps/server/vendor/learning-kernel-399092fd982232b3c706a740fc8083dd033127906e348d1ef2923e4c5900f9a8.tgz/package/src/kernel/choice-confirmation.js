import { readChoiceConfirmation } from "../contracts/choice-confirmation.js";
import { loadStudentReadingActivity } from "./activity.js";
import { ChoiceDraftConflict, readChoiceDrafts } from "./choice-drafts.js";
import { readChoiceEvaluation } from "./choice-evaluation.js";
import { readTransaction, writeTransaction } from "./database.js";
import { LearningError } from "../contracts/learning-error.js";
import { requireBeforeDeadline, writableOutput } from "./reading-progress.js";
import { confirmedDraftChangeCount, confirmedWorkForOperation, mapConfirmationQuestions, replayQuestionConfirmation, requireConfirmationRecovery, writeQuestionConfirmation, } from "./question-confirmation.js";
export class ChoiceConfirmationConflict extends ChoiceDraftConflict {
    questionId;
    constructor(questionId, current) {
        super(current);
        this.questionId = questionId;
    }
}
export function confirmChoices(database, registry, studentId, activityId, input, clock, verifyOriginal) {
    return writeTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, input.stepAttemptId);
        const previous = confirmationForOperation(database, activityId, input);
        if (previous) {
            const intent = previous.confirmation?.questions.map(({ choice, ...revision }) => revision);
            return replayQuestionConfirmation(previous.receipt, intent, input);
        }
        const slot = requireConfirmationSlot(registry, activity, input.slotId);
        const now = clock();
        requireBeforeDeadline(activity, now);
        const questions = freezeAnswers(database, activity, input, slot.confirmFromDrafts.allowUnanswered);
        const answeredQuestionIds = new Set(questions.filter(({ choice }) => choice !== null).map(({ questionId }) => questionId));
        return writeQuestionConfirmation(database, activity, studentId, input, slot.targetId, { kind: "choiceConfirmation", questions }, now, verifyOriginal, { answeredQuestionIds });
    });
}
export function recoverChoiceConfirmation(database, studentId, activityId, key, authorize) {
    return readTransaction(database, () => {
        const activity = loadStudentReadingActivity(database, studentId, activityId, key.stepAttemptId);
        requireConfirmationRecovery({ studentId, activityId, stepAttemptId: key.stepAttemptId, operationId: key.operationId }, authorize);
        const recovered = confirmationForOperation(database, activityId, key);
        if (!recovered?.confirmation)
            throw new LearningError(404, "CONFIRMATION_NOT_FOUND");
        const { receipt, confirmation } = recovered;
        const { id, version } = activity.practice;
        const evaluation = readChoiceEvaluation(database, activity, receipt, confirmation);
        const drafts = draftsByQuestion(database, activityId, receipt);
        const choiceDraftChangeCounts = confirmation.questions.map(question => ({
            questionId: question.questionId, changeCount: confirmedDraftChangeCount(question, drafts.get(question.questionId), "choice"),
        }));
        return { receipt, practice: { id, version }, confirmation, choiceDraftChangeCounts, ...(evaluation ? { evaluation } : {}) };
    });
}
function requireConfirmationSlot(registry, activity, slotId) {
    if (activity.completed)
        throw new LearningError(409, "ALREADY_SUBMITTED");
    const slot = writableOutput(registry, activity.step, slotId);
    if (slot.type !== "oneChoicePerQuestion" || !slot.confirmFromDrafts)
        throw new LearningError(422, "INVALID_SLOT");
    return { targetId: slot.targetId, confirmFromDrafts: slot.confirmFromDrafts };
}
function freezeAnswers(database, activity, input, allowUnanswered) {
    const heads = confirmationHeads(database, activity, input);
    return mapConfirmationQuestions(activity, input.questions, requested => {
        const current = heads.get(requested.questionId) ?? { revision: 0, choice: null };
        if (requested.revision !== current.revision) {
            throw new ChoiceConfirmationConflict(requested.questionId, { revision: current.revision, choice: current.choice });
        }
        if (current.choice === null && !allowUnanswered)
            throw new LearningError(422, "UNANSWERED_QUESTION");
        return { ...requested, choice: current.choice };
    });
}
function confirmationHeads(database, activity, input) {
    const heads = new Map();
    for (const { slotId, questionId, revision } of activity.choiceSnapshotRevisions) {
        if (slotId === input.slotId)
            heads.set(questionId, { revision, choice: null });
    }
    for (const [questionId, draft] of draftsByQuestion(database, activity.activityId, input)) {
        heads.set(questionId, draft);
    }
    return heads;
}
function draftsByQuestion(database, activityId, { stepAttemptId, slotId }) {
    return new Map(readChoiceDrafts(database, activityId, stepAttemptId)
        .filter(draft => draft.slotId === slotId).map(draft => [draft.questionId, draft]));
}
function confirmationForOperation(database, activityId, input) {
    const previous = confirmedWorkForOperation(database, activityId, input);
    return previous && { receipt: previous.receipt, confirmation: readChoiceConfirmation(previous.content) };
}
