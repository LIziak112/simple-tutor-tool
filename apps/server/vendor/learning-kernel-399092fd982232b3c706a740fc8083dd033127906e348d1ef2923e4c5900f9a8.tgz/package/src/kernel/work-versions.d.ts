import type { DatabaseSync } from "node:sqlite";
export type WorkScope = {
    activityId: string;
    step?: {
        id: string;
        slotId: string;
        questionId?: string;
    };
};
export declare function saveWorkVersion(database: DatabaseSync, scope: WorkScope, content: unknown, workId?: string): {
    id: string;
    version: number;
};
export declare function loadWorkVersion(database: DatabaseSync, scope: WorkScope, draft: {
    id: string;
    version: number;
}): unknown;
export declare function readPersonalDraft(database: DatabaseSync, student: string, workId: string): {
    draft: {
        id: string;
        version: number;
    };
    content: {
        ranges: {
            paragraphId: string;
            start: number;
            end: number;
            role: string;
        }[];
        choices?: never;
        reason?: never;
        range?: never;
    } | {
        ranges?: never;
        choices: Record<string, string>;
        reason: {
            text: string;
            independent: boolean;
        } | undefined;
        range?: never;
    } | {
        ranges?: never;
        choices?: never;
        reason?: never;
        range: {
            paragraphId: string;
            start: number;
            end: number;
        };
    };
};
