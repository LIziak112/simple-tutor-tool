import type { DatabaseSync } from "node:sqlite";
import type { AuthorizeConfirmationRecovery, ChoiceConfirmationInput, ConfirmationKey, VerifyOriginal } from "../contracts/choice-confirmation.ts";
import { ChoiceDraftConflict } from "./choice-drafts.ts";
import type { Registry } from "./registry.ts";
export declare class ChoiceConfirmationConflict extends ChoiceDraftConflict {
    readonly questionId: string;
    constructor(questionId: string, current: ChoiceDraftConflict["current"]);
}
export declare function confirmChoices(database: DatabaseSync, registry: Registry, studentId: string, activityId: string, input: ChoiceConfirmationInput, clock: () => Date, verifyOriginal?: VerifyOriginal): {
    id: string;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export declare function recoverChoiceConfirmation(database: DatabaseSync, studentId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeConfirmationRecovery | undefined): {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        kind: "choiceConfirmation";
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            choice: string | null;
        }[];
    };
    choiceDraftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
    evaluation?: {
        status: "failed" | "pending";
        evaluator: {
            id: string;
            version: number;
        };
        questionCount?: never;
        correctCount?: never;
        questions?: never;
    } | {
        status: "evaluated";
        evaluator: {
            id: string;
            version: number;
        };
        questionCount: number;
        correctCount: number;
        questions: {
            questionId: string;
            questionVersion: number;
            correct: boolean;
        }[];
    };
};
