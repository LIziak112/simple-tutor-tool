import { z } from "zod";
import { choiceSnapshotOffsetForWork } from "./choice-snapshot-store.js";
import { LearningError } from "../contracts/learning-error.js";
export class QuestionDraftConflict extends LearningError {
    current;
    constructor(current, code = "ANSWER_REVISION_CONFLICT") {
        super(409, code);
        this.current = current;
    }
}
const storedVersion = z.object({
    workId: z.uuid(), slotId: z.string(), questionId: z.string(), workVersion: z.int().positive(),
    revision: z.int().positive(), changeCount: z.int().nonnegative(), content: z.string(),
});
const storedOperation = storedVersion.extend({ baseRevision: z.int().nonnegative() });
const versionColumns = `
  w.id AS workId, w.slot_id AS slotId, w.question_id AS questionId, v.version AS workVersion, v.selection AS content,
  v.version + ${choiceSnapshotOffsetForWork} AS revision,
  v.version - (SELECT COUNT(*) FROM choice_draft_amendments a WHERE a.work_id = w.id AND a.revision <= v.version) AS changeCount
`;
const currentDrafts = `
  SELECT ${versionColumns}
  FROM works w JOIN work_versions v ON v.work_id = w.id
    AND v.version = (SELECT MAX(version) FROM work_versions WHERE work_id = w.id)
  WHERE w.activity_id = ? AND w.step_attempt_id = ? AND w.question_id IS NOT NULL
`;
function decodeDraft({ content, ...version }, value) {
    return { ...version, ...value.parse(JSON.parse(content)) };
}
export function publicDraft({ workId, workVersion, ...draft }) {
    return draft;
}
export function readQuestionDrafts(database, activityId, stepAttemptId, schema) {
    return database.prepare(currentDrafts + "ORDER BY w.slot_id, w.question_id").all(activityId, stepAttemptId)
        .map(row => publicDraft(decodeDraft(storedVersion.parse(row), schema)));
}
export function readQuestionDraftHead(database, activityId, { stepAttemptId, slotId, questionId }, schema) {
    const row = database.prepare(currentDrafts + "AND w.slot_id = ? AND w.question_id = ?")
        .get(activityId, stepAttemptId, slotId, questionId);
    return row && decodeDraft(storedVersion.parse(row), schema);
}
export function readQuestionDraftRevision(database, workId, revision, schema) {
    const row = database.prepare(`
    SELECT ${versionColumns} FROM works w JOIN work_versions v ON v.work_id = w.id
    WHERE w.id = ? AND v.version = ?
  `).get(workId, revision);
    return decodeDraft(storedVersion.parse(row), schema);
}
export function readQuestionDraftOperation(database, activityId, scope, schema) {
    const row = database.prepare(`
    SELECT ${versionColumns}, o.base_revision AS baseRevision
    FROM choice_draft_operations o
    JOIN works w ON w.id = o.work_id
    JOIN work_versions v ON v.work_id = o.work_id AND v.version = o.revision
    WHERE w.activity_id = ? AND w.step_attempt_id = ? AND w.slot_id = ? AND w.question_id = ? AND o.operation_id = ?
  `).get(activityId, scope.stepAttemptId, scope.slotId, scope.questionId, scope.operationId);
    if (!row)
        return undefined;
    const { baseRevision, ...stored } = storedOperation.parse(row);
    return { baseRevision, draft: decodeDraft(stored, schema) };
}
export function isLatestQuestionDraftOperation(database, workId, operationId) {
    return Boolean(database.prepare(`
    SELECT 1 FROM choice_draft_latest_operations WHERE work_id = ? AND operation_id = ?
  `).get(workId, operationId));
}
export function rememberQuestionDraftOperation(database, input, { workId, workVersion }) {
    database.prepare(`
    INSERT INTO choice_draft_operations (work_id, operation_id, base_revision, revision)
    VALUES (?, ?, ?, ?) ON CONFLICT (work_id, operation_id) DO NOTHING
  `).run(workId, input.operationId, input.baseRevision, workVersion);
    database.prepare(`
    INSERT INTO choice_draft_latest_operations (work_id, operation_id) VALUES (?, ?)
    ON CONFLICT (work_id) DO UPDATE SET operation_id = excluded.operation_id
  `).run(workId, input.operationId);
}
