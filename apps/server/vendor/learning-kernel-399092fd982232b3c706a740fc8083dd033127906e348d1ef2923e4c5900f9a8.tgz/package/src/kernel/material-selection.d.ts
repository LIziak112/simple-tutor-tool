import type { Material, SaveInput, Step } from "../contracts/reading.ts";
export declare function selectedText(material: Material, range: SaveInput["range"]): string;
export declare function selectText(material: Material, step: Step, range: SaveInput["range"]): {
    material: {
        id: string;
        version: number;
    };
    positionId: string;
    range: {
        paragraphId: string;
        start: number;
        end: number;
    };
    text: string;
};
