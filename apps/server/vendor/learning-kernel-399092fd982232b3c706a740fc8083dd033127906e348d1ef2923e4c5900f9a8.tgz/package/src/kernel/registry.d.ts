import type { ToolCapability } from "../contracts/capabilities.ts";
import type { EvaluatorRegistration, QuestionAnswerRule } from "../contracts/evaluator.ts";
import type { VersionRef } from "../contracts/reading.ts";
import type { RegisteredResponseType } from "../contracts/response-type.ts";
export type Extensions = Readonly<{
    tools: readonly ToolCapability[];
    responseTypes: readonly RegisteredResponseType[];
    evaluators: readonly EvaluatorRegistration[];
    answerRules: readonly QuestionAnswerRule[];
}>;
export type Registry = Readonly<{
    tool(reference: VersionRef): ToolCapability | undefined;
    responseType(id: string): RegisteredResponseType | undefined;
    requireResponseType(id: string): RegisteredResponseType;
    evaluator(reference: VersionRef): EvaluatorRegistration | undefined;
    answerRule(reference: VersionRef, responseType: string): QuestionAnswerRule | undefined;
}>;
export declare function createRegistry({ tools, responseTypes, evaluators, answerRules }: Extensions): Registry;
