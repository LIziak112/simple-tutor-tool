import type { DatabaseSync } from "node:sqlite";
import type { Material, VersionRef } from "../contracts/reading.ts";
import type { ReadingPublication } from "../contracts/reading-publication.ts";
import type { Registry } from "./registry.ts";
type Issue = (path: (string | number)[], message: string) => void;
export declare function validateMaterialPositions({ material, materials, practice }: ReadingPublication, registry: Registry, issue: Issue): void;
export declare function loadMaterialAtVersion(database: DatabaseSync, { id, version }: VersionRef): Material;
export {};
