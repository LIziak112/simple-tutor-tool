import type { DatabaseSync } from "node:sqlite";
import type { CurrentChoiceDraftMode } from "../contracts/choice-draft.ts";
import { LearningError } from "../contracts/learning-error.ts";
import type { ResponseDraftInput, ResponseDraftRequest, ResponseValue } from "../contracts/response.ts";
import type { ReadingActivity } from "./activity.ts";
import { QuestionDraftConflict } from "./question-draft-store.ts";
import type { Registry } from "./registry.ts";
type DraftState = {
    revision: number;
    value: ResponseValue | null;
};
export declare class ResponseDraftConflict extends QuestionDraftConflict<DraftState> {
    readonly questionId: string | undefined;
    constructor(current: DraftState, code?: "ANSWER_REVISION_CONFLICT" | "OPERATION_CONFLICT", questionId?: string);
}
type DraftConflict = new (current: DraftState, code?: "ANSWER_REVISION_CONFLICT" | "OPERATION_CONFLICT") => LearningError;
export declare function responseSlot(registry: Registry, activity: ReadingActivity, slotId: string): {
    source: string;
    targetId: string;
    type: "oneResponsePerQuestion";
    input: string;
    confirmFromDrafts: {
        allowUnanswered: boolean;
    };
};
export declare function readResponseDrafts(database: DatabaseSync, activityId: string, stepAttemptId: string): Omit<{
    workId: string;
    slotId: string;
    questionId: string;
    workVersion: number;
    revision: number;
    changeCount: number;
} & {
    questionVersion: number;
    value: import("zod").JSONType;
}, "workId" | "workVersion">[];
export declare function saveResponseDraft(database: DatabaseSync, registry: Registry, studentId: string, activityId: string, input: ResponseDraftRequest, mode: CurrentChoiceDraftMode, clock: () => Date): Omit<{
    workId: string;
    workVersion: number;
    slotId: string;
    questionId: string;
    questionVersion: number;
    value: import("zod").JSONType;
    revision: number;
    changeCount: number;
}, "workId" | "workVersion">;
export declare function saveCurrentResponse(database: DatabaseSync, activityId: string, input: ResponseDraftInput, mode: CurrentChoiceDraftMode, clock: () => Date, Conflict: DraftConflict): Omit<{
    workId: string;
    workVersion: number;
    slotId: string;
    questionId: string;
    questionVersion: number;
    value: import("zod").JSONType;
    revision: number;
    changeCount: number;
}, "workId" | "workVersion">;
export {};
