import type { ReadingPublication, ReadingSlot, ReadingStep } from "../contracts/reading-publication.ts";
import type { Registry } from "./registry.ts";
type Issue = (path: (string | number)[], message: string) => void;
export type DeliverySlot = Extract<ReadingSlot, {
    type: "questionDelivery";
}>;
export declare function questionDeliverySlot(step: ReadingStep): [string, {
    source: string;
    targetId: string;
    type: "questionDelivery";
    delivery: {
        mode: "whole";
    } | {
        mode: "perQuestion";
        questionSlots: {
            [k: string]: string;
        };
    };
    confirmFromDrafts: {
        allowUnanswered: boolean;
    };
}] | undefined;
export declare function validateQuestionDeliveryPublication(publication: ReadingPublication, registry: Registry, issue: Issue): boolean;
export {};
