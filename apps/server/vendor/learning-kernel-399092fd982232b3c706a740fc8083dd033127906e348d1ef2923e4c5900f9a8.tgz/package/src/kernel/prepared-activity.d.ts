import type { DatabaseSync } from "node:sqlite";
import type { PreparedActivityVersionInput } from "../contracts/prepared-activity.ts";
export declare function replacePreparedActivityVersion(database: DatabaseSync, student: string, activityId: string, input: PreparedActivityVersionInput): {
    activityId: string;
    startedAt: string;
    stepAttemptId: string;
    practiceVersion: number;
};
