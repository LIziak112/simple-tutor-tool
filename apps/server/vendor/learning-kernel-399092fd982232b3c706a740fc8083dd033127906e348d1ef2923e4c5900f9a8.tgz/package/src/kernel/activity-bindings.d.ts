import type { ActivityBindingClaims } from "../contracts/activity-bindings.ts";
export declare function verifyActivityBindings(databasePath: string, input: ActivityBindingClaims): void;
