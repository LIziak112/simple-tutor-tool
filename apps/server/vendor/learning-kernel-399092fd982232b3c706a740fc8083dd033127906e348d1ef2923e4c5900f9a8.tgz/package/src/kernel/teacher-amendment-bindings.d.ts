import type { DatabaseSync } from "node:sqlite";
import type { TeacherAmendmentBindingClaims } from "../contracts/activity-bindings.ts";
export declare function verifyTeacherAmendmentBindings(database: DatabaseSync, claims: TeacherAmendmentBindingClaims): void;
