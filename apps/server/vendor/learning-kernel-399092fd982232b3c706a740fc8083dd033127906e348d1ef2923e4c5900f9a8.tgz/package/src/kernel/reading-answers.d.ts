import type { DatabaseSync } from "node:sqlite";
import type { ReadingSlot, ReadingStep } from "../contracts/reading-publication.ts";
import type { ReadingAnswer } from "../contracts/reading-runtime.ts";
import type { ReadingActivity } from "./activity.ts";
import type { Observation, StoredSubmission } from "./submission-store.ts";
export declare function findSource(submissions: readonly StoredSubmission[], input: {
    stepId: string;
    slotId: string;
}): {
    stepId: string;
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    content: unknown;
} | undefined;
export declare function verifyAnswerReferences(database: DatabaseSync, activityId: string, step: ReadingStep, answer: ReadingAnswer): void;
export declare function answerObservations(activity: ReadingActivity, slot: Extract<ReadingSlot, {
    type: "oneChoicePerQuestion";
}>, answer: ReadingAnswer): Observation[];
