import { randomUUID } from "node:crypto";
import { z } from "zod";
import { readQuestionDelivery } from "../contracts/question-delivery.js";
import { readChoiceConfirmation } from "../contracts/choice-confirmation.js";
import { readResponseConfirmation } from "../contracts/response.js";
import { selectionSchema } from "../contracts/reading.js";
import { readingAnswer, readingSelection } from "../contracts/reading-runtime.js";
import { LearningError } from "../contracts/learning-error.js";
const latestDraft = z.object({ latest: z.int() });
export function saveWorkVersion(database, scope, content, workId) {
    const fresh = workId === undefined;
    const id = fresh ? randomUUID() : workId;
    const version = nextVersion(database, scope, id, fresh);
    database.prepare("INSERT INTO work_versions (work_id, version, selection) VALUES (?, ?, ?)")
        .run(id, version, JSON.stringify(content));
    return { id, version };
}
function nextVersion(database, scope, id, fresh) {
    if (fresh) {
        database.prepare("INSERT INTO works (id, activity_id, step_attempt_id, slot_id, question_id) VALUES (?, ?, ?, ?, ?)")
            .run(id, ...scopeValues(scope));
        return 1;
    }
    requireWorkScope(database, scope, id);
    const row = database.prepare("SELECT MAX(version) AS latest FROM work_versions WHERE work_id = ?").get(id);
    const { latest } = latestDraft.parse(row);
    return latest + 1;
}
export function loadWorkVersion(database, scope, draft) {
    requireWorkScope(database, scope, draft.id);
    const row = database.prepare("SELECT selection FROM work_versions WHERE work_id = ? AND version = ?")
        .get(draft.id, draft.version);
    if (!row)
        throw new LearningError(403, "FORBIDDEN");
    return JSON.parse(String(row.selection));
}
export function readPersonalDraft(database, student, workId) {
    const row = database.prepare(`
    SELECT v.version, v.selection FROM works w
    JOIN activities a ON a.id = w.activity_id JOIN work_versions v ON v.work_id = w.id
    WHERE w.id = ? AND a.student_id = ? AND w.question_id IS NULL ORDER BY v.version DESC LIMIT 1
  `).get(workId, student);
    if (!row)
        throw new LearningError(403, "FORBIDDEN");
    const stored = z.object({ version: z.int().positive(), selection: z.string() }).parse(row);
    const content = JSON.parse(stored.selection);
    if (readChoiceConfirmation(content) || readResponseConfirmation(content) || readQuestionDelivery(content)) {
        throw new LearningError(403, "FORBIDDEN");
    }
    return { draft: { id: workId, version: stored.version }, content: authorInput(content) };
}
function authorInput(content) {
    const multiple = readingSelection.safeParse(content);
    if (multiple.success)
        return { ranges: multiple.data.ranges.map(item => ({ role: item.role, ...item.range })) };
    const answer = readingAnswer.safeParse(content);
    if (answer.success)
        return { choices: answer.data.choices, reason: answer.data.reason };
    return { range: selectionSchema.parse(content).range };
}
function requireWorkScope(database, scope, id) {
    const work = database.prepare(`
    SELECT 1 FROM works WHERE id = ? AND activity_id = ? AND step_attempt_id IS ? AND slot_id IS ? AND question_id IS ?
  `).get(id, ...scopeValues(scope));
    if (!work)
        throw new LearningError(403, "FORBIDDEN");
}
function scopeValues({ activityId, step }) {
    return [activityId, step?.id ?? null, step?.slotId ?? null, step?.questionId ?? null];
}
