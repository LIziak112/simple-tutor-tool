import type { DatabaseSync } from "node:sqlite";
import type { SubmissionReceipt } from "../contracts/reading.ts";
import type { ResponseConfirmation } from "../contracts/response.ts";
import type { ReadingActivity } from "./activity.ts";
import { assessmentTarget } from "./verdict-state.ts";
export declare function readResponseEvaluation(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, confirmation: ResponseConfirmation): {
    status: "failed" | "pending";
    evaluator: {
        id: string;
        version: number;
    };
    questionCount?: never;
    correctCount?: never;
    needsReviewCount?: never;
    questions?: never;
} | {
    status: "evaluated";
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    needsReviewCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        result: {
            status: "judged";
            correct: boolean;
        } | {
            status: "needsReview";
        };
    }[];
};
export declare function readEvaluatedResponses(database: DatabaseSync, activity: ReadingActivity, receipt: SubmissionReceipt, confirmed: readonly {
    questionId: string;
    questionVersion: number;
}[], target: ReturnType<typeof assessmentTarget>): {
    status: "failed" | "pending";
    evaluator: {
        id: string;
        version: number;
    };
    questionCount?: never;
    correctCount?: never;
    needsReviewCount?: never;
    questions?: never;
} | {
    status: "evaluated";
    evaluator: {
        id: string;
        version: number;
    };
    questionCount: number;
    correctCount: number;
    needsReviewCount: number;
    questions: {
        questionId: string;
        questionVersion: number;
        result: {
            status: "judged";
            correct: boolean;
        } | {
            status: "needsReview";
        };
    }[];
};
export declare function recordResponseReviewRequirements(database: DatabaseSync, submissionId: string, questionIds: readonly string[]): void;
export declare function readResponseReviewRequirements(database: DatabaseSync, submissionId: string): string[];
