import { z } from "zod";
import { assessmentTarget, readAutomaticVerdicts } from "./verdict-state.js";
const verdict = z.boolean();
export function readChoiceEvaluation(database, activity, receipt, confirmation) {
    const assessment = activity.practice.grading.assessment;
    if (!assessment)
        return undefined;
    const target = assessmentTarget(database, activity.activityId);
    if (target?.submissionId !== receipt.id)
        throw new Error("已确认的评分任务不存在");
    const evaluator = assessment.evaluator;
    if (target.status !== "done")
        return { status: target.status, evaluator };
    const automatic = new Map(readAutomaticVerdicts(database, target).map(({ questionId, correct }) => [questionId, correct]));
    const questions = confirmation.questions.map(({ questionId, questionVersion }) => ({
        questionId, questionVersion, correct: verdict.parse(automatic.get(questionId)),
    }));
    return {
        status: "evaluated", evaluator, questionCount: questions.length,
        correctCount: questions.filter(question => question.correct).length, questions,
    };
}
