import { z } from "zod";
import { loadStudentActivity } from "./activity.js";
import { writeTransaction } from "./database.js";
const changeTimes = z.strictObject({
    firstChangedAt: z.iso.datetime().nullable(),
    lastChangedAt: z.iso.datetime().nullable(),
});
const storedActivity = changeTimes.extend({ hasDraft: z.literal([0, 1]) });
const hasStudentChoiceDraft = `EXISTS (
  SELECT 1 FROM step_attempts s JOIN works w ON w.step_attempt_id = s.id AND w.question_id IS NOT NULL
  JOIN work_versions v ON v.work_id = w.id
  WHERE s.activity_id = activities.id AND w.activity_id = activities.id
    AND NOT EXISTS (SELECT 1 FROM choice_draft_amendments a WHERE a.work_id = w.id AND a.revision = v.version)
)`;
export function readChoiceDraftActivity(database, student, activityId) {
    return writeTransaction(database, () => {
        loadStudentActivity(database, student, activityId);
        const { hasDraft, ...times } = storedActivity.parse(database.prepare(`
      SELECT first_choice_changed_at AS firstChangedAt, last_choice_changed_at AS lastChangedAt, ${hasStudentChoiceDraft} AS hasDraft
      FROM activities WHERE id = ?
    `).get(activityId));
        return hasDraft ? times : undefined;
    });
}
export function recordChoiceDraftChange(database, activityId, changedAt) {
    const timestamp = changedAt.toISOString();
    database.prepare(`
    UPDATE activities
    SET first_choice_changed_at = CASE WHEN ${hasStudentChoiceDraft} THEN first_choice_changed_at ELSE ? END,
        last_choice_changed_at = ?
    WHERE id = ?
  `).run(timestamp, timestamp, activityId);
}
