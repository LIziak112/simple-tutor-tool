import { reviewDisclosure } from "./review-access.js";
import { assessmentTarget, questionVerdicts } from "./verdict-state.js";
export function studentResults(database, activity) {
    const policy = activity.practice.policy.student;
    const target = assessmentTarget(database, activity.activityId);
    if (!target || !policy.passageScore)
        return {};
    const pending = policy.ownSubmission.onFinal.includes("passageGradingStatus") ? { status: "pending" } : undefined;
    if (target.status !== "done")
        return { assessment: pending };
    const graded = questionVerdicts(database, activity, target).flatMap(({ questionId, effective }) => effective ? [{ questionId, correct: effective.correct }] : []);
    if (graded.length !== activity.practice.questions.length)
        return { assessment: pending };
    const result = { questionCount: graded.length, correctCount: graded.filter(item => item.correct).length };
    const fields = Object.fromEntries(policy.passageScore.fields.map(field => [field, result[field]]));
    return {
        assessment: { status: "complete", ...fields },
        review: policy.review && studentReview(database, activity.activityId, policy.review, graded),
    };
}
function studentReview(database, activityId, policy, graded) {
    const disclosure = reviewDisclosure(database, activityId);
    if (!disclosure?.reviewOpen)
        return undefined;
    const byQuestion = policy.byQuestion.includes("effectiveVerdict") ? graded : undefined;
    const selectionFeedback = policy.byQuoteSet.includes("learnerFeedback") ? disclosure.feedback ?? undefined : undefined;
    if (!byQuestion && !selectionFeedback)
        return undefined;
    return { byQuestion, selectionFeedback };
}
