import { LearningError } from "../contracts/learning-error.js";
const identity = ({ id, version }) => JSON.stringify([id, version]);
function unique(entries, key, label) {
    const indexed = new Map();
    for (const entry of entries) {
        const name = key(entry);
        if (indexed.has(name))
            throw new Error(`${label}重复登记：${name}`);
        indexed.set(name, entry);
    }
    return indexed;
}
export function createRegistry({ tools, responseTypes, evaluators, answerRules }) {
    const toolIndex = unique(tools, identity, "工具");
    const typeIndex = unique(responseTypes, ({ id }) => id, "作答形态");
    const evaluatorIndex = unique(evaluators, identity, "评估器");
    const ruleIndex = unique(answerRules, identity, "已答规则");
    for (const { id, responseTypes: covered } of evaluators) {
        const missing = covered.find(type => !typeIndex.has(type));
        if (missing !== undefined)
            throw new Error(`评估器 ${id} 引用了未登记的作答形态：${missing}`);
    }
    for (const { id, responseType } of answerRules) {
        if (!typeIndex.has(responseType))
            throw new Error(`已答规则 ${id} 引用了未登记的作答形态：${responseType}`);
    }
    return {
        tool: reference => toolIndex.get(identity(reference)),
        responseType: id => typeIndex.get(id),
        requireResponseType(id) {
            const type = typeIndex.get(id);
            if (!type)
                throw new LearningError(503, "RESPONSE_TYPE_UNAVAILABLE");
            return type;
        },
        evaluator: reference => evaluatorIndex.get(identity(reference)),
        answerRule(reference, responseType) {
            const rule = ruleIndex.get(identity(reference));
            return rule?.responseType === responseType ? rule : undefined;
        },
    };
}
