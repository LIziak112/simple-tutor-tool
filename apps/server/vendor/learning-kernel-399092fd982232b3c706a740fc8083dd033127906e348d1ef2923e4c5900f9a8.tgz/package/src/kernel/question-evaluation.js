import { verdictResult } from "../contracts/evaluator.js";
import { LearningError } from "../contracts/learning-error.js";
import { frozenResponseType } from "./question-types.js";
export class EvaluatorFailure extends Error {
    code;
    constructor(code) {
        super(code);
        this.code = code;
    }
}
function invokeEvaluator(evaluate) {
    let raw;
    try {
        raw = evaluate();
    }
    catch {
        throw new EvaluatorFailure("EVALUATOR_FAILED");
    }
    const parsed = verdictResult.safeParse(raw);
    if (!parsed.success)
        throw new EvaluatorFailure("INVALID_EVALUATOR_RESULT");
    return parsed.data;
}
export function evaluationContext(activity, receipt) {
    const { id, version } = activity.practice;
    return { activityId: activity.activityId, stepAttemptId: receipt.stepAttemptId, slotId: receipt.slotId, practice: { id, version } };
}
export function evaluateFrozenAnswers(registry, practice, reference, context, answers, keyOf) {
    const evaluator = registry.evaluator(reference);
    if (!evaluator)
        throw new LearningError(503, "EVALUATOR_UNAVAILABLE");
    return answers.map(({ questionId, questionVersion, value }) => {
        const question = practice.questions.find(({ id }) => id === questionId);
        if (!question)
            throw new Error("冻结的作答缺少对应题目");
        const type = frozenResponseType(registry, practice, question);
        if (!evaluator.responseTypes.includes(type.id))
            throw new LearningError(503, "EVALUATOR_UNAVAILABLE");
        const key = keyOf(question);
        if (key === undefined)
            throw new Error("冻结的评分键缺少题目");
        const frozen = value === null ? null : type.parseValue(value, question);
        const result = invokeEvaluator(() => evaluator.evaluate({
            ...context, practice: { ...context.practice }, questionId, questionVersion, responseType: type.id, value: frozen, key,
        }));
        return { questionId, result };
    });
}
export function judgedOnly(outcomes) {
    return outcomes.map(({ questionId, result }) => {
        if (result.status !== "judged")
            throw new EvaluatorFailure("INVALID_EVALUATOR_RESULT");
        return { questionId, correct: result.correct };
    });
}
