import type { DatabaseSync } from "node:sqlite";
import type { ReadingActivity } from "./activity.ts";
export declare function studentResults(database: DatabaseSync, activity: ReadingActivity): {
    assessment?: never;
    review?: never;
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
};
