import { z } from "zod";
import { activeTeacherVerdict, verdictHistory } from "./verdict-history.js";
const storedAssessment = z.strictObject({ submissionId: z.uuid(), targetId: z.string(), status: z.enum(["pending", "done", "failed"]) });
const storedAutomatic = z.strictObject({
    questionId: z.string(), correct: z.literal([0, 1]).transform(Boolean), valid: z.literal([0, 1]).transform(Boolean),
});
export function assessmentTarget(database, activityId) {
    return findAssessmentTarget(database, "submission_id = (SELECT submission_id FROM completions WHERE activity_id = ?)", activityId);
}
export function submissionAssessmentTarget(database, submissionId) {
    return findAssessmentTarget(database, "submission_id = ?", submissionId);
}
function findAssessmentTarget(database, condition, id) {
    const target = database.prepare(`
    SELECT submission_id AS submissionId, target_id AS targetId, status
    FROM evaluation_tasks WHERE ${condition}
  `).get(id);
    return target ? storedAssessment.parse(target) : undefined;
}
export function submissionReviewTarget(database, submissionId, targetId) {
    const task = submissionAssessmentTarget(database, submissionId);
    if (task)
        return task;
    const required = database.prepare("SELECT 1 FROM response_review_requirements WHERE submission_id = ? LIMIT 1").get(submissionId);
    return required ? { submissionId, targetId, status: "unassessed" } : undefined;
}
export function readAutomaticVerdicts(database, { submissionId, targetId }) {
    return database.prepare(`
    SELECT question_id AS questionId, correct, valid FROM automatic_verdicts WHERE submission_id = ? AND target_id = ?
  `).all(submissionId, targetId).map(row => storedAutomatic.parse(row));
}
export function questionVerdicts(database, activity, target) {
    const questions = activity.practice.questions.map(({ id: questionId, prompt }) => ({ questionId, prompt }));
    return questionVerdictStates(database, target, questions);
}
export function questionVerdictStates(database, target, questions) {
    const automatic = readAutomaticVerdicts(database, target);
    const history = verdictHistory(database, target);
    return questions.map(question => {
        const { questionId } = question;
        const questionHistory = history.filter(event => event.questionId === questionId);
        const original = automatic.find(item => item.questionId === questionId);
        const automaticBasis = original && { correct: original.correct, valid: original.valid };
        const effective = activeTeacherVerdict(questionHistory) ?? effectiveAutomatic(automaticBasis);
        return {
            ...question, submissionId: target.submissionId, targetId: target.targetId,
            revision: questionHistory.at(-1)?.revision ?? 0, effective, automatic: automaticBasis, history: questionHistory,
        };
    });
}
function effectiveAutomatic(verdict) {
    return verdict?.valid ? { source: "automatic", correct: verdict.correct } : undefined;
}
