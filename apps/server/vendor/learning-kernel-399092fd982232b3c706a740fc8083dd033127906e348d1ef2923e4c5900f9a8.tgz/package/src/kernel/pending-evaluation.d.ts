import type { DatabaseSync } from "node:sqlite";
import type { Registry } from "./registry.ts";
import type { RuntimeCheckpoint } from "./runtime-checkpoint.ts";
export declare const maxEvaluationAttempts = 3;
export type EvaluationSummary = {
    evaluated: number;
    retrying: number;
    failed: number;
    deferred: number;
};
export declare function evaluatePending(database: DatabaseSync, registry: Registry, checkpoint?: RuntimeCheckpoint, submissionId?: string): EvaluationSummary;
