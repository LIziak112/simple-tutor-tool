import { z } from "zod";
const keyedValues = z.record(z.string(), z.unknown());
export function slotResponseType(registry, step, slot) {
    if (slot.type === "oneChoicePerQuestion")
        return registry.tool(step.tool)?.responseType;
    if (slot.type === "oneResponsePerQuestion")
        return slot.input;
    return undefined;
}
function impliedResponseType(registry, practice) {
    for (const step of practice.steps) {
        for (const slot of Object.values(step.submit.slots)) {
            const implied = slotResponseType(registry, step, slot);
            if (implied !== undefined)
                return implied;
        }
    }
    return undefined;
}
export function questionResponseType(registry, practice, question) {
    return question.response ?? impliedResponseType(registry, practice);
}
export function frozenResponseType(registry, practice, question) {
    const id = questionResponseType(registry, practice, question);
    if (id === undefined)
        throw new Error("冻结的题缺少作答形态");
    return registry.requireResponseType(id);
}
export function wholePaperValues(key, type) {
    const field = type.wholePaperKey?.field;
    if (field === undefined || !Object.hasOwn(key, field))
        return undefined;
    return keyedValues.parse(Reflect.get(key, field));
}
export function wholePaperQuestionKey(key, type, question) {
    const values = wholePaperValues(key, type);
    const layout = type.wholePaperKey;
    if (!values || !layout || !Object.hasOwn(values, question.id))
        return undefined;
    return type.parseKey?.(layout.toKey(values[question.id]), question);
}
