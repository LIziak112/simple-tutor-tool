import type { EvaluationContext, VerdictResult } from "../contracts/evaluator.ts";
import type { VersionRef } from "../contracts/reading.ts";
import type { ReadingActivity } from "./activity.ts";
import type { Registry } from "./registry.ts";
type Question = ReadingActivity["practice"]["questions"][number];
export type FrozenAnswer = {
    questionId: string;
    questionVersion: number;
    value: unknown;
};
export declare class EvaluatorFailure extends Error {
    readonly code: "EVALUATOR_FAILED" | "INVALID_EVALUATOR_RESULT";
    constructor(code: EvaluatorFailure["code"]);
}
export type QuestionKey = (question: Question) => unknown;
export declare function evaluationContext(activity: ReadingActivity, receipt: {
    stepAttemptId: string;
    slotId: string;
}): EvaluationContext;
export declare function evaluateFrozenAnswers(registry: Registry, practice: ReadingActivity["practice"], reference: VersionRef, context: EvaluationContext, answers: readonly FrozenAnswer[], keyOf: QuestionKey): {
    questionId: string;
    result: VerdictResult;
}[];
export declare function judgedOnly(outcomes: readonly {
    questionId: string;
    result: VerdictResult;
}[]): {
    questionId: string;
    correct: boolean;
}[];
export {};
