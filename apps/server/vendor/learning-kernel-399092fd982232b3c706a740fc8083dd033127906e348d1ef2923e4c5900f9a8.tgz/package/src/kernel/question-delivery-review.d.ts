import type { DatabaseSync } from "node:sqlite";
import type { ConfirmationKey } from "../contracts/choice-confirmation.ts";
import type { AuthorizeReview, FrozenConfirmationVerdictMode, VerdictCommand } from "../contracts/verdict.ts";
export declare function readQuestionDeliveryReview(database: DatabaseSync, reviewerId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeReview | undefined): {
    questions: {
        questionId: string;
        questionVersion: number;
        status: "needsReview";
    }[];
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: import("zod").JSONType;
        }[];
    };
    basis: {
        id: string;
        version: number;
        reviewCriteria: string;
    };
} | {
    questions: {
        questionId: string;
        questionVersion: number;
        status: "needsReview";
    }[];
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: import("zod").JSONType;
        }[];
    };
    basis?: never;
};
export declare function readQuestionDeliveryVerdicts(database: DatabaseSync, reviewerId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeReview | undefined): {
    targetId: string;
    questions: ({
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "judged";
        effective?: {
            source: "teacherReview";
            id: string;
            correct: boolean;
        } | {
            source: "automatic";
            correct: boolean;
        };
    } | {
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "evaluationFailed" | "needsReview" | "pendingEvaluation";
    })[];
    assessment: "manual";
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: import("zod").JSONType;
        }[];
    };
    basis: {
        id: string;
        version: number;
        reviewCriteria: string;
    };
} | {
    targetId: string;
    questions: ({
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "judged";
        effective?: {
            source: "teacherReview";
            id: string;
            correct: boolean;
        } | {
            source: "automatic";
            correct: boolean;
        };
    } | {
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "evaluationFailed" | "needsReview" | "pendingEvaluation";
    })[];
    assessment: "manual";
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: import("zod").JSONType;
        }[];
    };
    basis?: never;
} | {
    targetId: string;
    questions: ({
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "judged";
        effective?: {
            source: "teacherReview";
            id: string;
            correct: boolean;
        } | {
            source: "automatic";
            correct: boolean;
        };
    } | {
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "evaluationFailed" | "needsReview" | "pendingEvaluation";
    })[];
    assessment: "automatic";
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: import("zod").JSONType;
        }[];
    };
} | {
    targetId: string;
    questions: ({
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "judged";
        effective?: {
            source: "teacherReview";
            id: string;
            correct: boolean;
        } | {
            source: "automatic";
            correct: boolean;
        };
    } | {
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "evaluationFailed" | "needsReview" | "pendingEvaluation";
    })[];
    assessment: "teacherReview";
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: import("zod").JSONType;
        }[];
    };
};
export declare function readChoiceConfirmationVerdicts(database: DatabaseSync, reviewerId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeReview | undefined): {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        kind: "choiceConfirmation";
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            choice: string | null;
        }[];
    };
    targetId: string;
    assessment: "automatic";
    questions: ({
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "judged";
        effective?: {
            source: "teacherReview";
            id: string;
            correct: boolean;
        } | {
            source: "automatic";
            correct: boolean;
        };
    } | {
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "evaluationFailed" | "needsReview" | "pendingEvaluation";
    })[];
};
export declare function readResponseConfirmationVerdicts(database: DatabaseSync, reviewerId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeReview | undefined): {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        kind: "responseConfirmation";
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: import("zod").JSONType;
        }[];
    };
    targetId: string;
    assessment: "automatic";
    questions: ({
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "judged";
        effective?: {
            source: "teacherReview";
            id: string;
            correct: boolean;
        } | {
            source: "automatic";
            correct: boolean;
        };
    } | {
        questionId: string;
        questionVersion: number;
        revision: number;
        automatic?: {
            correct: boolean;
            valid: boolean;
        };
        history?: {
            submissionId: string;
            targetId: string;
            questionId: string;
            id: string;
            revision: number;
            reviewerId: string;
            reason: string;
            reviewedAt: string;
            action: "override" | "withdraw";
            correct: boolean | undefined;
            withdrawId: string | undefined;
        }[];
        status: "evaluationFailed" | "needsReview" | "pendingEvaluation";
    })[];
};
export declare function writeQuestionDeliveryVerdict(database: DatabaseSync, reviewerId: string, activityId: string, key: ConfirmationKey, command: VerdictCommand, authorize: AuthorizeReview | undefined, clock: () => Date, mode?: FrozenConfirmationVerdictMode): {
    submissionId: string;
    targetId: string;
    questionId: string;
    id: string;
    revision: number;
};
