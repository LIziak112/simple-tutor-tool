import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { ReadingActivity } from "./activity.ts";
declare const storedAssessment: z.ZodObject<{
    submissionId: z.ZodUUID;
    targetId: z.ZodString;
    status: z.ZodEnum<{
        done: "done";
        failed: "failed";
        pending: "pending";
    }>;
}, z.core.$strict>;
type Assessment = {
    submissionId: string;
    targetId: string;
    status: z.infer<typeof storedAssessment>["status"] | "unassessed";
};
export declare function assessmentTarget(database: DatabaseSync, activityId: string): {
    submissionId: string;
    targetId: string;
    status: "done" | "failed" | "pending";
} | undefined;
export declare function submissionAssessmentTarget(database: DatabaseSync, submissionId: string): {
    submissionId: string;
    targetId: string;
    status: "done" | "failed" | "pending";
} | undefined;
export declare function submissionReviewTarget(database: DatabaseSync, submissionId: string, targetId: string): Assessment | undefined;
export declare function readAutomaticVerdicts(database: DatabaseSync, { submissionId, targetId }: {
    submissionId: string;
    targetId: string;
}): {
    questionId: string;
    correct: boolean;
    valid: boolean;
}[];
export declare function questionVerdicts(database: DatabaseSync, activity: ReadingActivity, target: Assessment): ({
    questionId: string;
    prompt: string;
} & {
    submissionId: string;
    targetId: string;
    revision: number;
    effective: {
        source: "teacherReview";
        id: string;
        correct: boolean;
    } | {
        source: "automatic";
        correct: boolean;
    } | undefined;
    automatic: {
        correct: boolean;
        valid: boolean;
    } | undefined;
    history: {
        submissionId: string;
        targetId: string;
        questionId: string;
        id: string;
        revision: number;
        reviewerId: string;
        reason: string;
        reviewedAt: string;
        action: "override" | "withdraw";
        correct: 0 | 1 | null;
        withdrawId: string | null;
    }[];
})[];
export declare function questionVerdictStates<Question extends {
    questionId: string;
}>(database: DatabaseSync, target: Assessment, questions: readonly Question[]): (Question & {
    submissionId: string;
    targetId: string;
    revision: number;
    effective: {
        source: "teacherReview";
        id: string;
        correct: boolean;
    } | {
        source: "automatic";
        correct: boolean;
    } | undefined;
    automatic: {
        correct: boolean;
        valid: boolean;
    } | undefined;
    history: {
        submissionId: string;
        targetId: string;
        questionId: string;
        id: string;
        revision: number;
        reviewerId: string;
        reason: string;
        reviewedAt: string;
        action: "override" | "withdraw";
        correct: 0 | 1 | null;
        withdrawId: string | null;
    }[];
})[];
export {};
