import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
declare const changeTimes: z.ZodObject<{
    firstChangedAt: z.ZodNullable<z.ZodISODateTime>;
    lastChangedAt: z.ZodNullable<z.ZodISODateTime>;
}, z.core.$strict>;
export type ChoiceDraftActivity = z.infer<typeof changeTimes>;
export declare function readChoiceDraftActivity(database: DatabaseSync, student: string, activityId: string): ChoiceDraftActivity | undefined;
export declare function recordChoiceDraftChange(database: DatabaseSync, activityId: string, changedAt: Date): void;
export {};
