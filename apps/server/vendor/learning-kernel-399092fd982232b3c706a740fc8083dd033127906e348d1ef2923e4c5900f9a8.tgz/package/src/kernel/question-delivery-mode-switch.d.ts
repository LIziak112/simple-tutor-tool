import type { DatabaseSync } from "node:sqlite";
import type { ReadingPublication } from "../contracts/reading-publication.ts";
import type { ReadingActivity } from "./activity.ts";
type Practice = ReadingPublication["practice"];
export declare function rebindQuestionDeliveryDrafts(database: DatabaseSync, activity: ReadingActivity, practice: Practice, stepAttemptId: string): void;
export {};
