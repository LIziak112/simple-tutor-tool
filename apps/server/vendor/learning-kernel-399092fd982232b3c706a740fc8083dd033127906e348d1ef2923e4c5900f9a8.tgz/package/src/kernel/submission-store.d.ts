import type { DatabaseSync } from "node:sqlite";
import type { SubmitInput } from "../contracts/reading.ts";
export declare function submissionForOperation(database: DatabaseSync, input: Pick<SubmitInput, "stepAttemptId" | "operationId">): {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    draft: {
        id: string;
        version: number;
    };
} | undefined;
export declare function recoverReceipt(database: DatabaseSync, input: SubmitInput): {
    id: string;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
} | undefined;
export type Observation = {
    targetId: string;
    unitId: string;
};
export declare function recordSubmission(database: DatabaseSync, input: SubmitInput, observations: readonly Observation[], confirmedAt: Date): {
    id: `${string}-${string}-${string}-${string}-${string}`;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export declare function submittedSlots(database: DatabaseSync, stepAttemptId: string): Set<string>;
export declare function finishActivity(database: DatabaseSync, activityId: string, submissionId: string): void;
export declare function activitySubmissions(database: DatabaseSync, activityId: string): {
    stepId: string;
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    content: unknown;
}[];
export type StoredSubmission = ReturnType<typeof activitySubmissions>[number];
