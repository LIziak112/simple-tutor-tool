import type { DatabaseSync } from "node:sqlite";
import { z } from "zod";
import type { AuthorizeConfirmationRecovery, ConfirmationKey, VerifyOriginal } from "../contracts/choice-confirmation.ts";
import type { QuestionDeliveryInput } from "../contracts/question-delivery.ts";
import type { Registry } from "./registry.ts";
export declare function confirmQuestionDelivery(database: DatabaseSync, registry: Registry, studentId: string, activityId: string, input: QuestionDeliveryInput, clock: () => Date, verifyOriginal: VerifyOriginal | undefined, authorize: AuthorizeConfirmationRecovery | undefined): {
    id: string;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export declare function recoverQuestionDelivery(database: DatabaseSync, studentId: string, activityId: string, key: ConfirmationKey, authorize: AuthorizeConfirmationRecovery | undefined, mode: "automatic" | "declared"): {
    assessment: "automatic";
    evaluation: {
        status: "failed" | "pending";
        evaluator: {
            id: string;
            version: number;
        };
        questionCount?: never;
        correctCount?: never;
        needsReviewCount?: never;
        questions?: never;
    } | {
        status: "evaluated";
        evaluator: {
            id: string;
            version: number;
        };
        questionCount: number;
        correctCount: number;
        needsReviewCount: number;
        questions: {
            questionId: string;
            questionVersion: number;
            result: {
                status: "judged";
                correct: boolean;
            } | {
                status: "needsReview";
            };
        }[];
    };
    review?: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: z.JSONType;
        }[];
    };
    requestQuestions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
    }[];
    draftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
} | {
    assessment: "manual";
    review: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: z.JSONType;
        }[];
    };
    requestQuestions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
    }[];
    draftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
} | {
    assessment: "teacherReview";
    review: {
        questions: {
            questionId: string;
            questionVersion: number;
            status: "needsReview";
        }[];
    };
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: z.JSONType;
        }[];
    };
    requestQuestions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
    }[];
    draftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
} | {
    review?: never;
    assessment: "none";
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    practice: {
        id: string;
        version: number;
    };
    confirmation: {
        source: "finish" | "question" | "whole";
        slotId: string;
        questions: {
            questionId: string;
            questionVersion: number;
            revision: number;
            original: {
                state: "frozen";
                documentId: string;
                versionId: string;
                sha256?: string | undefined;
            } | {
                state: "none";
            } | {
                state: "missing";
            } | {
                state: "uncollected";
            };
            value: z.JSONType;
        }[];
    };
    requestQuestions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
    }[];
    draftChangeCounts: {
        questionId: string;
        changeCount: number;
    }[];
};
