import { selectionSchema } from "../contracts/reading.js";
import { LearningError } from "../contracts/learning-error.js";
export function selectedText(material, range) {
    const paragraph = material.paragraphs.find(item => item.id === range.paragraphId);
    if (!paragraph || range.end > paragraph.text.length) {
        throw new LearningError(422, "INVALID_SELECTION");
    }
    const text = paragraph.text.slice(range.start, range.end);
    if (!text.trim())
        throw new LearningError(422, "INVALID_SELECTION");
    return text;
}
export function selectText(material, step, range) {
    return selectionSchema.parse({
        material: { id: material.id, version: material.version },
        positionId: step.positionId,
        range,
        text: selectedText(material, range),
    });
}
