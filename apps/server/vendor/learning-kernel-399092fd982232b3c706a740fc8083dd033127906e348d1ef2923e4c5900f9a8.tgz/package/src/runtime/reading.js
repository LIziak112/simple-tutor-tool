import { z } from "zod";
import { LearningError } from "../contracts/learning-error.js";
import { id, redoInput, saveInput, startInput, submitInput } from "../contracts/reading.js";
import { readingAnswerInput, readingSaveInput } from "../contracts/reading-runtime.js";
import { verdictCommand } from "../contracts/verdict.js";
import { redoActivity, startActivity } from "../kernel/activity.js";
import { managementInput, managementView, manageReading } from "../kernel/review-access.js";
import { readReview, selectionFeedbackInput, writeSelectionFeedback, writeVerdict } from "../kernel/review.js";
import { readStudentFragment, readStudentResults, readSubmission, saveDraft, submitDraft } from "../kernel/submission.js";
import { readPersonalDraft } from "../kernel/work-versions.js";
const student = z.strictObject({ role: z.literal("student"), id });
const reviewer = z.strictObject({ role: z.literal("reviewer"), id });
const uuid = z.uuid();
const saveRequest = z.union([saveInput, readingSaveInput, readingAnswerInput]);
const studentResource = z.enum(["assessment", "review", "export"]);
const assignment = z.strictObject({ assignedReviewer: id.optional() }).optional();
function principalOf(schema, principal) {
    const parsed = schema.safeParse(principal);
    if (!parsed.success)
        throw new LearningError(403, "FORBIDDEN");
    return parsed.data.id;
}
export function readingEntries({ database, registry, clock, checkpoint }) {
    const learner = (principal) => principalOf(student, principal);
    const teacher = (principal) => principalOf(reviewer, principal);
    return {
        startLatest(principal, input, options) {
            return startActivity(database, learner(principal), startInput.parse(input), clock, assignment.parse(options)?.assignedReviewer);
        },
        redo(principal, activityId, input) {
            return redoActivity(database, learner(principal), uuid.parse(activityId), redoInput.parse(input).operationId, clock);
        },
        saveDraft(principal, activityId, input) {
            return saveDraft(database, registry, learner(principal), uuid.parse(activityId), saveRequest.parse(input));
        },
        submitDraft(principal, activityId, input) {
            return submitDraft(database, registry, learner(principal), uuid.parse(activityId), submitInput.parse(input), clock, checkpoint);
        },
        readSubmission(principal, activityId, submissionId) {
            return readSubmission(database, learner(principal), uuid.parse(activityId), uuid.parse(submissionId));
        },
        readFragment(principal, activityId, submissionId) {
            return readStudentFragment(database, learner(principal), uuid.parse(activityId), uuid.parse(submissionId));
        },
        readResults(principal, activityId, resource) {
            return readStudentResults(database, learner(principal), uuid.parse(activityId), studentResource.parse(resource));
        },
        readPersonalDraft(principal, workId) {
            return readPersonalDraft(database, learner(principal), uuid.parse(workId));
        },
        readReadingReview(principal, activityId) {
            return readReview(database, teacher(principal), uuid.parse(activityId));
        },
        writeReadingVerdict(principal, activityId, command) {
            return writeVerdict(database, teacher(principal), uuid.parse(activityId), verdictCommand.parse(command), clock);
        },
        writeSelectionFeedback(principal, activityId, input) {
            return writeSelectionFeedback(database, teacher(principal), uuid.parse(activityId), selectionFeedbackInput.parse(input).text);
        },
        readManagement(principal, activityId) {
            return managementView(database, teacher(principal), uuid.parse(activityId));
        },
        manage(principal, activityId, input) {
            return manageReading(database, teacher(principal), uuid.parse(activityId), managementInput.parse(input).action);
        },
    };
}
