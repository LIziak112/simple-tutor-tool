import type { DatabaseSync } from "node:sqlite";
import type { CurrentChoiceDraftMode } from "../contracts/choice-draft.ts";
import type { QuestionDeliveryDraftInput } from "../contracts/question-delivery.ts";
import type { ReadingActivity } from "./activity.ts";
import type { DeliverySlot } from "./question-delivery-publication.ts";
import { QuestionDraftConflict } from "./question-draft-store.ts";
type Value = QuestionDeliveryDraftInput["value"];
export declare class QuestionDeliveryConflict extends QuestionDraftConflict<{
    revision: number;
    value: Value | null;
}> {
    readonly questionId: string | undefined;
    constructor(current: {
        revision: number;
        value: Value | null;
    }, code?: "ANSWER_REVISION_CONFLICT" | "OPERATION_CONFLICT", questionId?: string);
}
export declare function saveQuestionDeliveryDraft(database: DatabaseSync, studentId: string, activityId: string, input: QuestionDeliveryDraftInput, mode: CurrentChoiceDraftMode, clock: () => Date): {
    questionId: string;
    questionVersion: number;
    value: string | boolean | number[];
    revision: number;
    changeCount: number;
    slotId: string;
};
export declare function readOpenDeliveryDrafts(database: DatabaseSync, activity: ReadingActivity, logicalSlotId: string, submitted: ReadonlySet<string>): {
    questionVersion: number;
    value: string | boolean | number[];
    questionId: string;
    revision: number;
    changeCount: number;
    slotId: string;
}[];
export declare function deliveryDraftHead(database: DatabaseSync, activity: ReadingActivity, slotId: string, questionId: string): ({
    workId: string;
    slotId: string;
    questionId: string;
    workVersion: number;
    revision: number;
    changeCount: number;
} & {
    questionVersion: number;
    value: string | boolean | number[];
}) | undefined;
export declare function requireQuestionDeliverySlot(activity: ReadingActivity, slotId: string): {
    source: string;
    targetId: string;
    type: "questionDelivery";
    delivery: {
        mode: "whole";
    } | {
        mode: "perQuestion";
        questionSlots: {
            [k: string]: string;
        };
    };
    confirmFromDrafts: {
        allowUnanswered: boolean;
    };
};
export declare function questionDeliveryPosition(slot: DeliverySlot, logicalSlotId: string, questionId: string): string;
export declare function requireFrozenQuestion(activity: ReadingActivity, { questionId, questionVersion }: {
    questionId: string;
    questionVersion: number;
}): {
    id: string;
    version?: number | undefined;
    prompt: string;
    options: Record<string, string>;
    response?: "booleanOrString" | "choice" | "optionIndexArray" | undefined;
};
export {};
