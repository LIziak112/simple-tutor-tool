import type { DatabaseSync } from "node:sqlite";
import type { ChoiceDraftInput, ChoiceDraftScope, CurrentChoiceDraftMode, UnversionedChoiceDraftInput } from "../contracts/choice-draft.ts";
import type { ReadingActivity } from "./activity.ts";
import { publicDraft as draftReceipt, QuestionDraftConflict } from "./question-draft-store.ts";
export { draftReceipt };
export declare class ChoiceDraftConflict extends QuestionDraftConflict<{
    revision: number;
    choice: string | null;
}> {
}
export declare function readChoiceDrafts(database: DatabaseSync, activityId: string, stepAttemptId: string): Omit<{
    workId: string;
    slotId: string;
    questionId: string;
    workVersion: number;
    revision: number;
    changeCount: number;
} & {
    questionVersion: number;
    choice: string;
}, "workId" | "workVersion">[];
type DraftInput = ChoiceDraftInput | UnversionedChoiceDraftInput;
type DraftQuestion = ReadingActivity["practice"]["questions"][number];
export declare function saveChoiceDraft(database: DatabaseSync, student: string, activityId: string, input: DraftInput, clock: () => Date): Omit<{
    workId: string;
    workVersion: number;
    slotId: string;
    questionId: string;
    revision: number;
    questionVersion: number;
    choice: string;
    changeCount: number;
}, "workId" | "workVersion">;
export declare function saveCurrentChoiceDraft(database: DatabaseSync, student: string, activityId: string, input: DraftInput, mode: CurrentChoiceDraftMode, clock: () => Date): Omit<{
    workId: string;
    workVersion: number;
    slotId: string;
    questionId: string;
    revision: number;
    questionVersion: number;
    choice: string;
    changeCount: number;
}, "workId" | "workVersion">;
export declare function readChoiceRevision(database: DatabaseSync, workId: string, revision: number): {
    workId: string;
    slotId: string;
    questionId: string;
    workVersion: number;
    revision: number;
    changeCount: number;
} & {
    questionVersion: number;
    choice: string;
};
export declare function requireDraftQuestion(activity: ReadingActivity, input: ChoiceDraftScope): {
    id: string;
    version?: number | undefined;
    prompt: string;
    options: Record<string, string>;
    response?: "booleanOrString" | "choice" | "optionIndexArray" | undefined;
};
export declare function requireWritableChoice(question: DraftQuestion, choice: string): void;
export declare function readChoiceHead(database: DatabaseSync, activityId: string, scope: ChoiceDraftScope): ({
    workId: string;
    slotId: string;
    questionId: string;
    workVersion: number;
    revision: number;
    changeCount: number;
} & {
    questionVersion: number;
    choice: string;
}) | undefined;
export declare function choiceState(database: DatabaseSync, scope: ChoiceDraftScope, current: ReturnType<typeof readChoiceHead>): {
    revision: number;
    choice: null;
} | ({
    workId: string;
    slotId: string;
    questionId: string;
    workVersion: number;
    revision: number;
    changeCount: number;
} & {
    questionVersion: number;
    choice: string;
});
export declare function appendChoiceVersion(database: DatabaseSync, activityId: string, input: DraftInput, current: ReturnType<typeof readChoiceHead>, clock: () => Date, actor?: "student" | "reviewer"): {
    workId: string;
    workVersion: number;
    slotId: string;
    questionId: string;
    revision: number;
    questionVersion: number;
    choice: string;
    changeCount: number;
};
