import { z } from "zod";
import { findChoiceEvaluator } from "../contracts/choice-evaluation.js";
import { questionDeliveryScoringKey } from "../contracts/question-delivery.js";
import { findResponseEvaluator } from "../contracts/response-evaluation.js";
import { indexResponseValue, responseValue } from "../contracts/response.js";
import { LearningError } from "./learning-error.js";
import { recoverEvaluatedResponses } from "./response-evaluation.js";
import { submissionAssessmentTarget } from "./verdict-state.js";
export function recoverQuestionDeliveryEvaluation(database, activity, receipt, delivery, registered) {
    const target = submissionAssessmentTarget(database, receipt.id);
    return recoverEvaluatedResponses(database, activity, receipt, delivery.questions, (reference, key, context) => {
        const { acceptedByQuestion } = questionDeliveryScoringKey.parse(key);
        return question => {
            const basis = Object.hasOwn(acceptedByQuestion, question.questionId) ? acceptedByQuestion[question.questionId] : undefined;
            if (!basis)
                throw new Error("冻结的逐题评分键缺少题目");
            const evaluate = evaluateOf(reference, basis, registered);
            return evaluate({ ...context, practice: { ...context.practice }, ...question });
        };
    }, target);
}
const confirmedChoice = z.string().nullable();
const confirmedScalar = responseValue.nullable();
const confirmedIndexes = indexResponseValue.nullable();
function evaluateOf(reference, basis, { choice = [], scalar = [], indexes = [] }) {
    switch (basis.response) {
        case "choice": {
            const evaluate = requireEvaluator(findChoiceEvaluator(choice, reference));
            return ({ value, ...context }) => {
                const correct = evaluate({ ...context, choice: confirmedChoice.parse(value), acceptedChoice: basis.acceptedChoice });
                return { status: "judged", correct };
            };
        }
        case "booleanOrString": {
            const evaluate = requireEvaluator(findResponseEvaluator(scalar, reference));
            return ({ value, ...context }) => evaluate({ ...context, value: confirmedScalar.parse(value), acceptedResponse: basis.acceptedResponse });
        }
        case "optionIndexArray": {
            const evaluate = requireEvaluator(findResponseEvaluator(indexes, reference));
            return ({ value, ...context }) => evaluate({ ...context, value: confirmedIndexes.parse(value), acceptedIndexes: [...basis.acceptedIndexes] });
        }
    }
}
function requireEvaluator(evaluate) {
    if (!evaluate)
        throw new LearningError(503, "EVALUATOR_UNAVAILABLE");
    return evaluate;
}
