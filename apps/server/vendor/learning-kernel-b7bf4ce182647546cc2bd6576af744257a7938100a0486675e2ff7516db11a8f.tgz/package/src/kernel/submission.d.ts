import type { DatabaseSync } from "node:sqlite";
import type { ActivityDetail, SaveInput, SubmitInput } from "../contracts/reading.ts";
import type { ReadingAnswerInput, ReadingSaveInput } from "../contracts/reading-runtime.ts";
import type { ReadingActivity } from "./activity.ts";
import { readingActivityView } from "./reading-progress.ts";
import type { RuntimeCheckpoint } from "./runtime-checkpoint.ts";
import type { StoredSubmission } from "./submission-store.ts";
export declare function saveDraft(database: DatabaseSync, student: string, activityId: string, input: SaveInput | ReadingSaveInput | ReadingAnswerInput): {
    draft: {
        id: string;
        version: number;
    };
    selection: {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        range: {
            paragraphId: string;
            start: number;
            end: number;
        };
        text: string;
    };
} | {
    draft: {
        id: string;
        version: number;
    };
    selection: {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        ranges: {
            role: string;
            range: {
                paragraphId: string;
                start: number;
                end: number;
            };
            text: string;
        }[];
    };
} | {
    draft: {
        id: string;
        version: number;
    };
    answer: {
        choices: Record<string, string>;
        references: Record<string, string>;
        reason?: {
            text: string;
            independent: boolean;
        } | undefined;
    };
};
export declare function submitDraft(database: DatabaseSync, student: string, activityId: string, input: SubmitInput, clock: () => Date, checkpoint?: RuntimeCheckpoint): {
    id: string;
    stepAttemptId: string;
    slotId: string;
    confirmedAt: string;
};
export type ActivityView = ActivityDetail | ReturnType<typeof legacyReadingActivityView> | ReturnType<typeof questionDeliveryActivityView>;
export declare function readActivity(database: DatabaseSync, student: string, activityId: string): ActivityView;
declare function legacyReadingActivityView(database: DatabaseSync, activity: ReadingActivity, view: ReturnType<typeof readingActivityView>): {
    assessment?: never;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
} | {
    assessment?: never;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    indexResponseDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        value: number[];
    }, "workId" | "workVersion">[];
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    indexResponseDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        value: number[];
    }, "workId" | "workVersion">[];
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    indexResponseDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        value: number[];
    }, "workId" | "workVersion">[];
} | {
    assessment?: never;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    responseDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        value: string | boolean;
    }, "workId" | "workVersion">[];
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    responseDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        value: string | boolean;
    }, "workId" | "workVersion">[];
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    responseDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        value: string | boolean;
    }, "workId" | "workVersion">[];
} | {
    assessment?: never;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    choiceDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        choice: string;
    }, "workId" | "workVersion">[];
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    choiceDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        choice: string;
    }, "workId" | "workVersion">[];
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    choiceDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        choice: string;
    }, "workId" | "workVersion">[];
} | {
    assessment?: never;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    choiceSnapshotRevisions: {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
    }[];
    choiceDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        choice: string;
    }, "workId" | "workVersion">[];
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    choiceSnapshotRevisions: {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
    }[];
    choiceDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        choice: string;
    }, "workId" | "workVersion">[];
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    choiceSnapshotRevisions: {
        slotId: string;
        questionId: string;
        questionVersion: number;
        revision: number;
    }[];
    choiceDrafts: Omit<{
        workId: string;
        slotId: string;
        questionId: string;
        workVersion: number;
        revision: number;
        changeCount: number;
    } & {
        questionVersion: number;
        choice: string;
    }, "workId" | "workVersion">[];
};
declare function questionDeliveryActivityView(database: DatabaseSync, activity: ReadingActivity, view: ReturnType<typeof readingActivityView>, slotId: string, submissions: readonly StoredSubmission[]): {
    assessment?: never;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    questionDeliveries: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    }[];
    questionDeliveryDrafts: {
        questionVersion: number;
        value: string | boolean | number[];
        questionId: string;
        revision: number;
        changeCount: number;
        slotId: string;
    }[];
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    questionDeliveries: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    }[];
    questionDeliveryDrafts: {
        questionVersion: number;
        value: string | boolean | number[];
        questionId: string;
        revision: number;
        changeCount: number;
        slotId: string;
    }[];
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
    formatVersion: 1;
    practiceVersion?: number;
    activityId: string;
    stepAttemptId: string;
    startedAt: string;
    material: {
        id: string;
        version: number;
        source: string;
        title: string;
        paragraphs: {
            id: string;
            text: string;
        }[];
    } | undefined;
    redoOf: string | undefined;
    title: string;
    step: {
        id: string;
        instructions: string;
        tool: {
            id: string;
            version: number;
        };
        submit: {
            purpose: "finalAnswer" | "stepEvidence";
            slots: Record<string, {
                type: "reuse";
                source: string;
            } | {
                source: string;
                targetId: string;
                type: "passageSelection";
                oneRangePerRole: Record<string, string>;
                distinctParagraphs: boolean;
                evidenceUnit: "wholeSelection";
            } | {
                source: string;
                targetId: string;
                type: "oneChoicePerQuestion";
                reasonTargetId?: string | undefined;
                confirmFromDrafts?: {
                    allowUnanswered: boolean;
                } | undefined;
            } | {
                source: string;
                targetId: string;
                type: "oneResponsePerQuestion";
                input: "booleanOrString" | "optionIndexArray";
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            } | {
                source: string;
                targetId: string;
                type: "questionDelivery";
                delivery: {
                    mode: "whole";
                } | {
                    mode: "perQuestion";
                    questionSlots: {
                        [k: string]: string;
                    };
                };
                confirmFromDrafts: {
                    allowUnanswered: boolean;
                };
            }>;
        };
    };
    status: "active" | "completed";
    inputs: {
        [k: string]: {
            from: "material";
            positionId: string;
            material?: import("../contracts/reading.ts").Material;
        } | {
            from: "questions";
            questions: ReadingActivity["practice"]["questions"];
        } | ({
            from: "submission";
        } & {
            receipt?: StoredSubmission["receipt"];
            confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
            responseConfirmation?: import("../server.ts").ResponseConfirmation;
            indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
            questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
            selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
            answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
                references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
            };
        });
    };
    submission: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    } | undefined;
    questionDeliveries: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    }[];
    questionDeliveryDrafts: {
        questionVersion: number;
        value: string | boolean | number[];
        questionId: string;
        revision: number;
        changeCount: number;
        slotId: string;
    }[];
};
export declare function readSubmission(database: DatabaseSync, student: string, activityId: string, submissionId: string): {
    receipt?: StoredSubmission["receipt"];
    confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
    responseConfirmation?: import("../server.ts").ResponseConfirmation;
    indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
    questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
    selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
    answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
        references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
    };
} | {
    receipt: {
        id: string;
        stepAttemptId: string;
        slotId: string;
        confirmedAt: string;
    };
    selection: {
        material: {
            id: string;
            version: number;
        };
        positionId: string;
        range: {
            paragraphId: string;
            start: number;
            end: number;
        };
        text: string;
    };
};
export declare function readStudentFragment(database: DatabaseSync, student: string, activityId: string, submissionId: string): {
    material: {
        id: string;
        version: number;
    };
    positionId: string;
    range: {
        paragraphId: string;
        start: number;
        end: number;
    };
    text: string;
} | {
    material: {
        id: string;
        version: number;
    };
    positionId: string;
    ranges: {
        role: string;
        range: {
            paragraphId: string;
            start: number;
            end: number;
        };
        text: string;
    }[];
};
export declare function readStudentResults(database: DatabaseSync, student: string, activityId: string, resource: "assessment" | "review" | "export"): {
    byQuestion: {
        questionId: string;
        correct: boolean;
    }[] | undefined;
    selectionFeedback: string | undefined;
} | {
    assessment: {
        status: "pending";
    } | {
        status: "complete";
    } | undefined;
} | {
    assessment?: never;
    review?: never;
    activityId: string;
    status: string;
    redoOf: string | undefined;
    submissions: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    }[];
} | {
    assessment: {
        status: "pending";
    } | undefined;
    review?: never;
    activityId: string;
    status: string;
    redoOf: string | undefined;
    submissions: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    }[];
} | {
    assessment: {
        status: "complete";
    };
    review: {
        byQuestion: {
            questionId: string;
            correct: boolean;
        }[] | undefined;
        selectionFeedback: string | undefined;
    } | undefined;
    activityId: string;
    status: string;
    redoOf: string | undefined;
    submissions: {
        receipt?: StoredSubmission["receipt"];
        confirmation?: import("../contracts/choice-confirmation.ts").ChoiceConfirmation;
        responseConfirmation?: import("../server.ts").ResponseConfirmation;
        indexResponseConfirmation?: import("../server.ts").IndexResponseConfirmation;
        questionDelivery?: ReturnType<typeof import("../contracts/question-delivery.ts").questionDeliveryView>;
        selection?: import("../contracts/reading-runtime.ts").ReadingSelection;
        answer?: Omit<import("../contracts/reading-runtime.ts").ReadingAnswer, "references"> & {
            references?: import("../contracts/reading-runtime.ts").ReadingAnswer["references"];
        };
    }[];
};
export {};
