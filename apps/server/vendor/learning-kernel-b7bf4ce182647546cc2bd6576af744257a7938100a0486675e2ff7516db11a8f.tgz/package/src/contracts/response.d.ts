import { z } from "zod";
import { choiceConfirmationInput } from "./choice-confirmation.ts";
export declare const responseValue: z.ZodUnion<readonly [z.ZodBoolean, z.ZodString]>;
export declare const optionIndex: z.ZodInt;
export declare const indexResponseValue: z.ZodArray<z.ZodInt>;
export declare const responseFormat: z.ZodEnum<{
    booleanOrString: "booleanOrString";
    optionIndexArray: "optionIndexArray";
}>;
export declare const responseDraftValue: z.ZodObject<{
    questionVersion: z.ZodInt;
    value: z.ZodUnion<readonly [z.ZodBoolean, z.ZodString]>;
}, z.core.$strict>;
export declare const responseDraftInput: z.ZodObject<{
    questionVersion: z.ZodInt;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    operationId: z.ZodString;
    baseRevision: z.ZodInt;
    value: z.ZodUnion<readonly [z.ZodBoolean, z.ZodString]>;
}, z.core.$strict>;
export declare const indexResponseDraftValue: z.ZodObject<{
    questionVersion: z.ZodInt;
    value: z.ZodArray<z.ZodInt>;
}, z.core.$strict>;
export declare const indexResponseDraftInput: z.ZodObject<{
    questionVersion: z.ZodInt;
    protocolVersion: z.ZodLiteral<1>;
    stepAttemptId: z.ZodUUID;
    slotId: z.ZodString;
    questionId: z.ZodString;
    operationId: z.ZodString;
    baseRevision: z.ZodInt;
    value: z.ZodArray<z.ZodInt>;
}, z.core.$strict>;
export declare const responseConfirmation: z.ZodObject<{
    kind: z.ZodLiteral<"responseConfirmation">;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        questionVersion: z.ZodInt;
        revision: z.ZodInt;
        original: z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"frozen">;
            documentId: z.ZodString;
            versionId: z.ZodString;
            sha256: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"none">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"missing">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"uncollected">;
        }, z.core.$strict>], "state">;
        value: z.ZodNullable<z.ZodUnion<readonly [z.ZodBoolean, z.ZodString]>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const indexResponseConfirmation: z.ZodObject<{
    kind: z.ZodLiteral<"indexResponseConfirmation">;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        questionVersion: z.ZodInt;
        revision: z.ZodInt;
        original: z.ZodDiscriminatedUnion<[z.ZodObject<{
            state: z.ZodLiteral<"frozen">;
            documentId: z.ZodString;
            versionId: z.ZodString;
            sha256: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"none">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"missing">;
        }, z.core.$strict>, z.ZodObject<{
            state: z.ZodLiteral<"uncollected">;
        }, z.core.$strict>], "state">;
        value: z.ZodNullable<z.ZodArray<z.ZodInt>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare function readResponseConfirmation(content: unknown): {
    kind: "responseConfirmation";
    questions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
        value: string | boolean | null;
    }[];
} | undefined;
export declare function readIndexResponseConfirmation(content: unknown): {
    kind: "indexResponseConfirmation";
    questions: {
        questionId: string;
        questionVersion: number;
        revision: number;
        original: {
            state: "frozen";
            documentId: string;
            versionId: string;
            sha256?: string | undefined;
        } | {
            state: "none";
        } | {
            state: "missing";
        } | {
            state: "uncollected";
        };
        value: number[] | null;
    }[];
} | undefined;
export type ResponseValue = z.infer<typeof responseValue>;
export type ResponseDraftInput = z.infer<typeof responseDraftInput>;
export type ResponseConfirmationInput = z.infer<typeof choiceConfirmationInput>;
export type ResponseConfirmation = z.infer<typeof responseConfirmation>;
export type IndexResponseDraftInput = z.infer<typeof indexResponseDraftInput>;
export type IndexResponseConfirmation = z.infer<typeof indexResponseConfirmation>;
export type ResponseFormat = z.infer<typeof responseFormat>;
export type StoredResponseValue = ResponseValue | readonly number[];
export declare function hasStoredResponse(value: StoredResponseValue | null): boolean;
export declare function sameStoredResponse(left: StoredResponseValue | null, right: StoredResponseValue | null): boolean;
