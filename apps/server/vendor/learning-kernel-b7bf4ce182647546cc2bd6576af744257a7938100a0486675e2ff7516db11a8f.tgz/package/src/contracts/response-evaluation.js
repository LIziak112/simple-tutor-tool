import { z } from "zod";
import { isReservedReadingCapability } from "../builtins/reading-capabilities.js";
import { versionRef } from "./reading.js";
export const responseVerdict = z.discriminatedUnion("status", [
    z.strictObject({ status: z.literal("judged"), correct: z.boolean() }),
    z.strictObject({ status: z.literal("needsReview") }),
]);
const registration = versionRef.extend({
    evaluate: z.custom(value => typeof value === "function"),
});
function validRegistrations(registered) {
    const identities = new Set(registered.map(({ id, version }) => JSON.stringify([id, version])));
    return identities.size === registered.length && registered.every(({ id }) => !isReservedReadingCapability(id));
}
const registrationIssue = "须注册唯一且非内置的原值评估器版本";
export const responseEvaluators = z.array(registration).refine(validRegistrations, registrationIssue);
export const indexResponseEvaluators = z.array(registration.extend({
    evaluate: z.custom(value => typeof value === "function"),
})).refine(validRegistrations, registrationIssue);
export function findResponseEvaluator(registered, { id, version }) {
    return registered.find(evaluator => evaluator.id === id && evaluator.version === version)?.evaluate;
}
