import { z } from "zod";
import type { ChoiceEvaluationInput } from "./choice-evaluation.ts";
import type { VersionRef } from "./reading.ts";
import type { ResponseValue } from "./response.ts";
export declare const responseVerdict: z.ZodDiscriminatedUnion<[z.ZodObject<{
    status: z.ZodLiteral<"judged">;
    correct: z.ZodBoolean;
}, z.core.$strict>, z.ZodObject<{
    status: z.ZodLiteral<"needsReview">;
}, z.core.$strict>], "status">;
export type ResponseVerdict = z.infer<typeof responseVerdict>;
export type ResponseEvaluationInput = Readonly<Omit<ChoiceEvaluationInput, "choice" | "acceptedChoice"> & {
    value: ResponseValue | null;
    acceptedResponse: boolean;
}>;
export type ResponseEvaluator = (input: ResponseEvaluationInput) => ResponseVerdict;
export type IndexResponseEvaluationInput = Readonly<Omit<ResponseEvaluationInput, "value" | "acceptedResponse"> & {
    value: readonly number[] | null;
    acceptedIndexes: readonly number[];
}>;
export type IndexResponseEvaluator = (input: IndexResponseEvaluationInput) => ResponseVerdict;
declare const registration: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<ResponseEvaluator, ResponseEvaluator>;
}, z.core.$strict>;
export declare const responseEvaluators: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<ResponseEvaluator, ResponseEvaluator>;
}, z.core.$strict>>;
export declare const indexResponseEvaluators: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    version: z.ZodInt;
    evaluate: z.ZodCustom<IndexResponseEvaluator, IndexResponseEvaluator>;
}, z.core.$strict>>;
export type ResponseEvaluatorRegistration = z.infer<typeof registration>;
export type IndexResponseEvaluatorRegistration = z.infer<typeof indexResponseEvaluators>[number];
export declare function findResponseEvaluator<T extends VersionRef & {
    evaluate: unknown;
}>(registered: readonly T[], { id, version }: VersionRef): T["evaluate"] | undefined;
export {};
